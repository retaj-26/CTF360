// CTF360 optional server — zero dependencies, Node 22.18+.
//
// What it does:
//   • serves the built site from ../dist
//   • POST /api/validate     { challengeId, stage, answer } → { correct }
//   • POST /api/facilitator  { code } → { ok }   (code from FACILITATOR_CODE env var)
//   • GET/POST /api/teams, DELETE /api/teams/:id — shared team leaderboard (server/teams.json)
//   • /api/register, /api/login, /api/progress — team accounts (scrypt), progress + activity log (server/data.json)
//   • /api/settings, /api/admin/* — competition lock and the admin dashboard
//     (admin login from ADMIN_USER / ADMIN_PASS, or server/admin.json)
//
// Use it with a server build (`npm run build:server`): that build ships NO answer
// hashes to the browser, so answers can only be checked here.
//
//   FACILITATOR_CODE=choose-a-code PORT=8360 npm run serve
//
import { createServer } from 'node:http';
import { readFileSync, writeFileSync, existsSync, statSync, createReadStream } from 'node:fs';
import { extname, join, normalize as normPath } from 'node:path';
import { fileURLToPath } from 'node:url';
import { timingSafeEqual, scryptSync, randomBytes, createHash } from 'node:crypto';
import { normalize } from '../src/engine/normalize.ts';

const here = fileURLToPath(new URL('.', import.meta.url));
const DIST = join(here, '..', 'dist');
const PORT = Number(process.env.PORT || 8360);
const CODE = process.env.FACILITATOR_CODE || '';
const ANSWERS = JSON.parse(readFileSync(join(here, 'answers.json'), 'utf8'));
const TEAMS_FILE = process.env.TEAMS_FILE || join(here, 'teams.json');
let TEAMS = existsSync(TEAMS_FILE) ? JSON.parse(readFileSync(TEAMS_FILE, 'utf8')) : {};
const saveTeams = () => writeFileSync(TEAMS_FILE, JSON.stringify(TEAMS, null, 1));

// ── accounts / logs / settings (server/data.json) ──
const DATA_FILE = process.env.DATA_FILE || join(here, 'data.json');
let DATA = existsSync(DATA_FILE) ? JSON.parse(readFileSync(DATA_FILE, 'utf8')) : {};
DATA.accounts ??= {};
DATA.logs ??= {};
DATA.settings ??= { competitionOpen: false, vaultOpen: false, updatedAt: 0 };
let saveTimer = null;
const saveData = () => {
  clearTimeout(saveTimer);
  saveTimer = setTimeout(() => writeFileSync(DATA_FILE, JSON.stringify(DATA)), 300);
};
const ADMIN_FILE = existsSync(join(here, 'admin.json')) ? JSON.parse(readFileSync(join(here, 'admin.json'), 'utf8')) : {};
const ADMIN_USER = process.env.ADMIN_USER || ADMIN_FILE.user;
const ADMIN_PASS = process.env.ADMIN_PASS || ADMIN_FILE.pass;
const SOLUTIONS = existsSync(join(here, 'solutions.json')) ? JSON.parse(readFileSync(join(here, 'solutions.json'), 'utf8')) : {};
const nameKey = (s) => String(s).normalize('NFKC').trim().replace(/\s+/g, ' ').toLowerCase();
const teamIdFor = (name) => 't' + createHash('sha256').update(`ctf360-team::${nameKey(name)}`).digest('hex').slice(0, 20);
const hashPw = (pw, salt) => scryptSync(String(pw), salt, 32).toString('hex');
const eq = (a, b) => {
  const x = Buffer.from(String(a));
  const y = Buffer.from(String(b));
  return x.length === y.length && timingSafeEqual(x, y);
};
const SESS = new Map(); // token -> { kind: 'team'|'admin', id, exp }
const newToken = (kind, id) => {
  const tk = randomBytes(24).toString('hex');
  SESS.set(tk, { kind, id, exp: Date.now() + 12 * 3600_000 });
  return tk;
};
const who = (req) => {
  const tk = (req.headers.authorization || '').replace(/^Bearer /, '');
  const s = SESS.get(tk);
  if (!s || s.exp < Date.now()) return null;
  return s;
};
const SPECS = ['net', 'web', 'support', 'marketing', 'office', 'other'];
const cleanProfile = (id, b) => ({
  id,
  name: String(b.name || '').trim().slice(0, 32),
  avatar: String(b.avatar || 'hat-white').slice(0, 24),
  members: (Array.isArray(b.members) ? b.members : []).slice(0, 6).map((m) => ({
    name: String(m?.name || '').slice(0, 40),
    spec: SPECS.includes(m?.spec) ? m.spec : 'other',
    specOther: m?.specOther ? String(m.specOther).slice(0, 40) : undefined,
    emoji: m?.emoji ? String(m.emoji).slice(0, 16) : undefined,
  })),
  createdAt: Date.now(),
});

const MIME = {
  '.html': 'text/html; charset=utf-8',
  '.js': 'text/javascript; charset=utf-8',
  '.css': 'text/css; charset=utf-8',
  '.svg': 'image/svg+xml',
  '.png': 'image/png',
  '.woff2': 'font/woff2',
  '.woff': 'font/woff',
  '.json': 'application/json',
};

// Small in-memory throttle so the facilitator code can't be brute-forced quickly.
const tries = new Map();
function throttled(ip, bucket = 'admin', limit = 10) {
  const key = `${bucket}:${ip}`;
  const now = Date.now();
  const t = (tries.get(key) || []).filter((x) => now - x < 60_000);
  t.push(now);
  tries.set(key, t);
  return t.length > limit;
}

function readJson(req) {
  return new Promise((resolve) => {
    let body = '';
    req.on('data', (c) => {
      body += c;
      if (body.length > 4096) req.destroy();
    });
    req.on('end', () => {
      try {
        resolve(JSON.parse(body || '{}'));
      } catch {
        resolve({});
      }
    });
  });
}

function send(res, status, obj) {
  res.writeHead(status, { 'Content-Type': 'application/json', 'Cache-Control': 'no-store' });
  res.end(JSON.stringify(obj));
}

const server = createServer(async (req, res) => {
  const url = new URL(req.url || '/', 'http://local');

  if (req.method === 'POST' && url.pathname === '/api/validate') {
    const { challengeId, stage, answer } = await readJson(req);
    const st = ANSWERS[challengeId]?.[Number(stage)];
    if (!st || typeof answer !== 'string') return send(res, 200, { correct: false });
    const n = normalize(answer, st.mode);
    const correct = st.accept.some((a) => normalize(a, st.mode) === n);
    return send(res, 200, { correct });
  }

  // ── accounts ──
  if (req.method === 'GET' && url.pathname === '/api/settings') return send(res, 200, DATA.settings);
  if (req.method === 'POST' && url.pathname === '/api/name-taken') {
    const { name } = await readJson(req);
    return send(res, 200, { taken: !!DATA.accounts[teamIdFor(name || '')] });
  }
  if (req.method === 'POST' && url.pathname === '/api/register') {
    if (throttled(req.socket.remoteAddress || '?', 'team', 60)) return send(res, 429, { ok: false, code: 'error' });
    const b = await readJson(req);
    if (!b.name || !String(b.name).trim() || typeof b.password !== 'string' || b.password.length < 8 || !Array.isArray(b.members) || !b.members.length)
      return send(res, 200, { ok: false, code: 'invalid' });
    const id = teamIdFor(b.name);
    if (DATA.accounts[id]) return send(res, 200, { ok: false, code: 'taken' });
    const salt = randomBytes(16).toString('hex');
    const profile = cleanProfile(id, b);
    DATA.accounts[id] = { profile, pass: { alg: 'scrypt', salt, hash: hashPw(b.password, salt) } };
    saveData();
    // on the board straight away, even with 0 points
    TEAMS[id] = { id, name: profile.name, avatar: profile.avatar, members: profile.members.map((m) => `${m.emoji ? m.emoji + ' ' : ''}${m.name}`), score: 0, solved: 0, total: 10, hints: 0, trainScore: 0, startedAt: Date.now(), scoredAt: Date.now(), finishedAt: null, updatedAt: Date.now() };
    saveTeams();
    return send(res, 200, { ok: true, team: profile, token: newToken('team', id) });
  }
  if (req.method === 'POST' && url.pathname === '/api/login') {
    if (throttled(req.socket.remoteAddress || '?', 'team', 60)) return send(res, 429, { ok: false, code: 'error' });
    const { name, password } = await readJson(req);
    const acc = DATA.accounts[teamIdFor(name || '')];
    if (!acc || !eq(hashPw(password || '', acc.pass.salt), acc.pass.hash)) return send(res, 200, { ok: false, code: 'bad' });
    return send(res, 200, { ok: true, team: acc.profile, saved: DATA.logs[acc.profile.id]?.saved ?? null, token: newToken('team', acc.profile.id) });
  }
  if (req.method === 'POST' && url.pathname === '/api/progress') {
    const s = who(req);
    if (!s || s.kind !== 'team') return send(res, 401, { ok: false });
    const { saved, events } = await readJson(req);
    const cur = DATA.logs[s.id] ?? { events: [] };
    const evs = (Array.isArray(events) ? events : []).slice(0, 200).map((e) => {
      // Re-check competition answers here so the log can't claim a fake solve.
      let ok = !!e.ok;
      const st = ANSWERS[e.cid]?.[Number(e.stage)];
      if (e.area === 'comp' && st && typeof e.answer === 'string') ok = st.accept.some((a) => normalize(a, st.mode) === normalize(e.answer, st.mode));
      return { t: Number(e.t) || Date.now(), area: e.area === 'train' ? 'train' : 'comp', cid: String(e.cid).slice(0, 40), stage: e.stage, kind: String(e.kind).slice(0, 10), answer: e.answer === undefined ? undefined : String(e.answer).slice(0, 200), ok: e.ok === undefined ? undefined : ok, pts: Number(e.pts) || 0 };
    });
    DATA.logs[s.id] = { saved: saved && typeof saved === 'object' ? saved : cur.saved, events: [...cur.events, ...evs].slice(-800), updatedAt: Date.now() };
    saveData();
    return send(res, 200, { ok: true });
  }

  // ── admin ──
  if (req.method === 'POST' && url.pathname === '/api/admin/login') {
    if (throttled(req.socket.remoteAddress || '?')) return send(res, 429, { ok: false });
    const { user, pass } = await readJson(req);
    const ok = eq(nameKey(user || ''), nameKey(ADMIN_USER)) && eq(pass || '', ADMIN_PASS);
    return send(res, 200, ok ? { ok: true, token: newToken('admin', 'admin') } : { ok: false });
  }
  if (url.pathname.startsWith('/api/admin/')) {
    const s = who(req);
    if (!s || s.kind !== 'admin') return send(res, 401, { ok: false });
    if (req.method === 'GET' && url.pathname === '/api/admin/overview') {
      const teams = Object.values(DATA.accounts).map((a) => ({ profile: a.profile, saved: DATA.logs[a.profile.id]?.saved ?? null, events: DATA.logs[a.profile.id]?.events ?? [] }));
      const solutions = Object.fromEntries(Object.entries(SOLUTIONS).filter(([k]) => !k.startsWith('_')).map(([k, v]) => [k, { id: k, ...v }]));
      return send(res, 200, { teams, solutions, settings: DATA.settings });
    }
    if (req.method === 'GET' && url.pathname === '/api/admin/solution') {
      const id = url.searchParams.get('id') || '';
      const v = SOLUTIONS[id];
      return send(res, 200, v && !id.startsWith('_') ? { ok: true, solution: { id, ...v } } : { ok: false });
    }
    const b = await readJson(req);
    if (url.pathname === '/api/admin/settings') {
      const opening = !!b.competitionOpen && !DATA.settings.competitionOpen;
      DATA.settings = { competitionOpen: !!b.competitionOpen, vaultOpen: !!b.vaultOpen, openedAt: opening ? Date.now() : DATA.settings.openedAt ?? 0, updatedAt: Date.now() };
      saveData();
      return send(res, 200, { ok: true });
    }
    if (url.pathname === '/api/admin/delete-team') {
      delete DATA.accounts[b.id];
      delete DATA.logs[b.id];
      delete TEAMS[b.id];
      saveData();
      saveTeams();
      return send(res, 200, { ok: true });
    }
    if (url.pathname === '/api/admin/reset-all') {
      DATA.accounts = {};
      DATA.logs = {};
      TEAMS = {};
      saveData();
      saveTeams();
      return send(res, 200, { ok: true });
    }
    if (url.pathname === '/api/admin/reset-password') {
      const acc = DATA.accounts[b.id];
      if (!acc || typeof b.password !== 'string' || b.password.length < 8) return send(res, 200, { ok: false });
      const salt = randomBytes(16).toString('hex');
      acc.pass = { alg: 'scrypt', salt, hash: hashPw(b.password, salt) };
      saveData();
      return send(res, 200, { ok: true });
    }
    return send(res, 404, { ok: false });
  }

  // ── leaderboard ──
  if (url.pathname === '/api/teams' && req.method === 'GET') return send(res, 200, Object.values(TEAMS));
  if (url.pathname === '/api/teams' && req.method === 'POST') {
    const t = await readJson(req);
    const s = who(req);
    if (!s || s.kind !== 'team' || !t || s.id !== t.id || typeof t.name !== 'string') return send(res, 401, { ok: false });
    TEAMS[t.id] = {
      id: t.id,
      name: String(t.name).slice(0, 32),
      members: Array.isArray(t.members) ? t.members.slice(0, 6).map((m) => String(m).slice(0, 32)) : [],
      avatar: String(t.avatar || '').slice(0, 24),
      trainScore: Number(t.trainScore) || 0,
      score: Math.max(0, Math.min(5000, Number(t.score) || 0)),
      solved: Number(t.solved) || 0,
      total: Number(t.total) || 10,
      hints: Number(t.hints) || 0,
      startedAt: Number(t.startedAt) || Date.now(),
      scoredAt: Number(t.scoredAt) || Date.now(),
      finishedAt: t.finishedAt ? Number(t.finishedAt) : null,
      updatedAt: Date.now(),
    };
    saveTeams();
    return send(res, 200, { ok: true });
  }
  if (url.pathname.startsWith('/api/teams/') && req.method === 'DELETE') {
    const s = who(req);
    if (!s || s.kind !== 'admin') return send(res, 401, { ok: false });
    delete TEAMS[decodeURIComponent(url.pathname.slice('/api/teams/'.length))];
    saveTeams();
    return send(res, 200, { ok: true });
  }

  if (req.method === 'POST' && url.pathname === '/api/facilitator') {
    if (throttled(req.socket.remoteAddress || '?')) return send(res, 429, { ok: false });
    const { code } = await readJson(req);
    if (!CODE || typeof code !== 'string') return send(res, 200, { ok: false });
    const a = Buffer.from(code);
    const b = Buffer.from(CODE);
    return send(res, 200, { ok: a.length === b.length && timingSafeEqual(a, b) });
  }

  // Static files (hash routing means everything else is index.html).
  let file = normPath(join(DIST, decodeURIComponent(url.pathname)));
  if (!file.startsWith(DIST)) return send(res, 403, { error: 'forbidden' });
  if (!existsSync(file) || statSync(file).isDirectory()) file = join(DIST, 'index.html');
  if (!existsSync(file)) {
    res.writeHead(500, { 'Content-Type': 'text/plain' });
    return res.end('dist/ not found — run `npm run build:server` first.');
  }
  res.writeHead(200, { 'Content-Type': MIME[extname(file)] || 'application/octet-stream' });
  createReadStream(file).pipe(res);
});

server.listen(PORT, () => {
  console.log(`CTF360 server on http://localhost:${PORT}`);
  if (!CODE) console.log('FACILITATOR_CODE is not set — the facilitator screen will stay locked.');
});
