# DERA CTF — معسكر تدريبي + المسابقة النهائية

Two parts in one site:

1. **Training camp (`#/home`, `#/train`)** — a CTF board: 18 new beginner challenges (185 pts) in
   5 categories — Warm-up, Networking (IP / Gateway / DNS / devices), IT Support (diagnose & pick the fix),
   Cyber Clues (logs, sender domain, file extensions) and Simple Code (print / variables). They practise
   the concepts the session teaches; none of them repeats a slide example. Data: `src/data/training.ts`.
   Progress stays on the device. Answers live in `server/training-answers.json` (organizer copy) and are
   shipped only as salted SHA-256 hashes (`src/data/trainKeys.generated.ts`, `npm run hashes`).
   Note: the evidence itself is on screen by design, so treat this as practice, not as a secured contest.
2. **Final competition (`#/intro` → `#/hub`)** — the team escape room with the shared leaderboard.
   The menu item **«المسابقة النهائية»** opens it.

All flags use the format `DERA{...}` (case-insensitive, spaces ignored). Training answer key: see
`server/training-answers.json`.


## Publishing (GitHub Pages + Supabase)

See **DEPLOY-AR.md**. The ready-built site is in `docs/`; the shared database is Supabase
(`supabase/setup.sql`), configured at runtime in `docs/backend-config.js` (public URL + publishable/anon key).
Back-end selection: server build → Node server; `backend-config.js` filled → Supabase; inside claude.ai → artifact database; otherwise this browser only.

## Organizer files (not in the repository)

These stay private and are listed in `.gitignore`:
`server/answers.json`, `server/training-answers.json`, `server/solutions.json`, `server/admin.json`
(see `server/admin.example.json`), and the live data `server/data.json` / `server/teams.json`.
Without them `npm run build` still works: it uses the committed salted hashes in `src/data/*.generated.ts`.
To change answers or the admin login, put the files back in `server/` and run `npm run hashes`.

## Team accounts, final-round lock and the admin dashboard

- **`#/register`**: team name, a picture (cyber-security hats or emojis), 1–5 members, each member's
  specialization (network systems, web programming, IT support, other: marketing / office admin / free text),
  and a password with a live strength meter. Passwords are stored only as salted hashes
  (PBKDF2-SHA-256 in the browser back-ends, scrypt on the server).
- **Final competition (`#/intro`)**: teams sign in with **team name + password only**; progress is restored
  on any device.
- **Lock**: the final competition and the final vault are **closed by default**. Only the admin can enter
  while closed; she opens them from the dashboard and team screens unlock live.
- **`#/admin`**: admin sign-in (credentials in `server/admin.json`; the browser only gets a salted PBKDF2 hash,
  run `npm run hashes` after changing it). It shows teams, members and their profiles and specializations,
  training and competition scores, level, every challenge's status, the first team to solve each one,
  the answers each team submitted (right and wrong, in order), and the official solution.

Where the data lives:

| Mode | Accounts & activity log | Who can read them |
|---|---|---|
| Published artifact (`db`) | `secure/v1/...` documents | admin level only (the owner), enforced by the published access rules |
| Server (`npm run build:server` + `npm run serve`) | `server/data.json` | the server only; admin API needs the admin token |
| Local | this browser | this browser |

On the published artifact, visitors who open it through a public link have **view** access and can't
write to the database, so registration and progress saving only work on devices signed in as the
owner (e.g. the exhibition laptops). For teams playing on their own phones, run the server version.

Partner logos in `public/assets/` were cropped unaltered from the session PDF.

---

# Final competition — غرفة الهروب السيبرانية · Cyber Escape Room

**#لا_تفتح_مجال** · افتح التحدي، لا تفتح المجال · *Open the Challenge. Don't Open the Door.*

An interactive, bilingual (Arabic-first, RTL) cybersecurity CTF for the October exhibition by
**Dera 360 Cybersecurity Association** in collaboration with **TVTC — Technical College in Buraidah**.

Visitors pick an anonymous codename, clear three haunted rooms (IT support, networking, code
forensics — 9 challenges), collect three evidence fragments, and open the final vault to restore the system.

---

## 1. Install & run

Requires **Node.js 22.18+** (scripts use Node's built-in TypeScript support).

```bash
npm install
npm run dev        # development server → http://localhost:5173
npm run build      # production build into dist/ (also regenerates answer hashes)
npm run preview    # serve the built site → http://localhost:4173
npm test           # checks every challenge has a valid answer path, wrong answers are rejected
```

No internet connection is needed to play: fonts, logos, sounds (Web Audio synthesis) and all
challenge logic are local. No analytics, tracking or logins.

## 2. Using it at the exhibition

- **Exhibition mode** — ⚙ Settings → *Exhibition mode: On*. Larger text, bigger touch targets,
  a red **Next visitor** button in the header, and an idle guard (after ~2.5 min without input it
  offers a fresh session, resetting after a 20 s countdown).
- **Quick start** on the intro screen skips the codename step (random codename).
- **Skip intro** button is always visible during the intro.
- **Sound** is off until a visitor presses *Enable sound*. **Motion**: System / Reduced / Full in Settings.
- **Facilitator screen** — Settings → Facilitator, or `Ctrl + Shift + F` (`#/facilitator`).
  Shows the session, every challenge's status/points/hints/wrong attempts, explanations, and buttons
  to reset or start a fresh visitor. In the static build it is clearly labelled **local demo controls**
  (no password — a password in frontend code would not be secret). See §6 for a protected version.

### Resetting the game
- Header **Reset / Next visitor** button → confirm, or
- Facilitator → *Start a fresh visitor*, or
- Clear site data / `localStorage` keys `ctf360.session.v1` (progress) and `ctf360.prefs.v1` (settings).

Progress is stored **only on this device** (localStorage). There is no shared leaderboard.

## 3. Where things live

| What | File |
|---|---|
| Challenge text, hints, explanations, points, scenes (AR + EN) | `src/data/challenges.ts` |
| Rooms: names, stories, evidence fragments, incident reports | `src/data/rooms.ts` |
| Interface text (buttons, intro, labels) AR + EN | `src/data/ui.ts` |
| **Answer key (plaintext, organizer only)** | `server/answers.json` |
| Generated salted hashes shipped to the browser | `src/data/answerKeys.generated.ts` (do not edit) |
| Scoring rules (hint penalty, cooldown, time cap) | `src/engine/scoring.ts` |
| Answer normalization (case, spaces, Arabic digits, punctuation) | `src/engine/normalize.ts` |
| Rendering: one renderer for all challenges | `src/components/challenge/ChallengeRenderer.tsx` |
| Official logos (cropped from the supplied reference, not redrawn) | `public/assets/` |
| Styles / design tokens | `src/styles/global.css` |

### Editing Arabic / English text
Every string is an object `{ ar: '…', en: '…' }`. Edit both sides in `challenges.ts`, `rooms.ts`
or `ui.ts`. Arabic is the default language; RTL/LTR switches automatically.

### Changing answers
1. Edit `server/answers.json`. Each challenge is a list of **stages**; each stage has a normalization
   `mode` (`id`, `text`, `phrase`, `flag`) and the accepted answers.
   - `text`: case-insensitive, extra spaces ignored, punctuation kept (passwords).
   - `phrase`: like text, punctuation ignored.
   - `flag`: all whitespace removed, case-insensitive. Flags use the format `CTF360{…}`.
2. If an answer is visible in a challenge (desk clues, code, encoded strings), update that content in
   `challenges.ts` too so the challenge stays solvable.
3. Run `npm run hashes` (or just `npm run build`) and `npm test`.

### Changing scoring
`basePoints` per challenge in `challenges.ts` (easy 100, medium 150, final 200 = 1300 max).
`HINT_PENALTY` (25% per hint, max 2 hints), `WRONG_COOLDOWN_MS` and `OVERTIME_CAP` in `scoring.ts`.
`timeLimitSec` is optional per challenge (used by *Firewall Guard*: after 2 min it's worth ≤50%).
Points are awarded once per challenge — re-solving is impossible once solved.

## 4. Tracks & challenges — CASE_001: a staff account was breached

Three tracks (no specialisation labels shown to players), three beginner-friendly challenges each,
then a final vault. Every solved challenge shows a capture flag.

| Track | Challenge | Mechanic |
|---|---|---|
| 01 · The Urgent Ticket | The Phishing Email | tap the 3 red flags in an email (sender domain, link, urgency) |
| | The Support Hotline | three calls — paper jam, a compromised user, a social-engineering caller |
| | The Password | spot why `Razan123` is dangerous, then build a strong password (live meter) |
| 02 · The Hidden Intruder | The Broken Link | read the ping log, tap the broken cable, pick the first fix |
| | Firewall Guard | 6 packets arrive one by one — allow or block (3-minute timer) |
| | The Evil-Twin Wi-Fi | pick the official network among look-alikes, then say why the free one is risky |
| 03 · The Forgotten Key | The Alarm Script | tap the buggy Python line and choose the fix |
| | Trace the Code | predict a PIN-guessing loop's output, then choose the defence |
| | The Hidden Key | tap encoded strings in a config file, decode Base64, submit the flag |
| Final Vault | Uncover the Breach | find the dangerous login, order the 4 attack steps, assemble `CTF360{…}` |

Max score: 1250.

## 4b. Teams & leaderboard

Teams register on the intro screen: a team name (unique) and 1–5 member names. No email or phone.
Points are pushed to the leaderboard after every solve. Ranking: points, then the shorter time to
reach that score, then whoever reached it first.

- `#/leaderboard` — podium + full table. `#/leaderboard/tv` — big-screen display for a projector.
- Header **Next team** button starts a new team on the same device; the previous team stays on the board.
- Facilitator screen lists all teams with **Remove team** / **Clear all teams**.

Where the board is stored (shown as a badge on the board):

| Mode | When | Shared between devices? |
|---|---|---|
| shared | the published claude.ai page (artifact database) | yes, live |
| server | `npm run build:server` + `npm run serve` (`server/teams.json`) | yes (polls every 5 s) |
| local | static build opened on its own | no — one kiosk device only |

Scores are reported by the players' browsers, so a technical visitor could fake a score. Fine for an
exhibition; for a competition use server mode with server-side scoring.

## 5. Deploying the static version

`npm run build` → upload the `dist/` folder to any static host (Netlify, GitHub Pages, S3, a USB stick,
an internal web server). The build uses relative paths and hash routing, so it works from a sub-folder
and directly from `file://` too.

## 6. Limitations of client-side validation — read this

In the static build, answers are checked **in the browser** against salted SHA-256 hashes.
The plaintext answers are not shipped, but:
- anyone with developer tools can read the challenge data, the hashes, and evidence fragments, and
  multiple-choice answers can be brute-forced from the hashes trivially;
- localStorage progress and scores can be edited by the visitor.

That is fine for an educational exhibition kiosk. **Do not use the static build for a competitive CTF.**

### Optional server mode (private deployments)
```bash
npm run build:server                       # build with NO answer hashes in the bundle
FACILITATOR_CODE=choose-a-code PORT=8360 npm run serve
```
`server/server.mjs` (no dependencies) serves `dist/` and answers `POST /api/validate` from
`server/answers.json`, and protects the facilitator screen with `FACILITATOR_CODE` (throttled,
constant-time compare). Evidence fragments and visible challenge content still live in the client.
Set `VITE_API_BASE` at build time if the API runs on another origin.

## 7. Branding
Official name: **CTF360**. Partner logos (Dera 360, TVTC / Technical College in Buraidah) and the
«لا تفتح مجال» campaign graphic were cropped unaltered from the supplied reference image and are shown
on a light plate to preserve their colours. For sharper print output, replace the files in
`public/assets/` with the original high-resolution logo files (keep the same names).
