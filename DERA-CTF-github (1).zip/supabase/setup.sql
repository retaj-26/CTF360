-- ═══════════════════════════════════════════════════════════════════════════
--  DERA CTF — Supabase database (run once in Supabase → SQL Editor → Run)
--
--  • public.leaderboard / public.settings : readable by everyone (the live board)
--  • ctf_private.*                         : NOT exposed by the API — accounts,
--                                            password hashes, logs, admin, solutions
--  • every write goes through the functions below (SECURITY DEFINER), so the
--    public key in the website can't edit tables directly.
--  Safe to run again: it only creates what is missing and replaces the functions.
-- ═══════════════════════════════════════════════════════════════════════════
create extension if not exists pgcrypto with schema extensions;

create schema if not exists ctf_private;
revoke all on schema ctf_private from anon, authenticated;

-- ── public, read-only for visitors ──────────────────────────────────────────
create table if not exists public.leaderboard (
  id          text primary key,
  name        text not null,
  avatar      text default '',
  members     jsonb default '[]'::jsonb,
  score       int  default 0,
  solved      int  default 0,
  total       int  default 10,
  hints       int  default 0,
  train_score int  default 0,
  started_at  bigint default 0,
  scored_at   bigint default 0,
  finished_at bigint,
  updated_at  bigint default 0
);
alter table public.leaderboard enable row level security;
drop policy if exists "leaderboard is public" on public.leaderboard;
create policy "leaderboard is public" on public.leaderboard for select using (true);

create table if not exists public.settings (
  id int primary key default 1 check (id = 1),
  competition_open boolean default false,
  vault_open       boolean default false,
  opened_at        bigint  default 0,
  updated_at       bigint  default 0
);
insert into public.settings (id) values (1) on conflict do nothing;
alter table public.settings enable row level security;
drop policy if exists "settings are public" on public.settings;
create policy "settings are public" on public.settings for select using (true);

grant select on public.leaderboard, public.settings to anon, authenticated;
revoke insert, update, delete on public.leaderboard, public.settings from anon, authenticated;

-- ── private ─────────────────────────────────────────────────────────────────
create table if not exists ctf_private.accounts (
  id         text primary key,
  name_key   text unique not null,
  profile    jsonb not null,
  pass_hash  text not null,
  created_at timestamptz default now()
);
create table if not exists ctf_private.sessions (
  token      text primary key,
  kind       text not null,          -- 'team' | 'admin'
  subject    text not null,          -- team id or admin username
  expires_at timestamptz not null
);
create table if not exists ctf_private.logs (
  team_id    text primary key,
  saved      jsonb,
  events     jsonb default '[]'::jsonb,
  updated_at timestamptz default now()
);
create table if not exists ctf_private.admins (
  username_key text primary key,
  pass_hash    text not null
);
create table if not exists ctf_private.solutions (
  id     text primary key,
  answer text not null,
  steps  jsonb default '[]'::jsonb
);

-- ── helpers ─────────────────────────────────────────────────────────────────
create or replace function ctf_private.name_key(p text) returns text
language sql immutable as $$
  select lower(regexp_replace(btrim(normalize(coalesce(p, ''), NFKC)), '\s+', ' ', 'g'))
$$;

create or replace function ctf_private.team_id(p text) returns text
language sql immutable as $$
  select 't' || substr(encode(extensions.digest('ctf360-team::' || ctf_private.name_key(p), 'sha256'), 'hex'), 1, 20)
$$;

create or replace function ctf_private.new_session(p_kind text, p_subject text) returns text
language plpgsql security definer set search_path = ctf_private, public, extensions as $$
declare tk text := encode(extensions.gen_random_bytes(24), 'hex');
begin
  delete from ctf_private.sessions where expires_at < now();
  insert into ctf_private.sessions values (tk, p_kind, p_subject, now() + interval '12 hours');
  return tk;
end $$;

create or replace function ctf_private.session_subject(p_token text, p_kind text) returns text
language sql stable security definer set search_path = ctf_private, public as $$
  select subject from ctf_private.sessions where token = p_token and kind = p_kind and expires_at > now()
$$;

create or replace function ctf_private.clean_members(p jsonb) returns jsonb
language sql immutable as $$
  select coalesce(jsonb_agg(jsonb_build_object(
           'name', left(coalesce(m->>'name', ''), 40),
           'spec', case when m->>'spec' in ('net','web','support','marketing','office','other') then m->>'spec' else 'other' end,
           'specOther', left(m->>'specOther', 40),
           'emoji', left(m->>'emoji', 16))), '[]'::jsonb)
  from (select value as m from jsonb_array_elements(coalesce(p, '[]'::jsonb)) limit 6) s
$$;

-- ── team API ────────────────────────────────────────────────────────────────
create or replace function public.ctf_register(p_name text, p_avatar text, p_members jsonb, p_password text)
returns jsonb language plpgsql security definer set search_path = ctf_private, public, extensions as $$
declare
  k text := ctf_private.name_key(p_name);
  tid text := ctf_private.team_id(p_name);
  prof jsonb;
  mem jsonb := ctf_private.clean_members(p_members);
  now_ms bigint := (extract(epoch from now()) * 1000)::bigint;
begin
  if k = '' or length(k) > 32 or p_password is null or length(p_password) < 8 or jsonb_array_length(mem) < 1 then
    return jsonb_build_object('ok', false, 'code', 'invalid');
  end if;
  if exists (select 1 from ctf_private.accounts where name_key = k) then
    return jsonb_build_object('ok', false, 'code', 'taken');
  end if;
  prof := jsonb_build_object('id', tid, 'name', left(btrim(p_name), 32), 'avatar', left(coalesce(p_avatar, 'hat-white'), 24),
                             'members', mem, 'createdAt', now_ms);
  insert into ctf_private.accounts (id, name_key, profile, pass_hash)
    values (tid, k, prof, extensions.crypt(p_password, extensions.gen_salt('bf', 10)));
  -- every registered team is on the board straight away, even with 0 points
  insert into public.leaderboard (id, name, avatar, members, started_at, scored_at, updated_at)
    values (tid, prof->>'name', prof->>'avatar',
            (select coalesce(jsonb_agg(btrim(coalesce(m->>'emoji','') || ' ' || (m->>'name'))), '[]'::jsonb) from jsonb_array_elements(mem) m),
            now_ms, now_ms, now_ms)
    on conflict (id) do nothing;
  return jsonb_build_object('ok', true, 'team', prof, 'token', ctf_private.new_session('team', tid));
end $$;

create or replace function public.ctf_name_taken(p_name text) returns boolean
language sql stable security definer set search_path = ctf_private, public as $$
  select exists (select 1 from ctf_private.accounts where name_key = ctf_private.name_key(p_name))
$$;

create or replace function public.ctf_login(p_name text, p_password text)
returns jsonb language plpgsql security definer set search_path = ctf_private, public, extensions as $$
declare a record;
begin
  select * into a from ctf_private.accounts where name_key = ctf_private.name_key(p_name);
  if a is null or a.pass_hash <> extensions.crypt(coalesce(p_password, ''), a.pass_hash) then
    perform pg_sleep(0.4);
    return jsonb_build_object('ok', false, 'code', 'bad');
  end if;
  return jsonb_build_object('ok', true, 'team', a.profile,
    'saved', (select saved from ctf_private.logs where team_id = a.id),
    'token', ctf_private.new_session('team', a.id));
end $$;

create or replace function public.ctf_save_progress(p_token text, p_saved jsonb, p_events jsonb)
returns boolean language plpgsql security definer set search_path = ctf_private, public as $$
declare tid text := ctf_private.session_subject(p_token, 'team');
begin
  if tid is null then return false; end if;
  insert into ctf_private.logs (team_id, saved, events, updated_at)
    values (tid, p_saved, coalesce(p_events, '[]'::jsonb), now())
  on conflict (team_id) do update set
    saved = coalesce(excluded.saved, ctf_private.logs.saved),
    events = (select coalesce(jsonb_agg(e order by n), '[]'::jsonb) from (
               select e, n from jsonb_array_elements(ctf_private.logs.events || coalesce(p_events, '[]'::jsonb)) with ordinality x(e, n)
               order by n desc limit 800) t),
    updated_at = now();
  return true;
end $$;

create or replace function public.ctf_save_row(p_token text, p_row jsonb)
returns boolean language plpgsql security definer set search_path = ctf_private, public as $$
declare tid text := ctf_private.session_subject(p_token, 'team');
begin
  if tid is null then return false; end if;
  update public.leaderboard set
    score       = greatest(0, least(1100, coalesce((p_row->>'score')::int, score))),
    solved      = greatest(0, least(20, coalesce((p_row->>'solved')::int, solved))),
    total       = coalesce((p_row->>'total')::int, total),
    hints       = coalesce((p_row->>'hints')::int, hints),
    train_score = greatest(0, least(1000, coalesce((p_row->>'trainScore')::int, train_score))),
    started_at  = coalesce((p_row->>'startedAt')::bigint, started_at),
    scored_at   = coalesce((p_row->>'scoredAt')::bigint, scored_at),
    finished_at = (p_row->>'finishedAt')::bigint,
    updated_at  = (extract(epoch from now()) * 1000)::bigint
  where id = tid;
  return true;
end $$;

-- ── admin API ───────────────────────────────────────────────────────────────
create or replace function public.ctf_admin_login(p_user text, p_pass text)
returns jsonb language plpgsql security definer set search_path = ctf_private, public, extensions as $$
declare a record;
begin
  select * into a from ctf_private.admins where username_key = ctf_private.name_key(p_user);
  if a is null or a.pass_hash <> extensions.crypt(coalesce(p_pass, ''), a.pass_hash) then
    perform pg_sleep(0.6);
    return jsonb_build_object('ok', false);
  end if;
  return jsonb_build_object('ok', true, 'token', ctf_private.new_session('admin', a.username_key));
end $$;

create or replace function public.ctf_admin_overview(p_token text)
returns jsonb language plpgsql security definer set search_path = ctf_private, public as $$
begin
  if ctf_private.session_subject(p_token, 'admin') is null then return jsonb_build_object('ok', false); end if;
  return jsonb_build_object('ok', true,
    'teams', (select coalesce(jsonb_agg(jsonb_build_object('profile', a.profile, 'saved', l.saved, 'events', coalesce(l.events, '[]'::jsonb))), '[]'::jsonb)
              from ctf_private.accounts a left join ctf_private.logs l on l.team_id = a.id),
    'solutions', (select coalesce(jsonb_object_agg(id, jsonb_build_object('id', id, 'answer', answer, 'steps', steps)), '{}'::jsonb) from ctf_private.solutions));
end $$;

create or replace function public.ctf_admin_solution(p_token text, p_id text)
returns jsonb language plpgsql security definer set search_path = ctf_private, public as $$
declare s record;
begin
  if ctf_private.session_subject(p_token, 'admin') is null then return jsonb_build_object('ok', false); end if;
  select * into s from ctf_private.solutions where id = p_id;
  if s is null then return jsonb_build_object('ok', false); end if;
  return jsonb_build_object('ok', true, 'solution', jsonb_build_object('id', s.id, 'answer', s.answer, 'steps', s.steps));
end $$;

create or replace function public.ctf_admin_settings(p_token text, p_open boolean, p_vault boolean)
returns boolean language plpgsql security definer set search_path = ctf_private, public as $$
declare now_ms bigint := (extract(epoch from now()) * 1000)::bigint;
begin
  if ctf_private.session_subject(p_token, 'admin') is null then return false; end if;
  update public.settings set
    opened_at = case when p_open and not competition_open then now_ms else opened_at end,
    competition_open = p_open, vault_open = p_vault, updated_at = now_ms
  where id = 1;
  return true;
end $$;

create or replace function public.ctf_admin_delete_team(p_token text, p_id text)
returns boolean language plpgsql security definer set search_path = ctf_private, public as $$
begin
  if ctf_private.session_subject(p_token, 'admin') is null then return false; end if;
  delete from ctf_private.accounts where id = p_id;
  delete from ctf_private.logs where team_id = p_id;
  delete from ctf_private.sessions where kind = 'team' and subject = p_id;
  delete from public.leaderboard where id = p_id;
  return true;
end $$;

create or replace function public.ctf_admin_reset_password(p_token text, p_id text, p_password text)
returns boolean language plpgsql security definer set search_path = ctf_private, public, extensions as $$
begin
  if ctf_private.session_subject(p_token, 'admin') is null or length(coalesce(p_password, '')) < 8 then return false; end if;
  update ctf_private.accounts set pass_hash = extensions.crypt(p_password, extensions.gen_salt('bf', 10)) where id = p_id;
  return found;
end $$;

-- Wipes every team (accounts, logs, board). Use before the real event.
create or replace function public.ctf_admin_reset_all(p_token text)
returns boolean language plpgsql security definer set search_path = ctf_private, public as $$
begin
  if ctf_private.session_subject(p_token, 'admin') is null then return false; end if;
  delete from ctf_private.logs;
  delete from ctf_private.sessions where kind = 'team';
  delete from ctf_private.accounts;
  delete from public.leaderboard;
  return true;
end $$;

-- only the API functions are callable from the website
revoke all on all functions in schema ctf_private from public, anon, authenticated;
revoke all on function public.ctf_register, public.ctf_name_taken, public.ctf_login, public.ctf_save_progress, public.ctf_save_row,
  public.ctf_admin_login, public.ctf_admin_overview, public.ctf_admin_solution, public.ctf_admin_settings,
  public.ctf_admin_delete_team, public.ctf_admin_reset_password, public.ctf_admin_reset_all from public;
grant execute on function public.ctf_register, public.ctf_name_taken, public.ctf_login, public.ctf_save_progress, public.ctf_save_row,
  public.ctf_admin_login, public.ctf_admin_overview, public.ctf_admin_solution, public.ctf_admin_settings,
  public.ctf_admin_delete_team, public.ctf_admin_reset_password, public.ctf_admin_reset_all to anon, authenticated;
