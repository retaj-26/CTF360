# نشر DERA CTF على GitHub Pages مع لوحة ترتيب حقيقية

الموقع يتنشر من مجلد `docs` (جاهز ومبني). لوحة الترتيب والحسابات تنحفظ في قاعدة بيانات
**Supabase** المجانية، عشان أي فريق يسجّل من أي جوال يطلع للكل مباشرة — حتى لو نقاطه صفر.

## ١) قاعدة البيانات (مرة وحدة · ٥ دقايق)
1. ادخلي https://supabase.com وسوّي حساب مجاني ← **New project** (أي اسم، مثل `dera-ctf`).
2. من القائمة الجانبية: **SQL Editor** ← **New query** ← الصقي محتوى الملف `supabase/setup.sql` ← **Run**.
3. **New query** ثانية ← الصقي محتوى ملف `organizer-seed.sql` (الملف الخاص اللي عندك، فيه دخول المشرفة والحلول) ← **Run**.
   > لا ترفعين `organizer-seed.sql` على GitHub أبدًا.
4. **Project Settings ← API** (أو **API Keys**): انسخي
   - **Project URL** (شكله `https://xxxx.supabase.co`)
   - المفتاح العام: **publishable** (`sb_publishable_…`) أو **anon public** — هذا المفتاح مصمم يكون عام.
   > لا تنسخين **secret** أو **service_role** أبدًا.

## ٢) ربط الموقع بالقاعدة
في مستودع GitHub افتحي `docs/backend-config.js` ← أيقونة القلم ✏️ ← الصقي القيمتين:
```js
window.CTF360_BACKEND = {
  supabaseUrl: 'https://xxxx.supabase.co',
  supabaseAnonKey: 'sb_publishable_xxxxxxxx',
};
```
← **Commit changes**.

## ٣) تشغيل GitHub Pages
المستودع ← **Settings ← Pages** ← Source: **Deploy from a branch** ← Branch: `main` و المجلد `/docs` ← **Save**.
بعد دقيقة يصير الموقع على: `https://<اسم-حسابك>.github.io/<اسم-المستودع>/`

## ٤) قبل الفعالية
- ادخلي «تسجيل الدخول» باسم المشرفة ← لوحة المشرفة ← **تصفير لوحة الترتيب** (يمسح فرق التجربة).
- افتحي **المسابقة النهائية** من لوحتك وقت البداية (الوقت يُحسب من لحظة الفتح)، وافتحي **القبو الأخير** متى ما بغيتي.
- اعرضي لوحة الترتيب على الشاشة: `…/#/leaderboard/tv`

## تعديل الإجابات أو كلمة مرور المشرفة
عدّلي ملفات المنظِّمة (`server/answers.json` …) ثم `npm run hashes && npm run build` وانسخي `dist` إلى `docs`.
لتغيير كلمة مرور المشرفة: عدّلي `server/admin.json` ثم `node scripts/make-supabase-seed.ts` وشغّلي الملف الناتج في Supabase.
