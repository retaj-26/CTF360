// ───────────────────────────────────────────────────────────────────────────
//  DERA CTF — shared database settings (for GitHub Pages)
//  Paste your Supabase "Project URL" and "anon public" key below.
//  (Supabase → Project Settings → API). The anon key is meant to be public.
//  Leave both empty to run without a shared database.
// ───────────────────────────────────────────────────────────────────────────
window.CTF360_BACKEND = {
  supabaseUrl: '',
  supabaseAnonKey: '',
};
