import type { NormMode } from './normalize';

export type Lang = 'ar' | 'en';
/** A bilingual string. Every user-facing string in challenge data uses this. */
export type L10n = { ar: string; en: string };

/** intro = easy (guided, educational) · easy = easy-medium · medium = medium. */
export type Difficulty = 'intro' | 'easy' | 'medium';
export type Category = 'it-support' | 'networking' | 'programming' | 'final';
export type RoomId = 'helpdesk' | 'network' | 'code';

export type ChallengeType =
  | 'multiple-choice'
  | 'short-text'
  | 'flag'
  | 'diagram'
  | 'decoder'
  | 'code-inspection';

export interface Option {
  id: string;
  label: L10n;
  /** Optional small mono caption under the label (e.g. a filename or an IP). */
  mono?: string;
}

export interface ChoiceStage {
  kind: 'choice';
  prompt: L10n;
  options: Option[];
}

export interface TextStage {
  kind: 'text';
  prompt: L10n;
  placeholder: L10n;
  /** Monospace / LTR input (passwords, flags). */
  mono?: boolean;
}

/** A stage the scene itself answers (click a popup, a cable, a line of code). */
export interface PickStage {
  kind: 'pick';
  prompt: L10n;
}

export type Stage = ChoiceStage | TextStage | PickStage;

// ---------- Interactive payloads (one per scene) ----------

export interface PhishPayload {
  scene: 'phish';
  fromName: L10n;
  fromAddr: string;
  to: string;
  subject: L10n;
  date: string;
  /** Email body as segments; segments with an id are tappable hotspots. */
  body: { id?: string; text: L10n; mono?: boolean; block?: boolean }[];
  /** Hotspot ids that sit in the header (rendered there instead of the body). */
  headerHotspots: { from: string; date: string; subject: string };
  flagsToFind: number;
}

export interface CallsPayload {
  scene: 'calls';
  calls: { caller: L10n; role: L10n; message: L10n; mood: 'calm' | 'urgent' | 'suspicious' }[];
}

export interface PasswordPayload {
  scene: 'password';
  account: { username: string; password: string };
  reusedOn: L10n[];
  banned: string[];
  minLength: number;
}

export interface FirewallPayload {
  scene: 'firewall';
  packets: { from: L10n; to: L10n; port: string; service: string; note: L10n }[];
}

export interface DesktopPayload {
  scene: 'desktop';
  popups: { id: string; code: string; title: L10n; body: L10n; tone: 'warn' | 'err' | 'info' }[];
}

export interface NetworkPayload {
  scene: 'network';
  nodes: { id: string; label: L10n; ip: string }[];
  links: { id: string; from: string; to: string; broken?: boolean }[];
  pingLog: { target: string; ok: boolean }[];
}

export interface WifiPayload {
  scene: 'wifi';
  poster: { ssid: string; note: L10n };
  networks: { id: string; ssid: string; locked: boolean; bars: 1 | 2 | 3 | 4; tag?: L10n }[];
}

export interface SubnetPayload {
  scene: 'subnet';
  host: string;
  mask: string;
}

export interface DecoderPayload {
  scene: 'decoder';
  input: string;
  modes: ('morse' | 'hex' | 'base64')[];
  defaultMode?: 'morse' | 'hex' | 'base64';
  requireDecode: boolean;
  signalLabel: L10n;
}

export interface CodePayload {
  scene: 'code';
  filename: string;
  language: 'python';
  lines: string[];
  pickableLines?: boolean;
  /** Static, pre-recorded output shown after solving — the code is never executed. */
  outputAfterSolve?: string[];
  /** Line (1-based) that is replaced after solving, to show the fix. */
  fixedLine?: { line: number; text: string };
}

export interface SecretPayload {
  scene: 'secret';
  filename: string;
  lines: string[];
}

export interface ChainPayload {
  scene: 'chain';
  log: { id: string; time: string; account: string; place: L10n; ip: string; device: string; ok: boolean }[];
  steps: { id: string; title: L10n; text: L10n }[];
  decoys: string[];
}

export type Payload =
  | PhishPayload
  | CallsPayload
  | PasswordPayload
  | FirewallPayload
  | DesktopPayload
  | NetworkPayload
  | SubnetPayload
  | WifiPayload
  | DecoderPayload
  | CodePayload
  | SecretPayload
  | ChainPayload;

export interface Challenge {
  id: string;
  room: RoomId | 'final';
  letter: 'A' | 'B' | 'C' | 'Ω';
  title: L10n;
  description: L10n;
  category: Category;
  difficulty: Difficulty;
  type: ChallengeType;
  payload: Payload;
  stages: Stage[];
  /** Feedback for wrong answers, keyed by option/target id or by a normalized typed answer. */
  wrongFeedback?: Record<string, L10n>;
  hints: [L10n, L10n];
  explanation: L10n;
  /** Short, funny Najdi intro line shown to teams. */
  bio?: L10n;
  /** Funny Najdi line shown to teams after solving (instead of the solution). */
  cheer?: L10n;
  /** Guided steps for the 'intro' (tutorial) challenge of each track. */
  tutorial?: L10n[];
  basePoints: number;
  /** Cosmetic flag shown when the challenge is captured (not used for validation). */
  reward?: string;
  /** Optional: after this many seconds the challenge is worth at most 50%. */
  timeLimitSec?: number;
  /** Optional: documented flag format for flag challenges. */
  flagFormat?: string;
}

export interface Room {
  id: RoomId;
  index: number;
  name: L10n;
  category: L10n;
  difficulty: L10n;
  minutes: string;
  story: L10n;
  teaser: L10n;
  accent: string;
  /** Lucide icon name used on the evidence envelope. */
  icon: 'headset' | 'network' | 'code';
  /** "Evidence 01" label on the envelope. */
  clue: L10n;
  challengeIds: string[];
  /** Evidence fragment revealed in the incident report when the room is cleared. */
  fragment: string;
  report: L10n;
  lesson: L10n;
}

export type AnswerKey = { mode: NormMode; hashes: string[] }[];
