// Team leaderboard storage. Three back-ends, picked at runtime:
//   shared — the claude.ai artifact database (every device that opens the published page)
//   server — server/server.mjs  (/api/teams), for private deployments
//   local  — this browser only (one kiosk laptop shared by all teams)
import { VALIDATION_MODE } from './validate';
import { SUPABASE_ON, rpc, select } from './supabase';

export interface TeamRecord {
  id: string;
  name: string;
  members: string[];
  avatar?: string;
  /** Training camp points (shown to the admin, not used for ranking). */
  trainScore?: number;
  score: number;
  solved: number;
  total: number;
  hints: number;
  startedAt: number;
  /** When the team reached its current score (tie-breaker: earlier wins). */
  scoredAt: number;
  finishedAt: number | null;
  updatedAt: number;
}

export type BoardMode = 'shared' | 'server' | 'local' | 'supabase';
type Listener = (teams: TeamRecord[]) => void;

const LOCAL_KEY = 'ctf360.board.v1';
const teamToken = () => {
  try {
    return (JSON.parse(localStorage.getItem('ctf360.team.v1') || 'null') as { token?: string } | null)?.token ?? '';
  } catch {
    return '';
  }
};
const API_BASE: string = import.meta.env.VITE_API_BASE ?? '';

export function rankTeams(teams: TeamRecord[]): TeamRecord[] {
  return [...teams].sort(
    (a, b) =>
      // highest score first, then whoever reached that score first (fastest)
      b.score - a.score ||
      a.scoredAt - b.scoredAt ||
      a.name.localeCompare(b.name),
  );
}

function clean(raw: unknown, id: string): TeamRecord | null {
  if (!raw || typeof raw !== 'object') return null;
  const r = raw as Record<string, unknown>;
  const num = (v: unknown, d = 0) => (typeof v === 'number' && Number.isFinite(v) ? v : d);
  const name = typeof r.name === 'string' ? r.name.slice(0, 32) : '';
  if (!name) return null;
  return {
    id,
    name,
    members: Array.isArray(r.members) ? r.members.filter((m) => typeof m === 'string').slice(0, 6).map((m) => (m as string).slice(0, 32)) : [],
    avatar: typeof r.avatar === 'string' ? r.avatar.slice(0, 24) : '',
    trainScore: num(r.trainScore),
    score: Math.max(0, Math.min(5000, num(r.score))),
    solved: num(r.solved),
    total: num(r.total, 10),
    hints: num(r.hints),
    startedAt: num(r.startedAt),
    scoredAt: num(r.scoredAt, num(r.startedAt)),
    finishedAt: typeof r.finishedAt === 'number' ? r.finishedAt : null,
    updatedAt: num(r.updatedAt),
  };
}

// ── local ──────────────────────────────────────────────────────────────────
function readLocal(): Record<string, TeamRecord> {
  try {
    return JSON.parse(localStorage.getItem(LOCAL_KEY) || '{}');
  } catch {
    return {};
  }
}
function writeLocal(all: Record<string, TeamRecord>) {
  try {
    localStorage.setItem(LOCAL_KEY, JSON.stringify(all));
  } catch {
    /* storage blocked */
  }
}

// ── shared (artifact db) ─────────────────────────────────────────────────────
type DbLike = {
  collection(p: string): {
    doc(id: string): { set(d: Record<string, unknown>): Promise<void>; delete(): Promise<void> };
    onSnapshot(next: (s: { docs: { id: string; data(): Record<string, unknown> | undefined }[] }) => void, err?: (e: { code: string }) => void): () => void;
  };
};

let dbPromise: Promise<DbLike | null> | null = null;
function getDb(): Promise<DbLike | null> {
  if (dbPromise) return dbPromise;
  const c = (window as unknown as { claude?: { use?: (n: string) => Promise<unknown> } }).claude;
  dbPromise = c?.use ? (c.use('db') as Promise<DbLike | null>).catch(() => null) : Promise.resolve(null);
  return dbPromise;
}

class Board {
  mode: BoardMode = VALIDATION_MODE === 'server' ? 'server' : SUPABASE_ON ? 'supabase' : 'local';
  /** True once a shared write was refused (e.g. a view-only visitor). */
  readOnly = false;
  private teams: TeamRecord[] = [];
  private listeners = new Set<Listener>();
  private started = false;
  private modeListeners = new Set<() => void>();

  private emit() {
    const ranked = rankTeams(this.teams);
    this.listeners.forEach((l) => l(ranked));
  }
  private setTeams(list: TeamRecord[]) {
    this.teams = list;
    this.emit();
  }
  onMode(fn: () => void) {
    this.modeListeners.add(fn);
    return () => this.modeListeners.delete(fn);
  }

  private start() {
    if (this.started) return;
    this.started = true;
    if (this.mode === 'supabase') {
      type Row = Record<string, unknown>;
      const pull = () =>
        select<Row>('leaderboard', 'select=*')
          .then((rows) =>
            this.setTeams(
              rows
                .map((r) =>
                  clean(
                    { ...r, trainScore: r.train_score, startedAt: r.started_at, scoredAt: r.scored_at, finishedAt: r.finished_at, updatedAt: r.updated_at },
                    String(r.id),
                  ),
                )
                .filter(Boolean) as TeamRecord[],
            ),
          )
          .catch(() => {});
      void pull();
      setInterval(pull, 4000);
      return;
    }
    if (this.mode === 'server') {
      const pull = () =>
        fetch(`${API_BASE}/api/teams`)
          .then((r) => r.json())
          .then((rows: Record<string, unknown>[]) => this.setTeams(rows.map((r) => clean(r, String(r.id))).filter(Boolean) as TeamRecord[]))
          .catch(() => {});
      void pull();
      setInterval(pull, 5000);
      return;
    }
    // local first, then upgrade to shared if the artifact database answers
    this.setTeams(Object.entries(readLocal()).map(([id, r]) => clean(r, id)).filter(Boolean) as TeamRecord[]);
    window.addEventListener('storage', (e) => {
      if (e.key === LOCAL_KEY && this.mode === 'local') this.setTeams(Object.entries(readLocal()).map(([id, r]) => clean(r, id)).filter(Boolean) as TeamRecord[]);
    });
    void getDb().then((db) => {
      if (!db) return;
      this.mode = 'shared';
      this.modeListeners.forEach((f) => f());
      // Move any teams that registered before the database answered.
      const pending = Object.values(readLocal());
      db.collection('teams').onSnapshot(
        (snap) => this.setTeams(snap.docs.map((d) => clean(d.data(), d.id)).filter(Boolean) as TeamRecord[]),
        () => {
          this.mode = 'local';
          this.modeListeners.forEach((f) => f());
        },
      );
      for (const t of pending) void this.upsert(t);
    });
  }

  subscribe(fn: Listener) {
    this.start();
    this.listeners.add(fn);
    fn(rankTeams(this.teams));
    return () => {
      this.listeners.delete(fn);
    };
  }

  current() {
    this.start();
    return rankTeams(this.teams);
  }

  nameTaken(name: string, exceptId?: string) {
    const n = name.trim().toLowerCase();
    return this.current().some((t) => t.id !== exceptId && t.name.trim().toLowerCase() === n);
  }

  async upsert(t: TeamRecord) {
    this.start();
    // optimistic local view
    const others = this.teams.filter((x) => x.id !== t.id);
    this.setTeams([...others, t]);
    if (this.mode === 'supabase') {
      const tk = teamToken();
      if (tk) await rpc('ctf_save_row', { p_token: tk, p_row: t }).catch(() => {});
      return;
    }
    if (this.mode === 'server') {
      await fetch(`${API_BASE}/api/teams`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json', Authorization: `Bearer ${teamToken()}` },
        body: JSON.stringify(t),
      }).catch(() => {});
      return;
    }
    if (this.mode === 'shared') {
      const db = await getDb();
      if (db) {
        try {
          const { id, ...body } = t;
          await db.collection('teams').doc(id).set(body as unknown as Record<string, unknown>);
          const all = readLocal();
          if (all[id]) {
            delete all[id];
            writeLocal(all);
          }
          return;
        } catch {
          this.readOnly = true;
          this.modeListeners.forEach((f) => f());
        }
      }
    }
    const all = readLocal();
    all[t.id] = t;
    writeLocal(all);
  }

  async remove(id: string) {
    this.setTeams(this.teams.filter((x) => x.id !== id));
    if (this.mode === 'supabase') return; // deleted by the admin function
    if (this.mode === 'server') {
      await fetch(`${API_BASE}/api/teams/${encodeURIComponent(id)}`, { method: 'DELETE' }).catch(() => {});
      return;
    }
    if (this.mode === 'shared') {
      const db = await getDb();
      try {
        await db?.collection('teams').doc(id).delete();
      } catch {
        /* not allowed */
      }
    }
    const all = readLocal();
    delete all[id];
    writeLocal(all);
  }
}

export const board = new Board();
