// Shared by the browser, the hash generator script and the optional server.
// Keep this file dependency-free so Node can import it directly.

export type NormMode = 'id' | 'text' | 'phrase' | 'flag';

/** Arabic-Indic and Eastern Arabic-Indic digits → ASCII, so ٢٠١٩ counts as 2019. */
function asciiDigits(s: string): string {
  return s
    .replace(/[٠-٩]/g, (d) => String(d.charCodeAt(0) - 0x0660))
    .replace(/[۰-۹]/g, (d) => String(d.charCodeAt(0) - 0x06f0));
}

/**
 * id     – option / target ids: exact, trimmed.
 * text   – trim, collapse spaces, case-insensitive. Punctuation is kept (it matters in passwords).
 * phrase – like text, but punctuation is ignored ("The door is open!" == "the door is open").
 * flag   – all whitespace removed, case-insensitive ("dera{ a_b }" == "DERA{a_b}").
 */
export function normalize(raw: string, mode: NormMode): string {
  const s = asciiDigits(String(raw ?? '')).normalize('NFKC').trim();
  switch (mode) {
    case 'id':
      return s;
    case 'text':
      return s.replace(/\s+/g, ' ').toLowerCase();
    case 'phrase':
      return s
        .toLowerCase()
        .replace(/[^\p{L}\p{N}\s]/gu, ' ')
        .replace(/\s+/g, ' ')
        .trim();
    case 'flag':
      return s.replace(/\s+/g, '').toLowerCase();
  }
}

/** Salted key that gets hashed. Includes challenge id + stage so equal answers hash differently. */
export function hashInput(challengeId: string, stage: number, normalized: string): string {
  return `ctf360::${challengeId}::${stage}::${normalized}`;
}
