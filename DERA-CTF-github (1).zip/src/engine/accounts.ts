// ─────────────────────────────────────────────────────────────────────────────
//  Team accounts, activity log, competition lock and the admin view.
//
//  Three back-ends, chosen at runtime (same idea as board.ts):
//   shared — the claude.ai artifact database. Account and log documents live
//            under `secure/…`, which the published access rules make readable
//            and writable only at admin level (the artifact owner's devices).
//            The public leaderboard rows (`teams/…`) stay readable by everyone.
//   server — server/server.mjs: passwords hashed with scrypt on the server,
//            admin checked on the server, answers never leave it.
//   local  — this browser only (a single kiosk / development).
//
//  Team passwords are never stored in plain text: PBKDF2-SHA-256 with a
//  per-team random salt (client back-ends) or scrypt (server).
// ─────────────────────────────────────────────────────────────────────────────
import { VALIDATION_MODE } from './validate';
import { ADMIN_KEY } from '../data/adminKey.generated';
import type { ChallengeProgress } from '../state/store';
import { SUPABASE_ON, rpc, select } from './supabase';

export type Spec = 'net' | 'web' | 'support' | 'marketing' | 'office' | 'other';
export interface Member {
  name: string;
  spec: Spec;
  /** Free text when spec is 'other'. */
  specOther?: string;
  /** Emoji avatar for this member. */
  emoji?: string;
}
export interface TeamProfile {
  id: string;
  name: string;
  avatar: string;
  members: Member[];
  createdAt: number;
}
export interface LogEvent {
  t: number;
  area: 'comp' | 'train';
  cid: string;
  stage?: number;
  kind: 'open' | 'attempt' | 'hint' | 'solve';
  answer?: string;
  ok?: boolean;
  pts?: number;
}
export interface SavedSession {
  startedAt: number;
  finishedAt?: number;
  progress: Record<string, ChallengeProgress>;
  inspected: string[];
  seenReports: string[];
}
export interface SavedTraining {
  solved: Record<string, number>;
  flags?: Record<string, string>;
  picks?: Record<string, string>;
}
export interface Saved {
  session?: SavedSession;
  training?: SavedTraining;
  updatedAt: number;
}
export interface Settings {
  competitionOpen: boolean;
  vaultOpen: boolean;
  /** When the admin last opened the competition (the shared start time for "fastest"). */
  openedAt?: number;
  updatedAt: number;
}
export interface AdminTeam {
  profile: TeamProfile;
  saved: Saved | null;
  events: LogEvent[];
}
export interface Solution {
  id: string;
  answer: string;
  steps: string[];
}

export type AccountsMode = 'shared' | 'server' | 'local' | 'supabase';
export type RegisterResult = { ok: true; team: TeamProfile; token?: string } | { ok: false; code: 'taken' | 'readonly' | 'invalid' | 'error' };
export type LoginResult = { ok: true; team: TeamProfile; saved: Saved | null; token?: string } | { ok: false; code: 'bad' | 'readonly' | 'error' };

export const DEFAULT_SETTINGS: Settings = { competitionOpen: false, vaultOpen: false, updatedAt: 0 };
const MAX_EVENTS = 800;
const API_BASE: string = import.meta.env.VITE_API_BASE ?? '';

// ── helpers ─────────────────────────────────────────────────────────────────
export const nameKey = (s: string) => s.normalize('NFKC').trim().replace(/\s+/g, ' ').toLowerCase();
const enc = new TextEncoder();
const hex = (b: ArrayBuffer) => [...new Uint8Array(b)].map((x) => x.toString(16).padStart(2, '0')).join('');
const unhex = (h: string) => new Uint8Array(h.match(/../g)!.map((x) => parseInt(x, 16)));

export async function teamIdFor(name: string) {
  const d = await crypto.subtle.digest('SHA-256', enc.encode(`ctf360-team::${nameKey(name)}`));
  return 't' + hex(d).slice(0, 20);
}

async function pbkdf2(secret: string, saltHex: string, iter: number) {
  const key = await crypto.subtle.importKey('raw', enc.encode(secret), 'PBKDF2', false, ['deriveBits']);
  const bits = await crypto.subtle.deriveBits({ name: 'PBKDF2', hash: 'SHA-256', salt: unhex(saltHex), iterations: iter }, key, 256);
  return hex(bits);
}
function safeEq(a: string, b: string) {
  if (a.length !== b.length) return false;
  let r = 0;
  for (let i = 0; i < a.length; i++) r |= a.charCodeAt(i) ^ b.charCodeAt(i);
  return r === 0;
}
const TEAM_ITER = 120_000;

/** Admin username is case-insensitive and spacing-tolerant; the password is exact. */
export const adminSecret = (user: string, pass: string) => `${nameKey(user)}\n${pass}`;
export async function checkAdminLocal(user: string, pass: string) {
  const h = await pbkdf2(adminSecret(user, pass), ADMIN_KEY.salt, ADMIN_KEY.iter);
  return safeEq(h, ADMIN_KEY.hash);
}

function cleanProfile(p: Partial<TeamProfile> & { id: string }): TeamProfile {
  return {
    id: p.id,
    name: String(p.name ?? '').slice(0, 32),
    avatar: String(p.avatar ?? 'hat-white').slice(0, 24),
    members: (Array.isArray(p.members) ? p.members : []).slice(0, 6).map((m) => ({
      name: String((m as Member).name ?? '').slice(0, 40),
      spec: (['net', 'web', 'support', 'marketing', 'office', 'other'].includes((m as Member).spec) ? (m as Member).spec : 'other') as Spec,
      specOther: (m as Member).specOther ? String((m as Member).specOther).slice(0, 40) : undefined,
      emoji: (m as Member).emoji ? String((m as Member).emoji).slice(0, 16) : undefined,
    })),
    createdAt: Number(p.createdAt) || Date.now(),
  };
}

// ── key-value layer for the client back-ends ─────────────────────────────────
interface Kv {
  get(path: string): Promise<Record<string, unknown> | null>;
  set(path: string, data: Record<string, unknown>): Promise<void>;
  del(path: string): Promise<void>;
  list(coll: string): Promise<{ id: string; data: Record<string, unknown> }[]>;
  watch(path: string, cb: (d: Record<string, unknown> | null) => void): () => void;
}

const strip = <T,>(v: T): T => JSON.parse(JSON.stringify(v));

function localKv(): Kv {
  const P = 'ctf360.kv:';
  const listeners = new Map<string, Set<(d: Record<string, unknown> | null) => void>>();
  const read = (path: string) => {
    try {
      const v = localStorage.getItem(P + path);
      return v ? (JSON.parse(v) as Record<string, unknown>) : null;
    } catch {
      return null;
    }
  };
  const fire = (path: string) => listeners.get(path)?.forEach((f) => f(read(path)));
  window.addEventListener('storage', (e) => {
    if (e.key?.startsWith(P)) fire(e.key.slice(P.length));
  });
  return {
    async get(path) {
      return read(path);
    },
    async set(path, data) {
      try {
        localStorage.setItem(P + path, JSON.stringify(data));
      } catch {
        /* blocked */
      }
      fire(path);
    },
    async del(path) {
      try {
        localStorage.removeItem(P + path);
      } catch {
        /* blocked */
      }
      fire(path);
    },
    async list(coll) {
      const out: { id: string; data: Record<string, unknown> }[] = [];
      try {
        for (let i = 0; i < localStorage.length; i++) {
          const k = localStorage.key(i)!;
          if (!k.startsWith(P + coll + '/')) continue;
          const rest = k.slice(P.length + coll.length + 1);
          if (rest.includes('/')) continue;
          const d = read(coll + '/' + rest);
          if (d) out.push({ id: rest, data: d });
        }
      } catch {
        /* blocked */
      }
      return out;
    },
    watch(path, cb) {
      if (!listeners.has(path)) listeners.set(path, new Set());
      listeners.get(path)!.add(cb);
      cb(read(path));
      return () => listeners.get(path)?.delete(cb);
    },
  };
}

type Snap = { exists: boolean; id: string; data(): Record<string, unknown> | undefined };
type DbNs = {
  doc(p: string): {
    get(): Promise<Snap>;
    set(d: Record<string, unknown>): Promise<void>;
    delete(): Promise<void>;
    onSnapshot(next: (s: Snap) => void, err?: (e: { code: string }) => void): () => void;
  };
  collection(p: string): { get(): Promise<{ docs: Snap[] }> };
};
function sharedKv(db: DbNs): Kv {
  return {
    async get(path) {
      const s = await db.doc(path).get();
      return s.exists ? (s.data() ?? null) : null;
    },
    set: (path, data) => db.doc(path).set(strip(data)),
    del: (path) => db.doc(path).delete(),
    async list(coll) {
      const q = await db.collection(coll).get();
      return q.docs.filter((d) => d.exists).map((d) => ({ id: d.id, data: d.data() ?? {} }));
    },
    watch(path, cb) {
      return db.doc(path).onSnapshot(
        (s) => cb(s.exists ? (s.data() ?? null) : null),
        () => {},
      );
    },
  };
}

type UserNs = { isOwner(): Promise<boolean>; canEdit(): Promise<boolean>; can(n: string): Promise<boolean | null> };
let runtime: Promise<{ db: DbNs | null; user: UserNs | null }> | null = null;
function getRuntime() {
  if (runtime) return runtime;
  const c = (window as unknown as { claude?: { use?: (n: string) => Promise<unknown> } }).claude;
  if (!c?.use) return (runtime = Promise.resolve({ db: null, user: null }));
  runtime = Promise.all([
    (c.use('db') as Promise<DbNs | null>).catch(() => null),
    (c.use('user') as Promise<UserNs | null>).catch(() => null),
  ]).then(([db, user]) => ({ db, user }));
  return runtime;
}

const PATH = {
  account: (id: string) => `secure/v1/accounts/${id}`,
  log: (id: string) => `secure/v1/logs/${id}`,
  accounts: 'secure/v1/accounts',
  logs: 'secure/v1/logs',
  solutions: 'secure/v1/solutions',
  settings: 'config/settings',
};

// ── client back-end (shared or local) ────────────────────────────────────────
class ClientAccounts {
  constructor(
    private kv: Kv,
    public mode: 'shared' | 'local',
    private user: UserNs | null,
  ) {}

  /** Whether this device may create accounts and save progress. */
  async canWrite() {
    if (this.mode === 'local') return true;
    try {
      return (await this.user?.canEdit()) ?? true;
    } catch {
      return true;
    }
  }

  async register(input: { name: string; avatar: string; members: Member[]; password: string }): Promise<RegisterResult> {
    if (!(await this.canWrite())) return { ok: false, code: 'readonly' };
    const id = await teamIdFor(input.name);
    try {
      if (await this.kv.get(PATH.account(id))) return { ok: false, code: 'taken' };
      const salt = hex(crypto.getRandomValues(new Uint8Array(16)).buffer);
      const hash = await pbkdf2(input.password, salt, TEAM_ITER);
      const profile = cleanProfile({ id, name: input.name.trim(), avatar: input.avatar, members: input.members, createdAt: Date.now() });
      await this.kv.set(PATH.account(id), { profile, nameKey: nameKey(input.name), pass: { alg: 'pbkdf2-sha256', iter: TEAM_ITER, salt, hash } });
      return { ok: true, team: profile };
    } catch {
      return { ok: false, code: (await this.canWrite()) ? 'error' : 'readonly' };
    }
  }

  async nameTaken(name: string) {
    try {
      return !!(await this.kv.get(PATH.account(await teamIdFor(name))));
    } catch {
      return false;
    }
  }

  async login(name: string, password: string): Promise<LoginResult> {
    try {
      const id = await teamIdFor(name);
      const acc = (await this.kv.get(PATH.account(id))) as { profile: TeamProfile; pass: { salt: string; hash: string; iter: number } } | null;
      if (!acc) return { ok: false, code: (await this.canWrite()) ? 'bad' : 'readonly' };
      const h = await pbkdf2(password, acc.pass.salt, acc.pass.iter);
      if (!safeEq(h, acc.pass.hash)) return { ok: false, code: 'bad' };
      const log = (await this.kv.get(PATH.log(id))) as { saved?: Saved } | null;
      return { ok: true, team: cleanProfile({ ...acc.profile, id }), saved: log?.saved ?? null };
    } catch {
      return { ok: false, code: 'error' };
    }
  }

  private writing = Promise.resolve();
  /** Saves the team's progress snapshot and appends new activity events. */
  save(teamId: string, saved: Saved, events: LogEvent[]) {
    this.writing = this.writing.then(async () => {
      try {
        const cur = ((await this.kv.get(PATH.log(teamId))) as { events?: LogEvent[] } | null) ?? {};
        const all = [...(cur.events ?? []), ...events].slice(-MAX_EVENTS);
        await this.kv.set(PATH.log(teamId), { saved, events: all, updatedAt: Date.now() });
      } catch {
        /* read-only device or offline — progress stays on this device */
      }
    });
    return this.writing;
  }

  watchSettings(cb: (s: Settings) => void) {
    return this.kv.watch(PATH.settings, (d) => cb({ ...DEFAULT_SETTINGS, ...((d as Partial<Settings>) ?? {}) }));
  }

  // admin
  async adminLogin(user: string, pass: string) {
    return checkAdminLocal(user, pass);
  }
  async setSettings(s: Settings) {
    await this.kv.set(PATH.settings, { ...s, updatedAt: Date.now() });
  }
  async overview(): Promise<{ teams: AdminTeam[]; solutions: Record<string, Solution> }> {
    const [accs, logs, sols] = await Promise.all([this.kv.list(PATH.accounts), this.kv.list(PATH.logs), this.kv.list(PATH.solutions).catch(() => [])]);
    const L = new Map(logs.map((l) => [l.id, l.data as { saved?: Saved; events?: LogEvent[] }]));
    const teams = accs.map((a) => {
      const l = L.get(a.id);
      return { profile: cleanProfile({ ...(a.data.profile as TeamProfile), id: a.id }), saved: l?.saved ?? null, events: l?.events ?? [] };
    });
    const solutions: Record<string, Solution> = {};
    for (const s of sols) solutions[s.id] = { id: s.id, answer: String(s.data.answer ?? ''), steps: Array.isArray(s.data.steps) ? (s.data.steps as string[]) : [] };
    return { teams, solutions };
  }
  async getSolution(cid: string): Promise<Solution | null> {
    try {
      const d = await this.kv.get(`${PATH.solutions}/${cid}`);
      return d ? { id: cid, answer: String(d.answer ?? ''), steps: Array.isArray(d.steps) ? (d.steps as string[]) : [] } : null;
    } catch {
      return null;
    }
  }
  async deleteTeam(id: string) {
    await this.kv.del(PATH.account(id));
    await this.kv.del(PATH.log(id));
  }
  async resetAll() {
    for (const a of await this.kv.list(PATH.accounts)) await this.deleteTeam(a.id);
    for (const l of await this.kv.list(PATH.logs)) await this.kv.del(PATH.log(l.id));
  }
  async resetPassword(id: string, password: string) {
    const acc = await this.kv.get(PATH.account(id));
    if (!acc) return false;
    const salt = hex(crypto.getRandomValues(new Uint8Array(16)).buffer);
    const hash = await pbkdf2(password, salt, TEAM_ITER);
    await this.kv.set(PATH.account(id), { ...acc, pass: { alg: 'pbkdf2-sha256', iter: TEAM_ITER, salt, hash } });
    return true;
  }
}

// ── server back-end ──────────────────────────────────────────────────────────
class ServerAccounts {
  mode = 'server' as const;
  private adminToken = '';
  teamToken = '';
  private post = (path: string, body: unknown, token = '') =>
    fetch(`${API_BASE}${path}`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json', ...(token ? { Authorization: `Bearer ${token}` } : {}) },
      body: JSON.stringify(body),
    }).then((r) => r.json());

  async canWrite() {
    return true;
  }
  async register(input: { name: string; avatar: string; members: Member[]; password: string }): Promise<RegisterResult> {
    try {
      const r = await this.post('/api/register', input);
      if (r.ok) this.teamToken = r.token;
      return r.ok ? { ok: true, team: r.team, token: r.token } : { ok: false, code: r.code ?? 'error' };
    } catch {
      return { ok: false, code: 'error' };
    }
  }
  async nameTaken(name: string) {
    try {
      return !!(await this.post('/api/name-taken', { name })).taken;
    } catch {
      return false;
    }
  }
  async login(name: string, password: string): Promise<LoginResult> {
    try {
      const r = await this.post('/api/login', { name, password });
      if (!r.ok) return { ok: false, code: r.code ?? 'bad' };
      this.teamToken = r.token;
      return { ok: true, team: r.team, saved: r.saved ?? null, token: r.token };
    } catch {
      return { ok: false, code: 'error' };
    }
  }
  async save(_teamId: string, saved: Saved, events: LogEvent[], token?: string) {
    const tk = token || this.teamToken;
    if (!tk) return;
    await this.post('/api/progress', { saved, events }, tk).catch(() => {});
  }
  watchSettings(cb: (s: Settings) => void) {
    let stop = false;
    const pull = () =>
      fetch(`${API_BASE}/api/settings`)
        .then((r) => r.json())
        .then((s) => !stop && cb({ ...DEFAULT_SETTINGS, ...s }))
        .catch(() => {});
    void pull();
    const id = setInterval(pull, 5000);
    return () => {
      stop = true;
      clearInterval(id);
    };
  }
  async adminLogin(user: string, pass: string) {
    try {
      const r = await this.post('/api/admin/login', { user, pass });
      this.adminToken = r.ok ? r.token : '';
      try {
        if (r.ok) sessionStorage.setItem('ctf360.adminToken', r.token);
      } catch {
        /* blocked */
      }
      return !!r.ok;
    } catch {
      return false;
    }
  }
  private tok() {
    if (!this.adminToken) {
      try {
        this.adminToken = sessionStorage.getItem('ctf360.adminToken') ?? '';
      } catch {
        /* blocked */
      }
    }
    return this.adminToken;
  }
  async setSettings(s: Settings) {
    await this.post('/api/admin/settings', s, this.tok());
  }
  async overview() {
    const r = await fetch(`${API_BASE}/api/admin/overview`, { headers: { Authorization: `Bearer ${this.tok()}` } }).then((x) => x.json());
    return { teams: (r.teams ?? []) as AdminTeam[], solutions: (r.solutions ?? {}) as Record<string, Solution> };
  }
  async getSolution(cid: string): Promise<Solution | null> {
    try {
      const r = await fetch(`${API_BASE}/api/admin/solution?id=${encodeURIComponent(cid)}`, { headers: { Authorization: `Bearer ${this.tok()}` } }).then((x) => x.json());
      return r?.ok ? (r.solution as Solution) : null;
    } catch {
      return null;
    }
  }
  async deleteTeam(id: string) {
    await this.post('/api/admin/delete-team', { id }, this.tok());
  }
  async resetAll() {
    await this.post('/api/admin/reset-all', {}, this.tok());
  }
  async resetPassword(id: string, password: string) {
    const r = await this.post('/api/admin/reset-password', { id, password }, this.tok());
    return !!r.ok;
  }
}

// ── Supabase back-end (GitHub Pages) ─────────────────────────────────────────
type SettingsRow = { competition_open: boolean; vault_open: boolean; opened_at: number; updated_at: number };
class SupabaseAccounts {
  mode = 'supabase' as const;
  private adminToken = '';
  async canWrite() {
    return true;
  }
  async register(input: { name: string; avatar: string; members: Member[]; password: string }): Promise<RegisterResult> {
    try {
      const r = await rpc<{ ok: boolean; team?: TeamProfile; token?: string; code?: string }>('ctf_register', {
        p_name: input.name,
        p_avatar: input.avatar,
        p_members: input.members,
        p_password: input.password,
      });
      return r.ok ? { ok: true, team: cleanProfile(r.team!), token: r.token } : { ok: false, code: (r.code as 'taken' | 'invalid') ?? 'error' };
    } catch {
      return { ok: false, code: 'error' };
    }
  }
  async nameTaken(name: string) {
    try {
      return !!(await rpc<boolean>('ctf_name_taken', { p_name: name }));
    } catch {
      return false;
    }
  }
  async login(name: string, password: string): Promise<LoginResult> {
    try {
      const r = await rpc<{ ok: boolean; team?: TeamProfile; saved?: Saved | null; token?: string }>('ctf_login', { p_name: name, p_password: password });
      if (!r.ok) return { ok: false, code: 'bad' };
      return { ok: true, team: cleanProfile(r.team!), saved: r.saved ?? null, token: r.token };
    } catch {
      return { ok: false, code: 'error' };
    }
  }
  async save(_teamId: string, saved: Saved, events: LogEvent[], token?: string) {
    if (!token) return;
    await rpc('ctf_save_progress', { p_token: token, p_saved: saved, p_events: events }).catch(() => {});
  }
  watchSettings(cb: (s: Settings) => void) {
    let stop = false;
    const pull = () =>
      select<SettingsRow>('settings', 'select=*&id=eq.1')
        .then((rows) => {
          const r = rows[0];
          if (!stop && r) cb({ competitionOpen: !!r.competition_open, vaultOpen: !!r.vault_open, openedAt: Number(r.opened_at) || 0, updatedAt: Number(r.updated_at) || 0 });
        })
        .catch(() => {});
    void pull();
    const id = setInterval(pull, 4000);
    return () => {
      stop = true;
      clearInterval(id);
    };
  }
  private tok() {
    if (!this.adminToken) {
      try {
        this.adminToken = sessionStorage.getItem('ctf360.adminToken') ?? '';
      } catch {
        /* blocked */
      }
    }
    return this.adminToken;
  }
  async adminLogin(user: string, pass: string) {
    try {
      const r = await rpc<{ ok: boolean; token?: string }>('ctf_admin_login', { p_user: user, p_pass: pass });
      this.adminToken = r.ok ? r.token! : '';
      try {
        if (r.ok) sessionStorage.setItem('ctf360.adminToken', this.adminToken);
      } catch {
        /* blocked */
      }
      return !!r.ok;
    } catch {
      return false;
    }
  }
  async setSettings(s: Settings) {
    await rpc('ctf_admin_settings', { p_token: this.tok(), p_open: s.competitionOpen, p_vault: s.vaultOpen });
  }
  async overview() {
    const r = await rpc<{ ok: boolean; teams?: AdminTeam[]; solutions?: Record<string, Solution> }>('ctf_admin_overview', { p_token: this.tok() });
    if (!r.ok) throw new Error('admin session expired');
    return { teams: (r.teams ?? []).map((t) => ({ ...t, profile: cleanProfile(t.profile), events: t.events ?? [] })), solutions: r.solutions ?? {} };
  }
  async getSolution(cid: string): Promise<Solution | null> {
    try {
      const r = await rpc<{ ok: boolean; solution?: Solution }>('ctf_admin_solution', { p_token: this.tok(), p_id: cid });
      return r.ok ? r.solution! : null;
    } catch {
      return null;
    }
  }
  async deleteTeam(id: string) {
    await rpc('ctf_admin_delete_team', { p_token: this.tok(), p_id: id });
  }
  async resetPassword(id: string, password: string) {
    try {
      return !!(await rpc<boolean>('ctf_admin_reset_password', { p_token: this.tok(), p_id: id, p_password: password }));
    } catch {
      return false;
    }
  }
  async resetAll() {
    await rpc('ctf_admin_reset_all', { p_token: this.tok() });
  }
}

export type Accounts = ClientAccounts | ServerAccounts | SupabaseAccounts;

let acc: Promise<Accounts> | null = null;
/** Resolves the back-end once: server build → server; artifact db answers → shared; else local. */
export function accounts(): Promise<Accounts> {
  if (acc) return acc;
  if (VALIDATION_MODE === 'server') return (acc = Promise.resolve(new ServerAccounts()));
  if (SUPABASE_ON) return (acc = Promise.resolve(new SupabaseAccounts()));
  acc = getRuntime().then(({ db, user }) => (db ? new ClientAccounts(sharedKv(db), 'shared', user) : new ClientAccounts(localKv(), 'local', null)));
  return acc;
}

/** True when this viewer is the artifact's owner (shared mode only). */
export async function viewerIsOwner() {
  const { user } = await getRuntime();
  try {
    return (await user?.isOwner()) ?? false;
  } catch {
    return false;
  }
}

// ── password strength ────────────────────────────────────────────────────────
const COMMON = ['password', '123456', '12345678', 'qwerty', '111111', 'abc123', 'admin', 'iloveyou', 'welcome', 'dera', 'ctf'];
export function passwordStrength(pw: string, teamName = '') {
  const checks = {
    len8: pw.length >= 8,
    len12: pw.length >= 12,
    lower: /[a-z]/.test(pw),
    upper: /[A-Z]/.test(pw),
    digit: /\d/.test(pw),
    symbol: /[^A-Za-z0-9\s]/.test(pw),
  };
  let score = 0;
  if (checks.len8) score++;
  if (checks.len12) score++;
  if (checks.lower && checks.upper) score++;
  if (checks.digit) score++;
  if (checks.symbol) score++;
  const low = pw.toLowerCase();
  const weakWord = COMMON.some((w) => low.includes(w)) || (teamName.trim().length > 2 && low.includes(nameKey(teamName).replace(/\s/g, '')));
  if (weakWord) score = Math.max(0, score - 2);
  if (/^(.)\1+$/.test(pw)) score = 0;
  if (!checks.len8) score = Math.min(score, 1);
  const level = score <= 1 ? 0 : score === 2 ? 1 : score === 3 ? 2 : 3; // weak / medium / strong / very strong
  return { score, level, checks, weakWord };
}
