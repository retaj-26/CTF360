import { normalize, hashInput, type NormMode } from './normalize';
import { sha256Hex } from './sha256';
import type { AnswerKey } from './types';

export const VALIDATION_MODE: 'local' | 'server' =
  import.meta.env.VITE_VALIDATION_MODE === 'server' ? 'server' : 'local';

/** Base URL of server/server.mjs. Empty = same origin. */
const API_BASE: string = import.meta.env.VITE_API_BASE ?? '';

let keysPromise: Promise<Record<string, AnswerKey>> | null = null;
function loadKeys() {
  // In a server build this branch is dead code, so the hashes never reach the bundle.
  keysPromise ??= import('../data/answerKeys.generated').then((m) => m.ANSWER_KEYS);
  return keysPromise;
}

export interface Verdict {
  correct: boolean;
  /** The normalized answer, used to look up targeted feedback for wrong answers. */
  normalized: string;
}

/** Normalization mode for a stage, needed client-side for feedback lookup in both modes. */
export function guessMode(kind: 'choice' | 'pick' | 'text', isFlag: boolean, isPhrase: boolean): NormMode {
  if (kind !== 'text') return 'id';
  if (isFlag) return 'flag';
  return isPhrase ? 'phrase' : 'text';
}

export async function checkAnswer(
  challengeId: string,
  stage: number,
  raw: string,
  fallbackMode: NormMode,
): Promise<Verdict> {
  if (VALIDATION_MODE === 'server') {
    const res = await fetch(`${API_BASE}/api/validate`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ challengeId, stage, answer: raw }),
    });
    if (!res.ok) throw new Error(`validate ${res.status}`);
    const body = (await res.json()) as { correct: boolean };
    return { correct: !!body.correct, normalized: normalize(raw, fallbackMode) };
  }
  const keys = await loadKeys();
  const st = keys[challengeId]?.[stage];
  if (!st) return { correct: false, normalized: normalize(raw, fallbackMode) };
  const n = normalize(raw, st.mode);
  if (!n) return { correct: false, normalized: n };
  const h = sha256Hex(hashInput(challengeId, stage, n));
  return { correct: st.hashes.includes(h), normalized: n };
}
