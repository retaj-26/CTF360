// Pure, local decoders used by the on-screen decoder tool. Nothing is executed.

const MORSE: Record<string, string> = {
  '.-': 'A', '-...': 'B', '-.-.': 'C', '-..': 'D', '.': 'E', '..-.': 'F', '--.': 'G', '....': 'H',
  '..': 'I', '.---': 'J', '-.-': 'K', '.-..': 'L', '--': 'M', '-.': 'N', '---': 'O', '.--.': 'P',
  '--.-': 'Q', '.-.': 'R', '...': 'S', '-': 'T', '..-': 'U', '...-': 'V', '.--': 'W', '-..-': 'X',
  '-.--': 'Y', '--..': 'Z', '-----': '0', '.----': '1', '..---': '2', '...--': '3', '....-': '4',
  '.....': '5', '-....': '6', '--...': '7', '---..': '8', '----.': '9', '.-.-.-': '.', '--..--': ',',
  '..--..': '?', '-.-.--': '!',
};

export type DecodeResult = { ok: true; text: string } | { ok: false };

export function decodeMorse(input: string): DecodeResult {
  const clean = input.replace(/[·•]/g, '.').replace(/[—–_]/g, '-').trim();
  if (!clean || /[^.\-\s/|]/.test(clean)) return { ok: false };
  const words = clean.split(/\s*[/|]\s*/);
  const text = words
    .map((w) =>
      w
        .split(/\s+/)
        .filter(Boolean)
        .map((sym) => MORSE[sym] ?? '?')
        .join(''),
    )
    .join(' ');
  return { ok: true, text };
}

export function decodeHex(input: string): DecodeResult {
  const clean = input.replace(/0x/gi, '').replace(/[\s,:]/g, '');
  if (!clean || clean.length % 2 || /[^0-9a-f]/i.test(clean)) return { ok: false };
  const bytes = new Uint8Array(clean.length / 2);
  for (let i = 0; i < bytes.length; i++) bytes[i] = parseInt(clean.slice(i * 2, i * 2 + 2), 16);
  try {
    return { ok: true, text: new TextDecoder('utf-8', { fatal: true }).decode(bytes) };
  } catch {
    return { ok: false };
  }
}

export function decodeBase64(input: string): DecodeResult {
  const clean = input.replace(/\s+/g, '');
  if (!clean || /[^A-Za-z0-9+/=]/.test(clean) || clean.length % 4 === 1) return { ok: false };
  try {
    const bin = atob(clean);
    const bytes = Uint8Array.from(bin, (c) => c.charCodeAt(0));
    return { ok: true, text: new TextDecoder('utf-8', { fatal: true }).decode(bytes) };
  } catch {
    return { ok: false };
  }
}

export const DECODERS = { morse: decodeMorse, hex: decodeHex, base64: decodeBase64 };
