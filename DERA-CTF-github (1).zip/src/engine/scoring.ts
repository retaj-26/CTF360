export const HINT_PENALTY = 0.25; // each hint removes 25% of the challenge's maximum
export const OVERTIME_CAP = 0.5;  // past an optional time limit, a challenge is worth at most 50%
export const WRONG_COOLDOWN_MS = 2500;

export function pointsFor(basePoints: number, hintsUsed: number, overTime: boolean, freeHints = false): number {
  if (freeHints) hintsUsed = 0;
  let factor = Math.max(0, 1 - HINT_PENALTY * hintsUsed);
  if (overTime) factor = Math.min(factor, OVERTIME_CAP);
  return Math.round(basePoints * factor);
}
