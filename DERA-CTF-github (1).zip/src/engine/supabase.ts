// Supabase back-end (for the GitHub Pages build). Configured at runtime by
// public/backend-config.js → window.CTF360_BACKEND = { supabaseUrl, supabaseAnonKey }.
// Only the public "anon" key lives in the site; every write goes through the
// SECURITY DEFINER functions in supabase/setup.sql.
type Cfg = { supabaseUrl?: string; supabaseAnonKey?: string };
const cfg: Cfg = ((typeof window !== 'undefined' && (window as unknown as { CTF360_BACKEND?: Cfg }).CTF360_BACKEND) || {}) as Cfg;
const URL_ = (cfg.supabaseUrl || '').replace(/\/+$/, '');
const KEY = cfg.supabaseAnonKey || '';

export const SUPABASE_ON = !!(URL_ && KEY && /^(https:\/\/|http:\/\/(localhost|127\.0\.0\.1)[:/])/.test(URL_));

// New "publishable" keys (sb_publishable_…) go on `apikey` only; legacy anon JWTs (eyJ…) also on Authorization.
const headers = (): Record<string, string> => ({
  apikey: KEY,
  ...(KEY.startsWith('eyJ') ? { Authorization: `Bearer ${KEY}` } : {}),
  'Content-Type': 'application/json',
});

export async function rpc<T = unknown>(fn: string, args: Record<string, unknown>): Promise<T> {
  const r = await fetch(`${URL_}/rest/v1/rpc/${fn}`, { method: 'POST', headers: headers(), body: JSON.stringify(args) });
  if (!r.ok) throw new Error(`${fn} ${r.status}`);
  return (await r.json()) as T;
}

export async function select<T = unknown>(table: string, query = 'select=*'): Promise<T[]> {
  const r = await fetch(`${URL_}/rest/v1/${table}?${query}`, { headers: headers(), cache: 'no-store' });
  if (!r.ok) throw new Error(`${table} ${r.status}`);
  return (await r.json()) as T[];
}
