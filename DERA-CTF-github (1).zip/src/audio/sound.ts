// Short synthesised sound effects for the final competition (same on/off as the music).
import { audio, masterOut, mtof } from './engine';
import { musicState } from './music';

type Sfx = 'click' | 'correct' | 'wrong' | 'unlock' | 'crt' | 'alarm' | 'hint' | 'restore' | 'type';

function blip(freq: number, at: number, dur: number, type: OscillatorType = 'square', vol = 0.12, slideTo?: number) {
  const c = audio();
  const out = masterOut();
  if (!c || !out || c.state !== 'running') return;
  const t = c.currentTime + at;
  const o = c.createOscillator();
  const g = c.createGain();
  o.type = type;
  o.frequency.setValueAtTime(freq, t);
  if (slideTo) o.frequency.exponentialRampToValueAtTime(slideTo, t + dur);
  g.gain.setValueAtTime(0.0001, t);
  g.gain.exponentialRampToValueAtTime(vol, t + 0.008);
  g.gain.exponentialRampToValueAtTime(0.0001, t + dur);
  o.connect(g).connect(out);
  o.start(t);
  o.stop(t + dur + 0.05);
}

export function play(name: Sfx) {
  if (!musicState().on || document.documentElement.dataset.area !== 'arena') return;
  switch (name) {
    case 'correct':
      [72, 76, 79, 84].forEach((m, i) => blip(mtof(m), i * 0.07, 0.18, 'square', 0.1));
      break;
    case 'wrong':
      blip(150, 0, 0.28, 'sawtooth', 0.12, 80);
      break;
    case 'unlock':
      blip(300, 0, 0.35, 'sawtooth', 0.08, 1400);
      [79, 84].forEach((m, i) => blip(mtof(m), 0.3 + i * 0.09, 0.2, 'square', 0.09));
      break;
    case 'hint':
      blip(mtof(88), 0, 0.12, 'sine', 0.12);
      blip(mtof(93), 0.09, 0.16, 'sine', 0.1);
      break;
    case 'restore':
      [60, 64, 67, 72, 76, 79, 84].forEach((m, i) => blip(mtof(m), i * 0.08, 0.3, 'square', 0.08));
      break;
    case 'alarm':
      blip(880, 0, 0.18, 'square', 0.06);
      blip(660, 0.2, 0.18, 'square', 0.06);
      break;
    case 'click':
      blip(1200, 0, 0.03, 'square', 0.03);
      break;
    default:
      break;
  }
}

// Kept for older call sites.
export function setSoundEnabled() {}
export const isSoundEnabled = () => musicState().on;
