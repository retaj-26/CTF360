// ─────────────────────────────────────────────────────────────────────────────
//  Original, procedurally-synthesised "hackathon" music (Web Audio, no files).
//  Three tracks: four-on-the-floor kick, claps, hats, pumping bass, arpeggios and pads,
//  with sidechain-style ducking and 16-bar song structure (intro → drop → fill).
// ─────────────────────────────────────────────────────────────────────────────
import { audio, masterOut, noiseBuffer, mtof, unlockAudio } from './engine';

type Chord = [number, 'm' | 'M'];
interface Track {
  id: string;
  name: string;
  bpm: number;
  root: number; // MIDI note of the key's root (bass octave)
  prog: Chord[];
  kick: string;
  clap: string;
  hat: string;
  ohat: string;
  bass: string;
  arp: number[]; // chord-tone indices per 16th (-1 = rest)
  lead: 'sawtooth' | 'square';
}

export const TRACKS: Track[] = [
  {
    id: 'hack',
    name: 'وضع الهاكر',
    bpm: 124,
    root: 45, // A
    prog: [[0, 'm'], [-4, 'M'], [3, 'M'], [-2, 'M']],
    kick: 'x...x...x...x...',
    clap: '....x.......x...',
    hat: 'x.x.x.x.x.x.x.x.',
    ohat: '..x...x...x...x.',
    bass: '..x...x...x...x.',
    arp: [0, 1, 2, 3, 2, 1, 0, 1, 2, 3, 4, 3, 2, 1, 2, 3],
    lead: 'square',
  },
  {
    id: 'sprint',
    name: 'سباق الوقت',
    bpm: 136,
    root: 38, // D
    prog: [[0, 'm'], [-2, 'M'], [-5, 'M'], [-7, 'M']],
    kick: 'x...x...x...x...',
    clap: '....x.......x..x',
    hat: 'xxxxxxxxxxxxxxxx',
    ohat: '..x...x...x...x.',
    bass: 'x.xxx.xxx.xxx.xx',
    arp: [0, 2, 4, 2, 1, 3, 4, 3, 0, 2, 4, 2, 1, 3, 4, 5],
    lead: 'sawtooth',
  },
  {
    id: 'vault',
    name: 'القبو الأخير',
    bpm: 148,
    root: 40, // E
    prog: [[0, 'm'], [-4, 'M'], [3, 'M'], [-2, 'M']],
    kick: 'x...x...x...x.x.',
    clap: '....x.......x...',
    hat: 'x.xxx.xxx.xxx.xx',
    ohat: '..x...x...x...x.',
    bass: '.xxx.xxx.xxx.xxx',
    arp: [0, 1, 2, 4, 2, 1, 0, 2, 4, 5, 4, 2, 0, 1, 2, 4],
    lead: 'sawtooth',
  },
];

// ── state ────────────────────────────────────────────────────────────────────
const KEY = 'ctf360.music.v1';
type Saved = { on: boolean; volume: number; track: string };
function load(): Saved {
  try {
    const v = JSON.parse(localStorage.getItem(KEY) || 'null');
    if (v && typeof v === 'object') return { on: v.on !== false, volume: typeof v.volume === 'number' ? v.volume : 0.7, track: v.track || 'hack' };
  } catch {
    /* ignore */
  }
  return { on: true, volume: 0.7, track: 'hack' };
}
let saved = load();
const persist = () => {
  try {
    localStorage.setItem(KEY, JSON.stringify(saved));
  } catch {
    /* ignore */
  }
};

let playing = false;
let track = TRACKS.find((t) => t.id === saved.track) ?? TRACKS[0];
const subs = new Set<() => void>();
const emit = () => subs.forEach((f) => f());

export function musicState() {
  return { playing, on: saved.on, volume: saved.volume, track: track.id, trackName: track.name };
}
export function subscribeMusic(f: () => void) {
  subs.add(f);
  return () => {
    subs.delete(f);
  };
}

// ── audio graph ──────────────────────────────────────────────────────────────
let bus: GainNode | null = null; // music volume
let drums: GainNode | null = null;
let synths: GainNode | null = null; // ducked by the kick
let delay: DelayNode | null = null;

function graph() {
  const c = audio();
  const out = masterOut();
  if (!c || !out) return null;
  if (!bus) {
    bus = c.createGain();
    bus.gain.value = 0;
    bus.connect(out);
    drums = c.createGain();
    drums.gain.value = 0.9;
    drums.connect(bus);
    synths = c.createGain();
    synths.gain.value = 1;
    synths.connect(bus);
    delay = c.createDelay(1);
    const fb = c.createGain();
    fb.gain.value = 0.32;
    const wet = c.createGain();
    wet.gain.value = 0.28;
    const lp = c.createBiquadFilter();
    lp.type = 'lowpass';
    lp.frequency.value = 2400;
    delay.connect(lp).connect(fb).connect(delay);
    lp.connect(wet).connect(synths);
  }
  return c;
}

function env(g: GainNode, t: number, peak: number, attack: number, decay: number) {
  g.gain.setValueAtTime(0.0001, t);
  g.gain.exponentialRampToValueAtTime(peak, t + attack);
  g.gain.exponentialRampToValueAtTime(0.0001, t + attack + decay);
}

function kick(c: AudioContext, t: number) {
  const o = c.createOscillator();
  const g = c.createGain();
  o.frequency.setValueAtTime(155, t);
  o.frequency.exponentialRampToValueAtTime(42, t + 0.13);
  env(g, t, 1.0, 0.002, 0.34);
  o.connect(g).connect(drums!);
  o.start(t);
  o.stop(t + 0.4);
  // sidechain pump
  synths!.gain.cancelScheduledValues(t);
  synths!.gain.setValueAtTime(0.35, t);
  synths!.gain.linearRampToValueAtTime(1, t + 0.22);
}

function noiseHit(c: AudioContext, t: number, type: BiquadFilterType, freq: number, peak: number, decay: number, q = 0.8) {
  const buf = noiseBuffer();
  if (!buf) return;
  const s = c.createBufferSource();
  s.buffer = buf;
  const f = c.createBiquadFilter();
  f.type = type;
  f.frequency.value = freq;
  f.Q.value = q;
  const g = c.createGain();
  env(g, t, peak, 0.001, decay);
  s.connect(f).connect(g).connect(drums!);
  s.start(t, Math.random() * 0.5);
  s.stop(t + decay + 0.05);
}

const clap = (c: AudioContext, t: number) => {
  noiseHit(c, t, 'bandpass', 1600, 0.5, 0.05, 1.2);
  noiseHit(c, t + 0.012, 'bandpass', 1500, 0.45, 0.06, 1.2);
  noiseHit(c, t + 0.025, 'bandpass', 1400, 0.55, 0.16, 1);
};
const hat = (c: AudioContext, t: number, open: boolean) => noiseHit(c, t, 'highpass', 7500, open ? 0.16 : 0.09, open ? 0.12 : 0.035, 0.5);

function bassNote(c: AudioContext, t: number, midi: number, dur: number) {
  const o = c.createOscillator();
  o.type = 'sawtooth';
  o.frequency.value = mtof(midi);
  const o2 = c.createOscillator();
  o2.type = 'square';
  o2.frequency.value = mtof(midi - 12);
  const f = c.createBiquadFilter();
  f.type = 'lowpass';
  f.Q.value = 6;
  f.frequency.setValueAtTime(900, t);
  f.frequency.exponentialRampToValueAtTime(160, t + dur);
  const g = c.createGain();
  env(g, t, 0.32, 0.005, dur);
  o.connect(f);
  o2.connect(f);
  f.connect(g).connect(synths!);
  o.start(t);
  o2.start(t);
  o.stop(t + dur + 0.05);
  o2.stop(t + dur + 0.05);
}

function arpNote(c: AudioContext, t: number, midi: number, type: OscillatorType, bright: number) {
  const g = c.createGain();
  env(g, t, 0.075, 0.004, 0.17);
  const f = c.createBiquadFilter();
  f.type = 'lowpass';
  f.frequency.value = bright;
  for (const det of [-7, 7]) {
    const o = c.createOscillator();
    o.type = type;
    o.frequency.value = mtof(midi);
    o.detune.value = det;
    o.connect(f);
    o.start(t);
    o.stop(t + 0.25);
  }
  f.connect(g);
  g.connect(synths!);
  g.connect(delay!);
}

function pad(c: AudioContext, t: number, notes: number[], dur: number) {
  const g = c.createGain();
  g.gain.setValueAtTime(0.0001, t);
  g.gain.linearRampToValueAtTime(0.035, t + 0.4);
  g.gain.setValueAtTime(0.035, t + dur - 0.3);
  g.gain.linearRampToValueAtTime(0.0001, t + dur);
  const f = c.createBiquadFilter();
  f.type = 'lowpass';
  f.frequency.value = 1300;
  for (const n of notes)
    for (const det of [-10, 0, 10]) {
      const o = c.createOscillator();
      o.type = 'sawtooth';
      o.frequency.value = mtof(n);
      o.detune.value = det;
      o.connect(f);
      o.start(t);
      o.stop(t + dur + 0.05);
    }
  f.connect(g).connect(synths!);
}

function riser(c: AudioContext, t: number, dur: number) {
  const buf = noiseBuffer();
  if (!buf) return;
  const s = c.createBufferSource();
  s.buffer = buf;
  s.loop = true;
  const f = c.createBiquadFilter();
  f.type = 'bandpass';
  f.Q.value = 3;
  f.frequency.setValueAtTime(400, t);
  f.frequency.exponentialRampToValueAtTime(8000, t + dur);
  const g = c.createGain();
  g.gain.setValueAtTime(0.0001, t);
  g.gain.exponentialRampToValueAtTime(0.18, t + dur);
  g.gain.linearRampToValueAtTime(0.0001, t + dur + 0.05);
  s.connect(f).connect(g).connect(drums!);
  s.start(t);
  s.stop(t + dur + 0.1);
}

// ── sequencer ────────────────────────────────────────────────────────────────
let step = 0; // 16th notes since start
let nextTime = 0;
let timer: ReturnType<typeof setInterval> | null = null;

const chordTones = (ch: Chord, base: number) => {
  const third = ch[1] === 'm' ? 3 : 4;
  const r = base + ch[0];
  return [r, r + third, r + 7, r + 12, r + 12 + third, r + 19];
};

function scheduleStep(c: AudioContext, s: number, t: number) {
  const tr = track;
  const i = s % 16;
  const bar = Math.floor(s / 16);
  const section = bar % 16; // 16-bar song
  const intro = section < 2;
  const fillBar = section === 7 || section === 15;
  const ch = tr.prog[bar % tr.prog.length];
  const stepDur = 60 / tr.bpm / 4;

  // drums
  if (tr.kick[i] === 'x' && !(fillBar && i >= 12)) kick(c, t);
  if (!intro && tr.clap[i] === 'x') clap(c, t);
  if (fillBar && i >= 12) noiseHit(c, t, 'bandpass', 1800 + (i - 12) * 300, 0.35, 0.06, 1);
  if (tr.hat[i] === 'x' && !(intro && i % 4 !== 2)) hat(c, t, false);
  if (!intro && tr.ohat[i] === 'x') hat(c, t, true);
  if (fillBar && i === 0) riser(c, t, stepDur * 16);

  // bass
  if (tr.bass[i] === 'x') bassNote(c, t, tr.root + ch[0] + (i % 8 === 6 && section > 3 ? 12 : 0), stepDur * 0.9);

  // pad on each bar
  if (i === 0) pad(c, t, chordTones(ch, tr.root + 24).slice(0, 3), stepDur * 16);

  // arpeggio (from bar 2), brighter as the song builds
  if (!intro) {
    const idx = tr.arp[i];
    if (idx >= 0) {
      const tones = chordTones(ch, tr.root + 36);
      const bright = 1800 + Math.min(section, 8) * 350;
      arpNote(c, t, tones[idx % tones.length], tr.lead, bright);
    }
  }
}

function tick() {
  const c = audio();
  if (!c || !playing) return;
  const ahead = 0.15;
  while (nextTime < c.currentTime + ahead) {
    scheduleStep(c, step, nextTime);
    nextTime += 60 / track.bpm / 4;
    step++;
  }
}

function fadeTo(v: number, sec = 0.6) {
  const c = audio();
  if (!c || !bus) return;
  bus.gain.cancelScheduledValues(c.currentTime);
  bus.gain.setValueAtTime(bus.gain.value, c.currentTime);
  bus.gain.linearRampToValueAtTime(v, c.currentTime + sec);
}

export function startMusic(id?: string) {
  unlockAudio();
  const c = graph();
  if (!c) return;
  if (id) setTrackId(id);
  saved = { ...saved, on: true };
  persist();
  if (playing) return emit();
  playing = true;
  if (delay) delay.delayTime.value = (60 / track.bpm) * 0.75;
  step = 0;
  nextTime = c.currentTime + 0.08;
  timer = setInterval(tick, 25);
  tick();
  fadeTo(saved.volume * 0.85, 0.8);
  emit();
}

/** Stops playback. `remember` = the visitor chose to mute (kept across pages). */
export function stopMusic(remember = true) {
  if (remember) {
    saved = { ...saved, on: false };
    persist();
  }
  if (!playing) return emit();
  playing = false;
  fadeTo(0, 0.4);
  if (timer) clearInterval(timer);
  timer = null;
  emit();
}

function setTrackId(id: string) {
  const t = TRACKS.find((x) => x.id === id);
  if (!t || t === track) return;
  track = t;
  saved = { ...saved, track: t.id };
  persist();
  if (delay) delay.delayTime.value = (60 / track.bpm) * 0.75;
  // restart on the next bar boundary so the groove doesn't stumble
  step = Math.ceil(step / 16) * 16;
}

export function setTrack(id: string) {
  setTrackId(id);
  emit();
}

export function nextTrack() {
  const i = TRACKS.indexOf(track);
  setTrack(TRACKS[(i + 1) % TRACKS.length].id);
}

export function setVolume(v: number) {
  saved = { ...saved, volume: Math.max(0, Math.min(1, v)) };
  persist();
  if (playing) fadeTo(saved.volume * 0.85, 0.15);
  emit();
}

export function toggleMusic() {
  if (playing) stopMusic();
  else startMusic();
}

/** Starts music on a gesture if the visitor hasn't muted it. */
export function autoStartMusic(id?: string) {
  if (saved.on) startMusic(id);
}
