import { useEffect, useState, useSyncExternalStore } from 'react';
import { accounts, DEFAULT_SETTINGS, type LogEvent, type Saved, type SavedSession, type SavedTraining, type Settings, type TeamProfile } from '../engine/accounts';

// ── tiny external store helper ───────────────────────────────────────────────
function cell<T>(initial: T) {
  let v = initial;
  const subs = new Set<() => void>();
  return {
    get: () => v,
    set: (n: T) => {
      v = n;
      subs.forEach((f) => f());
    },
    use: () =>
      useSyncExternalStore(
        (f) => {
          subs.add(f);
          return () => subs.delete(f);
        },
        () => v,
      ),
  };
}

function readLS<T>(k: string, store: 'local' | 'session' = 'local'): T | null {
  try {
    const s = store === 'local' ? localStorage : sessionStorage;
    const v = s.getItem(k);
    return v ? (JSON.parse(v) as T) : null;
  } catch {
    return null;
  }
}
function writeLS(k: string, v: unknown, store: 'local' | 'session' = 'local') {
  try {
    const s = store === 'local' ? localStorage : sessionStorage;
    if (v === null) s.removeItem(k);
    else s.setItem(k, JSON.stringify(v));
  } catch {
    /* blocked */
  }
}

// ── logged-in team ───────────────────────────────────────────────────────────
const TEAM_KEY = 'ctf360.team.v1';
export type TeamLogin = Pick<TeamProfile, 'id' | 'name' | 'avatar'> & { token?: string };
const team = cell<TeamLogin | null>(readLS<TeamLogin>(TEAM_KEY));
export const useTeam = team.use;
export const currentTeam = team.get;
export function setTeam(t: TeamLogin | null) {
  writeLS(TEAM_KEY, t);
  team.set(t);
}

// ── admin (this tab only; expires after 8 hours) ─────────────────────────────
const ADMIN_KEY = 'ctf360.admin.v1';
const adminUntil = readLS<number>(ADMIN_KEY, 'session') ?? 0;
const admin = cell<boolean>(adminUntil > Date.now());
export const useAdmin = admin.use;
export const isAdmin = admin.get;
export function setAdmin(on: boolean) {
  writeLS(ADMIN_KEY, on ? Date.now() + 8 * 3600_000 : null, 'session');
  admin.set(on);
}

// ── competition lock settings ────────────────────────────────────────────────
const settings = cell<Settings & { loaded: boolean }>({ ...DEFAULT_SETTINGS, loaded: false });
let settingsStarted = false;
export function useSettings() {
  const v = settings.use();
  useEffect(() => {
    if (settingsStarted) return;
    settingsStarted = true;
    void accounts().then((a) => a.watchSettings((s) => settings.set({ ...s, loaded: true })));
  }, []);
  return v;
}

// ── activity log + progress sync ─────────────────────────────────────────────
let queue: LogEvent[] = [];
let lastSession: SavedSession | undefined;
let trainingGetter: () => SavedTraining | undefined = () => undefined;
let timer: ReturnType<typeof setTimeout> | null = null;

export function registerTrainingGetter(fn: () => SavedTraining | undefined) {
  trainingGetter = fn;
}

/** Records one thing a logged-in team did (answers are only readable by the admin). */
export function logEvent(ev: Omit<LogEvent, 't'>) {
  if (!team.get()) return;
  queue.push({ ...ev, t: Date.now(), answer: ev.answer?.slice(0, 200) });
  scheduleSave();
}

export function queueSession(s: SavedSession | undefined) {
  lastSession = s;
  scheduleSave();
}

export function scheduleSave(delay = 1200) {
  if (!team.get()) return;
  if (timer) clearTimeout(timer);
  timer = setTimeout(flush, delay);
}

async function flush() {
  timer = null;
  const t = team.get();
  if (!t) return;
  const events = queue;
  queue = [];
  const saved: Saved = { session: lastSession, training: trainingGetter(), updatedAt: Date.now() };
  const a = await accounts();
  await a.save(t.id, saved, events, t.token);
}
/** Writes anything pending right now (before logging out). */
export async function flushNow() {
  if (timer) {
    clearTimeout(timer);
    await flush();
  }
}
window.addEventListener('pagehide', () => {
  if (timer) {
    clearTimeout(timer);
    void flush();
  }
});

/** The back-end mode, for labels ("shared", "server", "local"). */
export function useAccountsMode() {
  const [m, setM] = useState<{ mode: string; canWrite: boolean } | null>(null);
  useEffect(() => {
    let live = true;
    void accounts().then(async (a) => {
      const canWrite = await a.canWrite();
      if (live) setM({ mode: a.mode, canWrite });
    });
    return () => {
      live = false;
    };
  }, []);
  return m;
}
