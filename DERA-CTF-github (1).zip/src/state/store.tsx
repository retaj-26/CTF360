import { createContext, useCallback, useContext, useEffect, useMemo, useReducer, useRef, type ReactNode } from 'react';
import type { Lang, RoomId } from '../engine/types';
import { CHALLENGES, FINAL_CHALLENGE, byId } from '../data/challenges';
import { ROOMS } from '../data/rooms';
import { pointsFor } from '../engine/scoring';
import { board } from '../engine/board';
import { queueSession, currentTeam } from './auth';
import { useTraining, trainScore } from './training';
import type { TeamProfile, SavedSession } from '../engine/accounts';

// ── Shapes ────────────────────────────────────────────────────────────────────
export interface ChallengeProgress {
  solved: boolean;
  points: number;
  hintsUsed: number;
  wrong: number;
  /** Index of the stage the visitor is on. */
  stage: number;
  /** Correct answers of completed stages (so a refresh resumes mid-challenge). */
  answers: string[];
  openedAt?: number;
  solvedAt?: number;
  decoded?: boolean;
}

export interface Session {
  v: 1;
  id: string;
  /** Team name (kept as `codename` for compatibility with saved sessions). */
  codename: string;
  members: string[];
  /** Avatar id from the team profile. */
  avatar?: string;
  /** Set for a logged-in team (equals `id`). */
  teamId?: string;
  /** Admin's private test run — never synced or ranked. */
  adminTest?: boolean;
  startedAt: number;
  finishedAt?: number;
  progress: Record<string, ChallengeProgress>;
  inspected: string[];
  seenReports: RoomId[];
}

export interface Prefs {
  lang: Lang;
  sound: boolean;
  motion: 'system' | 'reduced' | 'full';
  exhibition: boolean;
  introSeen: boolean;
}

interface State {
  session: Session | null;
  prefs: Prefs;
}

const SESSION_KEY = 'ctf360.session.v1';
const PREFS_KEY = 'ctf360.prefs.v1';

const emptyProgress = (): ChallengeProgress => ({ solved: false, points: 0, hintsUsed: 0, wrong: 0, stage: 0, answers: [] });

function load<T>(key: string): T | null {
  try {
    const raw = localStorage.getItem(key);
    return raw ? (JSON.parse(raw) as T) : null;
  } catch {
    return null;
  }
}
function save(key: string, value: unknown) {
  try {
    if (value === null) localStorage.removeItem(key);
    else localStorage.setItem(key, JSON.stringify(value));
  } catch {
    /* storage unavailable (private mode) — game still works for this tab */
  }
}

const defaultPrefs: Prefs = { lang: 'ar', sound: false, motion: 'system', exhibition: false, introSeen: false };

// ── Codenames (anonymous, no personal data) ───────────────────────────────────
const CODE_A = ['صقور', 'ذئاب', 'نمور', 'فهود', 'نسور', 'أسود', 'عقبان', 'شواهين'];
const CODE_B = ['الشبكة', 'الكود', 'التشفير', 'الجدار', 'البايت', 'المفتاح', 'السيرفر', 'الرمز'];
export function randomCodename() {
  const r = (n: number) => Math.floor(Math.random() * n);
  return `${CODE_A[r(CODE_A.length)]} ${CODE_B[r(CODE_B.length)]} ${r(90) + 10}`;
}

function newSession(codename: string, members: string[]): Session {
  return {
    v: 1,
    id: Math.random().toString(36).slice(2, 10) + Date.now().toString(36).slice(-4),
    codename,
    members,
    startedAt: Date.now(),
    progress: {},
    inspected: [],
    seenReports: [],
  };
}

// ── Reducer ───────────────────────────────────────────────────────────────────
type Action =
  | { type: 'start'; codename: string; members?: string[] }
  | { type: 'login'; team: TeamProfile; saved?: SavedSession | null }
  | { type: 'reset' }
  | { type: 'pref'; patch: Partial<Prefs> }
  | { type: 'open'; id: string }
  | { type: 'hint'; id: string }
  | { type: 'wrong'; id: string }
  | { type: 'decoded'; id: string }
  | { type: 'inspect'; item: string }
  | { type: 'stage'; id: string; answer: string }
  | { type: 'solve'; id: string; answer: string }
  | { type: 'seenReport'; room: RoomId };

function withProgress(s: Session, id: string, fn: (p: ChallengeProgress) => ChallengeProgress): Session {
  const cur = s.progress[id] ?? emptyProgress();
  return { ...s, progress: { ...s.progress, [id]: fn(cur) } };
}

function reducer(state: State, a: Action): State {
  if (a.type === 'pref') return { ...state, prefs: { ...state.prefs, ...a.patch } };
  if (a.type === 'start')
    return {
      ...state,
      session: {
        ...newSession(
          a.codename.trim().slice(0, 32) || randomCodename(),
          (a.members ?? []).map((m) => m.trim().slice(0, 32)).filter(Boolean).slice(0, 6),
        ),
        adminTest: true,
      },
    };
  if (a.type === 'login') {
    const sv = a.saved;
    return {
      ...state,
      session: {
        v: 1,
        id: a.team.id,
        teamId: a.team.id,
        codename: a.team.name,
        members: a.team.members.map((m) => (m.emoji ? `${m.emoji} ${m.name}` : m.name)),
        avatar: a.team.avatar,
        startedAt: sv?.startedAt ?? Date.now(),
        finishedAt: sv?.finishedAt,
        progress: sv?.progress ?? {},
        inspected: sv?.inspected ?? [],
        seenReports: (sv?.seenReports ?? []) as RoomId[],
      },
    };
  }
  if (a.type === 'reset') return { ...state, session: null };
  const s = state.session;
  if (!s) return state;
  switch (a.type) {
    case 'open':
      return { ...state, session: withProgress(s, a.id, (p) => (p.openedAt ? p : { ...p, openedAt: Date.now() })) };
    case 'hint':
      return {
        ...state,
        session: withProgress(s, a.id, (p) => (p.solved || p.hintsUsed >= 2 ? p : { ...p, hintsUsed: p.hintsUsed + 1 })),
      };
    case 'wrong':
      return { ...state, session: withProgress(s, a.id, (p) => (p.solved ? p : { ...p, wrong: p.wrong + 1 })) };
    case 'decoded':
      return { ...state, session: withProgress(s, a.id, (p) => ({ ...p, decoded: true })) };
    case 'inspect':
      return s.inspected.includes(a.item) ? state : { ...state, session: { ...s, inspected: [...s.inspected, a.item] } };
    case 'stage':
      return {
        ...state,
        session: withProgress(s, a.id, (p) => (p.solved ? p : { ...p, stage: p.stage + 1, answers: [...p.answers, a.answer] })),
      };
    case 'solve': {
      const p = s.progress[a.id] ?? emptyProgress();
      if (p.solved) return state; // never award the same challenge twice
      const c = byId(a.id);
      const now = Date.now();
      const overTime = !!(c.timeLimitSec && p.openedAt && now - p.openedAt > c.timeLimitSec * 1000);
      const points = pointsFor(c.basePoints, p.hintsUsed, overTime, c.difficulty === 'intro');
      let next = withProgress(s, a.id, () => ({
        ...p,
        solved: true,
        points,
        solvedAt: now,
        stage: c.stages.length,
        answers: [...p.answers, a.answer],
      }));
      if (a.id === FINAL_CHALLENGE.id) next = { ...next, finishedAt: now };
      return { ...state, session: next };
    }
    case 'seenReport':
      return s.seenReports.includes(a.room) ? state : { ...state, session: { ...s, seenReports: [...s.seenReports, a.room] } };
  }
}

// ── Derived stats ─────────────────────────────────────────────────────────────
export function stats(session: Session | null) {
  const prog = session?.progress ?? {};
  const solvedIds = CHALLENGES.filter((c) => prog[c.id]?.solved).map((c) => c.id);
  const roomsDone = ROOMS.filter((r) => r.challengeIds.every((id) => prog[id]?.solved)).map((r) => r.id);
  const all = [...CHALLENGES, FINAL_CHALLENGE];
  const score = all.reduce((sum, c) => sum + (prog[c.id]?.points ?? 0), 0);
  const hints = all.reduce((sum, c) => sum + (prog[c.id]?.hintsUsed ?? 0), 0);
  const maxScore = all.reduce((sum, c) => sum + c.basePoints, 0);
  const finalSolved = !!prog[FINAL_CHALLENGE.id]?.solved;
  return {
    solved: solvedIds.length,
    total: CHALLENGES.length,
    roomsDone,
    score,
    maxScore,
    hints,
    vaultOpen: solvedIds.length === CHALLENGES.length,
    finalSolved,
    progressPct: Math.round(((solvedIds.length + (finalSolved ? 1 : 0)) / (CHALLENGES.length + 1)) * 100),
  };
}

export function roomProgress(session: Session | null, roomId: RoomId) {
  const r = ROOMS.find((x) => x.id === roomId)!;
  const done = r.challengeIds.filter((id) => session?.progress[id]?.solved).length;
  return { done, total: r.challengeIds.length, complete: done === r.challengeIds.length };
}

// ── Context ───────────────────────────────────────────────────────────────────
interface Store extends State {
  dispatch: (a: Action) => void;
  t: <T>(l: { ar: T; en: T }) => T;
  progressOf: (id: string) => ChallengeProgress;
  reducedMotion: boolean;
}

const Ctx = createContext<Store | null>(null);

function systemReduced() {
  return typeof window !== 'undefined' && window.matchMedia?.('(prefers-reduced-motion: reduce)').matches;
}

export function StoreProvider({ children }: { children: ReactNode }) {
  const [state, dispatch] = useReducer(reducer, null, () => ({
    session: load<Session>(SESSION_KEY),
    prefs: { ...defaultPrefs, ...(load<Prefs>(PREFS_KEY) ?? {}), lang: 'ar' as const, sound: false },
  }));

  useEffect(() => save(SESSION_KEY, state.session), [state.session]);

  // Push this team's standing to the leaderboard whenever it actually changes.
  const tr = useTraining();
  const tScore = trainScore(tr);
  const lastPushed = useRef('');
  useEffect(() => {
    const s = state.session;
    if (!s || !s.teamId || s.adminTest || currentTeam()?.id !== s.teamId) return;
    queueSession({ startedAt: s.startedAt, finishedAt: s.finishedAt, progress: s.progress, inspected: s.inspected, seenReports: s.seenReports });
    const st = stats(s);
    const solvedTimes = Object.values(s.progress)
      .map((p) => p.solvedAt ?? 0)
      .filter(Boolean);
    const rec = {
      id: s.id,
      name: s.codename,
      members: s.members ?? [],
      avatar: s.avatar ?? '',
      trainScore: tScore,
      score: st.score,
      solved: st.solved + (st.finalSolved ? 1 : 0),
      total: st.total + 1,
      hints: st.hints,
      startedAt: s.startedAt,
      scoredAt: solvedTimes.length ? Math.max(...solvedTimes) : s.startedAt,
      finishedAt: s.finishedAt ?? null,
      updatedAt: 0,
    };
    const key = JSON.stringify(rec);
    if (key === lastPushed.current) return;
    lastPushed.current = key;
    void board.upsert({ ...rec, updatedAt: Date.now() });
  }, [state.session, tScore]);
  useEffect(() => save(PREFS_KEY, state.prefs), [state.prefs]);

  // Keep several tabs (e.g. facilitator + kiosk) in sync.
  useEffect(() => {
    const onStorage = (e: StorageEvent) => {
      if (e.key === SESSION_KEY && !e.newValue) dispatch({ type: 'reset' });
    };
    window.addEventListener('storage', onStorage);
    return () => window.removeEventListener('storage', onStorage);
  }, []);

  const reducedMotion = state.prefs.motion === 'reduced' || (state.prefs.motion === 'system' && systemReduced());

  useEffect(() => {
    const html = document.documentElement;
    html.lang = state.prefs.lang;
    html.dir = state.prefs.lang === 'ar' ? 'rtl' : 'ltr';
    html.dataset.motion = reducedMotion ? 'reduced' : 'full';
    html.dataset.exhibition = state.prefs.exhibition ? 'on' : 'off';
  }, [state.prefs.lang, state.prefs.exhibition, reducedMotion]);

  const t = useCallback(<T,>(l: { ar: T; en: T }) => l[state.prefs.lang], [state.prefs.lang]);
  const progressOf = useCallback((id: string) => state.session?.progress[id] ?? emptyProgress(), [state.session]);

  const value = useMemo(() => ({ ...state, dispatch, t, progressOf, reducedMotion }), [state, t, progressOf, reducedMotion]);
  return <Ctx.Provider value={value}>{children}</Ctx.Provider>;
}

export function useStore() {
  const v = useContext(Ctx);
  if (!v) throw new Error('useStore outside provider');
  return v;
}
