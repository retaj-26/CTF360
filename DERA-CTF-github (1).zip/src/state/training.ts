import { useSyncExternalStore } from 'react';
import { TRAINING, type TrainChallenge } from '../data/training';
import type { L10n } from '../engine/types';
import { TRAIN_KEYS } from '../data/trainKeys.generated';
import { sha256Hex } from '../engine/sha256';
import { normalize, hashInput } from '../engine/normalize';
import { logEvent, registerTrainingGetter, scheduleSave } from './auth';

// Practice progress for the bootcamp — kept on this device only.
const KEY = 'ctf360.train.v1';
export type TrainState = { solved: Record<string, number>; flags?: Record<string, string>; picks?: Record<string, string> };

let state: TrainState = load();
const subs = new Set<() => void>();

function load(): TrainState {
  try {
    const v = JSON.parse(localStorage.getItem(KEY) || 'null');
    if (v && typeof v === 'object' && v.solved) return v;
  } catch {
    /* ignore */
  }
  return { solved: {} };
}
function commit(next: TrainState) {
  state = next;
  try {
    localStorage.setItem(KEY, JSON.stringify(state));
  } catch {
    /* storage blocked */
  }
  subs.forEach((f) => f());
  scheduleSave();
}

registerTrainingGetter(() => state);

/** After a team logs in: use the team's saved training (or keep this device's practice if the team has none yet). */
export function adoptTraining(saved: TrainState | undefined) {
  if (saved && saved.solved && Object.keys(saved.solved).length) commit({ solved: saved.solved, flags: saved.flags ?? {}, picks: saved.picks ?? {} });
  else scheduleSave();
}

export function useTraining() {
  return useSyncExternalStore(
    (f) => {
      subs.add(f);
      return () => subs.delete(f);
    },
    () => state,
  );
}

export function trainScore(st: TrainState) {
  return TRAINING.reduce((n, c) => n + (st.solved[c.id] ? c.points : 0), 0);
}

export function resetTraining() {
  commit({ solved: {}, flags: {}, picks: {} });
}

export type TrainVerdict = { ok: boolean; msg?: L10n; flag?: string };

const FORMAT = { ar: 'قريبة جدًا! اكتبيها بالصيغة: DERA{...}', en: 'So close! Write it in the format DERA{...}' };
const WRONG_FMT = { ar: 'الصيغة صح، بس الإجابة مو هي. ارجعي للأدلة واقرئي السؤال مرة ثانية.', en: 'Right format, wrong answer. Go back to the evidence and re-read the question.' };
const NO_FMT = { ar: 'مو صحيحة. تذكّري: الإجابة تبدأ بـ DERA{ وتنتهي بـ }', en: 'Not quite. Remember: answers start with DERA{ and end with }' };

const matches = (id: string, value: string) => {
  const h = sha256Hex(hashInput(`train:${id}`, 0, value));
  return (TRAIN_KEYS[id] ?? []).includes(h);
};

/** The flag shown for a solved challenge (stored at capture time). */
export function capturedFlag(c: TrainChallenge, st: TrainState) {
  return st.flags?.[c.id] ?? (c.reward ?? '');
}

/** Checks an answer against salted hashes, records the capture, and explains wrong answers kindly. */
export function submitTraining(c: TrainChallenge, raw: string): TrainVerdict {
  let ok = false;
  let inner = '';
  let flag = '';
  if (c.kind === 'choice') {
    ok = matches(c.id, raw);
    inner = raw;
    flag = c.reward ?? '';
  } else {
    const n = normalize(raw, 'flag');
    const m = n.match(/^dera\{(.*)\}$/);
    inner = m ? m[1] : n;
    ok = !!m && matches(c.id, inner);
    if (!ok && !m && matches(c.id, n)) return { ok: false, msg: FORMAT };
    const typed = raw.replace(/\s+/g, '').match(/\{(.*)\}/);
    flag = `DERA{${typed ? typed[1] : inner}}`;
  }
  logEvent({ area: 'train', cid: c.id, kind: 'attempt', answer: raw, ok, pts: ok && !state.solved[c.id] ? c.points : 0 });
  if (ok) {
    if (!state.solved[c.id]) commit({
        solved: { ...state.solved, [c.id]: Date.now() },
        flags: { ...(state.flags ?? {}), [c.id]: flag },
        picks: c.kind === 'choice' ? { ...(state.picks ?? {}), [c.id]: raw } : state.picks,
      });
    return { ok: true, flag };
  }
  const W = c.wrong ?? {};
  const key = Object.keys(W).find((k) => normalize(k, 'flag') === inner.toLowerCase());
  if (key) return { ok: false, msg: W[key] };
  if (c.kind === 'flag') return { ok: false, msg: /^dera\{/.test(normalize(raw, 'flag')) ? WRONG_FMT : NO_FMT };
  return { ok: false };
}
