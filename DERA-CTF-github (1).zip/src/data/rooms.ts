import type { Room, RoomId } from '../engine/types';

export const ROOMS: Room[] = [
  {
    id: 'helpdesk',
    index: 1,
    clue: { ar: 'المسار الأول', en: 'Track 01' },
    icon: 'headset',
    name: { ar: 'المسار الأول', en: 'Track 01' },
    category: { ar: 'البلاغ العاجل', en: 'The Urgent Ticket' },
    difficulty: { ar: 'سهل ← متوسط سهل ← متوسط', en: 'Easy → Easy-medium → Medium' },
    minutes: '3–5',
    story: {
      ar: 'حساب الموظفة رزان يتصرف بغرابة. ابدئي من بريدها، ردّي على المكالمات، واكتشفي وش الخطأ في كلمة مرورها.',
      en: 'Staff member Razan’s account is acting strangely. Start with her inbox, answer the calls, and find what’s wrong with her password.',
    },
    teaser: {
      ar: 'رسالة تصيّد، خط دعم ساخن، وكلمة مرور مكشوفة.',
      en: 'A phishing email, a busy hotline, an exposed password.',
    },
    accent: '#C6FF33',
    challengeIds: ['r1-phish', 'r1-calls', 'r1-password'],
    fragment: 'DONT',
    report: {
      ar: 'تأكدنا: رزان دخلت بياناتها في صفحة تصيّد، وكلمة مرورها ضعيفة ومكررة. المهاجم صار معه مفتاح الباب… ودخل الشبكة.',
      en: 'Confirmed: Razan typed her login into a phishing page, and her password was weak and reused. The attacker now had a key to the door… and moved into the network.',
    },
    lesson: {
      ar: 'أغلب الاختراقات تبدأ بخطأ بشري بسيط — والدعم الفني هو خط الدفاع الأول.',
      en: 'Most breaches start with a simple human mistake — and IT support is the first line of defence.',
    },
  },
  {
    id: 'network',
    index: 2,
    clue: { ar: 'المسار الثاني', en: 'Track 02' },
    icon: 'network',
    name: { ar: 'المسار الثاني', en: 'Track 02' },
    category: { ar: 'الدخيل الخفي', en: 'The Hidden Intruder' },
    difficulty: { ar: 'سهل ← متوسط سهل ← متوسط', en: 'Easy → Easy-medium → Medium' },
    minutes: '4–6',
    story: {
      ar: 'المهاجم يتحرك داخل المعرض. رجّعي الاتصال لفريق الأمن، وقفي كجدار ناري، واكشفي شبكة الواي فاي المزيّفة.',
      en: 'The attacker is moving through the expo network. Restore the security team’s link, stand guard as the firewall, and expose the fake Wi-Fi.',
    },
    teaser: {
      ar: 'وصلة مقطوعة، جدار ناري تحت الضغط، وواي فاي مزيّف.',
      en: 'A broken link, a firewall under pressure, a fake Wi-Fi.',
    },
    accent: '#A66BFF',
    challengeIds: ['r2-link', 'r2-wifi', 'r2-firewall'],
    fragment: 'OPEN',
    report: {
      ar: 'الوصلة رجعت، الحزم الخبيثة انحظرت، والشبكة المزيّفة انكشفت. بس كيف سيطر المهاجم على الخادم؟ الجواب في الكود.',
      en: 'The network is under control: the link is back, the malicious packets are blocked, the fake Wi-Fi exposed. But how did the attacker take the server? The answer is in the code.',
    },
    lesson: {
      ar: 'الشبكة الآمنة تعزل الزوار عن الخوادم، وتسمح بس باللي يحتاجه العمل.',
      en: 'A secure network isolates guests from servers and allows only what the work needs.',
    },
  },
  {
    id: 'code',
    index: 3,
    clue: { ar: 'المسار الثالث', en: 'Track 03' },
    icon: 'code',
    name: { ar: 'المسار الثالث', en: 'Track 03' },
    category: { ar: 'المفتاح المنسي', en: 'The Forgotten Key' },
    difficulty: { ar: 'سهل ← متوسط سهل ← متوسط', en: 'Easy → Easy-medium → Medium' },
    minutes: '4–6',
    story: {
      ar: 'شخص مستعجل ترك ثغرات في الكود. أصلحي سكربت الإنذار، تتبّعي برنامج المهاجم، واستخرجي المفتاح اللي «أخفاه» المبرمج.',
      en: 'Someone in a hurry left holes in the code. Fix the alarm script, trace the attacker’s program, and extract the key the developer “hid”.',
    },
    teaser: {
      ar: 'سكربت معطوب، برنامج تخمين، ومفتاح مرمّز.',
      en: 'A broken script, a guessing program, an encoded key.',
    },
    accent: '#FF3DA1',
    challengeIds: ['r3-script', 'r3-trace', 'r3-secret'],
    fragment: 'THE_DOOR',
    report: {
      ar: 'الإنذار يشتغل، وفهمنا كيف يخمّن المهاجم الرموز، ولقينا المفتاح اللي سلّمه الخادم. صار عندك كل الأدلة — القبو الأخير مفتوح.',
      en: 'The alarm works, we understand how the attacker guesses codes, and we found the key that handed over the server. You have all the evidence — the final vault is open.',
    },
    lesson: {
      ar: 'الأسرار ما تنكتب داخل الكود، والترميز مو تشفير، وأي قفل يحتاج حد للمحاولات.',
      en: 'Secrets never belong in code, encoding isn’t encryption, and every lock needs an attempt limit.',
    },
  },
];

export const roomById = (id: RoomId) => ROOMS.find((r) => r.id === id)!;
