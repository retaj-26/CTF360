// ─────────────────────────────────────────────────────────────────────────────
//  DERA CTF · Training challenges.
//  New beginner challenges built on the concepts taught in the session:
//  IP address, Gateway, DNS, IT-support troubleshooting, reading logs/clues,
//  and very short code. Practice only — checked in the browser.
// ─────────────────────────────────────────────────────────────────────────────
import type { L10n } from '../engine/types';

export type TrainSection = 'start' | 'net' | 'support' | 'clues' | 'code' | 'lab';
export type Tone = 'lime' | 'violet' | 'pink' | 'ink';

export type TermLine = { t: string; k?: 'cmd' | 'dim' | 'hl' | 'ok' | 'bad' | 'hidden'; tap?: string };
export type Tile = { label: string; icon: 'plane' | 'wifi' | 'volume' | 'bt' | 'printer' | 'paper' | 'battery'; before: string; after: string; bad?: boolean };

export type TrainScreen =
  | { type: 'term'; title: string; lines: TermLine[] }
  | { type: 'kv'; title: string; status: string; rows: { k: string; v: string }[] }
  | { type: 'log'; title: string; cols: string[]; rows: string[][]; tapCols: number[]; hotCol: number }
  | { type: 'bars'; title: string; col: string; unit: string; rows: { app: string; v: number }[] }
  | { type: 'code'; file: string; lines: string[]; output: string }
  | { type: 'tiles'; title: string; tiles: Tile[] }
  | { type: 'email'; fromName: string; fromAddr: string; to: string; subject: string; body: string[] }
  | { type: 'login'; user: string };

export interface TrainChallenge {
  id: string;
  section: TrainSection;
  title: string;
  mission: L10n;
  story?: L10n;
  ticket?: { id: string; text: L10n };
  points: number;
  kind: 'flag' | 'choice';
  format?: string;
  options?: { id: string; label: L10n }[];
  /** Cosmetic flag shown after a correct choice. Answers themselves live hashed in trainKeys.generated.ts. */
  reward?: string;
  hint: L10n;
  learn: L10n;
  wrong?: Record<string, L10n>;
  screen: TrainScreen;
}

const s = (ar: string, en: string) => ({ ar, en });

export const TRAINING: TrainChallenge[] = [
  // ───────────── START ─────────────
  {
    id: 'w-welcome',
    section: 'start',
    title: 'Welcome Flag',
    story: s('كل CTF يبدأ بعلم ترحيبي.', 'Every CTF starts with a welcome flag.'),
    mission: s('العلم مخبّى داخل الشاشة بنفس لون الخلفية. ظلّليه بالماوس (أو اضغطي مطوّلاً على الجوال) وانسخيه.', 'The flag is hidden on the screen in the background colour. Highlight it (or long-press on mobile) and copy it.'),
    points: 5,
    kind: 'flag',
    format: 'DERA{...}',
    hint: s('ظلّلي المساحة الفاضية تحت سطر status.', 'Highlight the empty space below the status line.'),
    learn: s('في CTF المعلومة أحياناً موجودة قدامك بس مخفية. دايماً افحصي الصفحة كاملة.', 'In CTFs the information is often right there, just hidden. Always inspect the whole page.'),
    screen: {
      type: 'term',
      title: 'welcome.sh',
      lines: [
        { t: '$ ./welcome.sh', k: 'cmd' },
        { t: 'Loading DERA CTF training...' },
        { t: 'status: ready', k: 'hl' },
        { t: '' },
        { t: 'flag: DERA{WELCOME_HACKER}', k: 'hidden' },
        { t: '' },
      ],
    },
  },
  {
    id: 'w-format',
    section: 'start',
    title: 'Read the Rules',
    mission: s('قوانين المسابقة فيها جملة سرّية. اقرئيها بتركيز، واكتبي الكلمة السرية بصيغة الـFlag.', 'The competition rules hide a secret word. Read them carefully and submit it as a flag.'),
    points: 5,
    kind: 'flag',
    format: 'DERA{SECRET_WORD}',
    hint: s('القاعدة رقم 3 تقول لك وش الكلمة.', 'Rule 3 tells you the word.'),
    learn: s('أول خطوة في أي تحدي: اقرئي السؤال والتعليمات مرتين. نص الحل غالباً في التفاصيل.', 'Step one of any challenge: read the instructions twice. Half the solution is in the details.'),
    screen: {
      type: 'term',
      title: 'rules.txt',
      lines: [
        { t: '1. Every flag looks like DERA{...}' },
        { t: '2. Flags are not case-sensitive' },
        { t: '3. The secret word is: ', tap: 'FOCUS' },
        { t: '4. Never attack real systems', k: 'dim' },
      ],
    },
  },

  // ───────────── NETWORKING ─────────────
  {
    id: 'n-whoami',
    section: 'net',
    title: 'Who Am I?',
    story: s('جهاز المكتبة يحتاج يتعرّف على الشبكة.', 'The library PC needs to identify itself on the network.'),
    mission: s('من نتيجة الأمر ipconfig، وش عنوان IPv4 لهذا الجهاز؟', 'From the ipconfig output, what is this device’s IPv4 address?'),
    points: 10,
    kind: 'flag',
    format: 'DERA{IPv4}',
    hint: s('فيه ثلاث قيم شكلها أرقام ونقاط. وحدة بس جنبها كلمة IPv4.', 'Three values look like numbers and dots. Only one is labelled IPv4.'),
    learn: s('الـIP Address مثل عنوان البيت: يحدد مكان الجهاز داخل الشبكة عشان توصله البيانات.', 'An IP address is like a home address: it tells data where the device is.'),
    wrong: {
      '10.0.0.1': s('هذا عنوان الـGateway (باب الخروج)، مو الجهاز.', 'That’s the Gateway (the exit door), not the device.'),
      '255.0.0.0': s('هذا الـSubnet Mask، مو عنوان جهاز.', 'That’s the subnet mask, not a device address.'),
    },
    screen: {
      type: 'term',
      title: 'Command Prompt — LIB-PC-02',
      lines: [
        { t: 'C:\\> ipconfig', k: 'cmd' },
        { t: 'Ethernet adapter LAN:' },
        { t: '  Subnet Mask . . . . . : ', tap: '255.0.0.0' },
        { t: '  Default Gateway . . . : ', tap: '10.0.0.1' },
        { t: '  IPv4 Address . . . . : ', tap: '10.0.0.37' },
      ],
    },
  },
  {
    id: 'n-exit',
    section: 'net',
    title: 'The Exit Door',
    story: s('جوال متدربة متصل بالواي فاي، وتبي تعرف من وين تطلع بياناتها للإنترنت.', 'A trainee’s phone is on Wi-Fi and she wants to know where her data leaves for the internet.'),
    mission: s('وش عنوان الـRouter / Gateway في إعدادات الجوال؟', 'What is the Router / Gateway address in the phone settings?'),
    points: 10,
    kind: 'flag',
    format: 'DERA{Gateway IP}',
    hint: s('في الجوالات، الـGateway أحياناً اسمه Router.', 'On phones the Gateway is often called Router.'),
    learn: s('الـGateway هو «باب الخروج» من شبكتك للشبكات الثانية والإنترنت، وغالباً يكون الراوتر.', 'The Gateway is the exit door from your network to the internet — usually the router.'),
    wrong: {
      '172.16.5.88': s('هذا عنوان الجوال نفسه.', 'That’s the phone’s own address.'),
      '8.8.8.8': s('هذا خادم DNS، مو الـGateway.', 'That’s a DNS server, not the Gateway.'),
    },
    screen: {
      type: 'kv',
      title: 'Wi-Fi · CampusNet',
      status: 'Connected',
      rows: [
        { k: 'IP Address', v: '172.16.5.88' },
        { k: 'Subnet Mask', v: '255.255.255.0' },
        { k: 'Router', v: '172.16.5.1' },
        { k: 'DNS', v: '8.8.8.8' },
      ],
    },
  },
  {
    id: 'n-dns',
    section: 'net',
    title: 'Phone Book',
    story: s('الـDNS هو دليل الإنترنت: يحوّل اسم الموقع إلى عنوان IP.', 'DNS is the internet’s phone book: it turns a site name into an IP.'),
    mission: s('استخدمنا nslookup لثلاثة مواقع. وش عنوان IP الخاص بموقع library.dera.lab؟', 'We ran nslookup on three sites. What is the IP of library.dera.lab?'),
    points: 15,
    kind: 'flag',
    format: 'DERA{IP}',
    hint: s('دوّري على Name: library.dera.lab، والعنوان اللي تحته مباشرة.', 'Find Name: library.dera.lab and the address right below it.'),
    learn: s('نحن نحفظ الأسماء، والأجهزة تتعامل بالأرقام. الـDNS يربط بينهم.', 'We remember names; devices use numbers. DNS links the two.'),
    wrong: {
      '10.10.4.21': s('هذا عنوان mail.dera.lab.', 'That’s mail.dera.lab.'),
      '10.10.4.1': s('هذا عنوان خادم الـDNS نفسه.', 'That’s the DNS server itself.'),
      '10.10.4.30': s('هذا عنوان portal.dera.lab.', 'That’s portal.dera.lab.'),
    },
    screen: {
      type: 'term',
      title: 'nslookup',
      lines: [
        { t: 'Server:  ', tap: '10.10.4.1' },
        { t: '' },
        { t: 'Name:    mail.dera.lab', k: 'dim' },
        { t: 'Address: ', tap: '10.10.4.21' },
        { t: 'Name:    library.dera.lab', k: 'hl' },
        { t: 'Address: ', tap: '10.10.4.20' },
        { t: 'Name:    portal.dera.lab', k: 'dim' },
        { t: 'Address: ', tap: '10.10.4.30' },
      ],
    },
  },
  {
    id: 'n-dnsq',
    section: 'net',
    title: 'Name to Number',
    mission: s('كتبتي اسم الموقع في المتصفح، والجهاز يحتاج عنوانه الرقمي. أي خدمة تسوي هذي الترجمة؟', 'You typed a site name; the device needs its number. Which service does that translation?'),
    points: 5,
    kind: 'choice',
    options: [
      { id: 'gateway', label: s('Gateway', 'Gateway') },
      { id: 'dns', label: s('DNS', 'DNS') },
      { id: 'wifi', label: s('Wi-Fi', 'Wi-Fi') },
      { id: 'mask', label: s('Subnet Mask', 'Subnet Mask') },
    ],
    reward: 'DERA{DNS}',
    hint: s('اسمها ثلاث حروف، وتشتغل مثل «دليل الهاتف».', 'Three letters, and it works like a phone book.'),
    learn: s('DNS = Domain Name System. بدونه لازم نحفظ أرقام كل المواقع!', 'DNS = Domain Name System. Without it we’d memorise every site’s number!'),
    wrong: {
      gateway: s('الـGateway يطلّع البيانات من الشبكة، لكنه ما يترجم الأسماء.', 'The Gateway sends data out; it doesn’t translate names.'),
      wifi: s('الواي فاي يوصلك بالشبكة بس.', 'Wi-Fi just connects you.'),
      mask: s('الـSubnet Mask يحدد حدود الشبكة.', 'The subnet mask defines the network’s boundary.'),
    },
    screen: {
      type: 'term',
      title: 'browser',
      lines: [
        { t: '> https://library.dera.lab', k: 'cmd' },
        { t: '  ? who is library.dera.lab ?', k: 'hl' },
        { t: '  answer: 10.10.4.20', k: 'ok' },
        { t: '  connecting...' },
      ],
    },
  },
  {
    id: 'n-device',
    section: 'net',
    title: 'Whose IP?',
    story: s('في صفحة إدارة الراوتر، تبين تعرفين مين الجهاز اللي عنوانه 192.168.1.40.', 'In the router admin page, find which device has 192.168.1.40.'),
    mission: s('وش اسم الجهاز اللي عنوانه 192.168.1.40؟', 'Which device name has the address 192.168.1.40?'),
    points: 15,
    kind: 'flag',
    format: 'DERA{DEVICE_NAME}',
    hint: s('ابدئي من عمود IP ADDRESS، ثم امشي على نفس السطر لعمود DEVICE.', 'Start at the IP ADDRESS column, then follow the row to DEVICE.'),
    learn: s('كل جهاز في الشبكة له عنوان خاص فيه — وهذا اللي يخلي الراوتر يعرف لمين يوصّل البيانات.', 'Each device has its own address — that’s how the router knows where to deliver data.'),
    wrong: {
      'NOURA-PHONE': s('هذا عنوانه 192.168.1.14.', 'That one is 192.168.1.14.'),
      'STUDY-LAPTOP': s('هذا عنوانه 192.168.1.41 — قريب! انتبهي للرقم الأخير.', 'That’s 192.168.1.41 — close! Check the last number.'),
      PRINTER: s('هذا عنوانه 192.168.1.4.', 'That one is 192.168.1.4.'),
    },
    screen: {
      type: 'log',
      title: 'Router · Connected devices',
      cols: ['DEVICE', 'IP ADDRESS', 'TYPE'],
      rows: [
        ['NOURA-PHONE', '192.168.1.14', 'Wi-Fi'],
        ['PRINTER', '192.168.1.4', 'Cable'],
        ['STUDY-LAPTOP', '192.168.1.41', 'Wi-Fi'],
        ['LIVING-ROOM-TV', '192.168.1.40', 'Wi-Fi'],
      ],
      tapCols: [0],
      hotCol: 0,
    },
  },

  // ───────────── IT SUPPORT ─────────────
  {
    id: 's-sound',
    section: 'support',
    title: 'No Sound',
    ticket: { id: 'TICKET #3104', text: s('«المحاضرة بدأت وما أسمع أي صوت من اللابتوب!»', '“The lecture started and I can’t hear anything from my laptop!”') },
    mission: s('شوفي الإعدادات السريعة. وش أول خطوة منطقية؟', 'Check the quick settings. What’s the first logical step?'),
    points: 10,
    kind: 'choice',
    options: [
      { id: 'reinstall', label: s('إعادة تثبيت ويندوز', 'Reinstall Windows') },
      { id: 'unmute', label: s('إلغاء كتم الصوت', 'Unmute the sound') },
      { id: 'speakers', label: s('شراء سماعات جديدة', 'Buy new speakers') },
    ],
    reward: 'DERA{UNMUTE}',
    hint: s('أيقونة الصوت لونها وردي… وش مكتوب تحتها؟', 'The volume tile is pink… what does it say?'),
    learn: s('القاعدة الذهبية: ابدئي بالأبسط والأوضح. أغلب مشاكل الصوت سببها الكتم!', 'Golden rule: start with the simplest, clearest thing. Most sound issues are just mute!'),
    wrong: {
      reinstall: s('خطوة ضخمة! ممكن تخرّبين شي كان شغّال.', 'Huge step — you might break something that worked.'),
      speakers: s('السماعات سليمة غالباً. افحصي الإعدادات أول.', 'The speakers are probably fine. Check settings first.'),
    },
    screen: {
      type: 'tiles',
      title: 'Quick Settings',
      tiles: [
        { label: 'Volume', icon: 'volume', before: 'MUTED', after: '60%', bad: true },
        { label: 'Wi-Fi', icon: 'wifi', before: 'Connected', after: 'Connected' },
        { label: 'Bluetooth', icon: 'bt', before: 'Off', after: 'Off' },
        { label: 'Battery', icon: 'battery', before: '78%', after: '78%' },
      ],
    },
  },
  {
    id: 's-caps',
    section: 'support',
    title: 'Wrong Password?',
    ticket: { id: 'TICKET #3121', text: s('«متأكدة من كلمة المرور، بس الجهاز يقول غلط!»', '“I’m sure of my password, but it keeps saying it’s wrong!”') },
    mission: s('شوفي شاشة الدخول بتركيز. وش الحل؟', 'Look closely at the login screen. What’s the fix?'),
    points: 10,
    kind: 'choice',
    options: [
      { id: 'reset', label: s('نعيد تعيين كلمة المرور فوراً', 'Reset the password immediately') },
      { id: 'caps', label: s('نطفّي Caps Lock ونكتبها مرة ثانية', 'Turn off Caps Lock and type it again') },
      { id: 'newacc', label: s('نسوي لها حساب جديد', 'Create a new account') },
    ],
    reward: 'DERA{CAPS_OFF}',
    hint: s('فيه تنبيه صغير تحت خانة كلمة المرور.', 'There’s a small warning under the password box.'),
    learn: s('كلمات المرور حساسة لحالة الأحرف: A تختلف عن a. Caps Lock سبب شائع جداً!', 'Passwords are case-sensitive: A isn’t a. Caps Lock is a very common cause!'),
    wrong: {
      reset: s('قبل إعادة التعيين، افحصي الأساسيات — ممكن المشكلة أبسط.', 'Before resetting, check the basics — it may be simpler.'),
      newacc: s('ما نحتاج حساب جديد. المشكلة في طريقة الكتابة.', 'No new account needed. It’s how it’s typed.'),
    },
    screen: { type: 'login', user: 'student07' },
  },
  {
    id: 's-storage',
    section: 'support',
    title: 'Storage Full',
    ticket: { id: 'TICKET #3150', text: s('«الجهاز يقول: المساحة ممتلئة! وش اللي ماخذ كل المساحة؟»', '“It says storage is full! What’s taking all the space?”') },
    mission: s('أي مجلد ياخذ أكبر مساحة؟', 'Which folder takes the most space?'),
    points: 10,
    kind: 'flag',
    format: 'DERA{FOLDER}',
    hint: s('اقرئي الدليل… لا تخمّنين. أي شريط هو الأطول؟', 'Read the evidence — don’t guess. Which bar is longest?'),
    learn: s('فنية الدعم تبني قرارها على الدليل، مو على التخمين.', 'A support tech decides based on evidence, not guesses.'),
    wrong: {
      PHOTOS: s('الصور 18 GB بس — فيه شي أكبر.', 'Photos are only 18 GB — something’s bigger.'),
      DOCUMENTS: s('المستندات صغيرة جداً هنا.', 'Documents are tiny here.'),
    },
    screen: {
      type: 'bars',
      title: 'Storage · 256 GB',
      col: 'SIZE',
      unit: ' GB',
      rows: [
        { app: 'Documents', v: 6 },
        { app: 'Videos', v: 190 },
        { app: 'Photos', v: 18 },
        { app: 'Apps', v: 34 },
      ],
    },
  },
  {
    id: 's-printer',
    section: 'support',
    title: 'Printer Panic',
    ticket: { id: 'TICKET #3177', text: s('«أبي أطبع البحث قبل المحاضرة والطابعة ما تطبع!»', '“I need to print my report before class and the printer won’t print!”') },
    mission: s('شاشة الطابعة توضّح المشكلة. وش الحل؟', 'The printer screen shows the problem. What’s the fix?'),
    points: 10,
    kind: 'choice',
    options: [
      { id: 'paper', label: s('نحط ورق في الدرج', 'Load paper into the tray') },
      { id: 'driver', label: s('نحذف كل التعريفات من الجهاز', 'Delete every driver on the PC') },
      { id: 'cable', label: s('نغيّر كابل الكهرباء', 'Replace the power cable') },
    ],
    reward: 'DERA{ADD_PAPER}',
    hint: s('الطابعة شغالة ومتصلة… بس فيه شي ناقص.', 'The printer is on and connected… but something is missing.'),
    learn: s('خطوات الدعم: افهمي المشكلة ← افحصي الأساسيات ← اختبري ← أصلحي ← تأكدي.', 'Support steps: understand → check basics → test → fix → confirm.'),
    wrong: {
      driver: s('لا! هذا يخرّب أشياء كثيرة. الطابعة أصلاً متصلة.', 'No! That breaks a lot. The printer is already connected.'),
      cable: s('الطابعة شغالة — الكهرباء مو المشكلة.', 'The printer is on — power isn’t the problem.'),
    },
    screen: {
      type: 'tiles',
      title: 'Printer · LIB-PRN-1',
      tiles: [
        { label: 'Power', icon: 'printer', before: 'ON', after: 'ON' },
        { label: 'Connection', icon: 'wifi', before: 'Online', after: 'Online' },
        { label: 'Paper tray', icon: 'paper', before: 'EMPTY', after: 'Loaded', bad: true },
      ],
    },
  },

  // ───────────── CYBER CLUES ─────────────
  {
    id: 'c-night',
    section: 'clues',
    title: 'Night Owl',
    story: s('أحد سجّل دخول للمختبر بعد منتصف الليل.', 'Someone logged into the lab after midnight.'),
    mission: s('وش اسم المستخدم اللي دخل الساعة 02:13؟', 'Which username logged in at 02:13?'),
    points: 10,
    kind: 'flag',
    format: 'DERA{USERNAME}',
    hint: s('ابدئي من عمود TIME، ثم امشي على نفس السطر.', 'Start at TIME, then follow the same row.'),
    learn: s('المحققة السيبرانية تقرأ السجل بتركيز: الوقت، المستخدم، الجهاز، الحالة.', 'An investigator reads logs carefully: time, user, device, status.'),
    wrong: {
      SARA: s('سارة دخلت 09:02 الصباح.', 'Sara logged in at 09:02.'),
      NOURA: s('نورة دخلت 13:40.', 'Noura logged in at 13:40.'),
      'LAB-PC-05': s('هذا اسم الجهاز. المطلوب اسم المستخدم.', 'That’s the device. We need the username.'),
    },
    screen: {
      type: 'log',
      title: 'lab_access.log',
      cols: ['TIME', 'USER', 'DEVICE', 'STATUS'],
      rows: [
        ['09:02', 'sara', 'LAB-PC-01', 'SUCCESS'],
        ['13:40', 'noura', 'LAB-PC-03', 'SUCCESS'],
        ['02:13', 'guest07', 'LAB-PC-05', 'SUCCESS'],
        ['02:20', 'guest07', 'LAB-PC-05', 'LOGOUT'],
      ],
      tapCols: [1, 2],
      hotCol: 1,
    },
  },
  {
    id: 'c-fails',
    section: 'clues',
    title: 'Five Failures',
    story: s('في السجل جهاز حاول يدخل كثير وفشل.', 'One device tried to log in many times and failed.'),
    mission: s('أي جهاز سجّل 5 محاولات دخول فاشلة؟', 'Which device logged 5 failed login attempts?'),
    points: 15,
    kind: 'flag',
    format: 'DERA{DEVICE}',
    hint: s('عدّي كلمة FAILED لكل جهاز.', 'Count the word FAILED for each device.'),
    learn: s('محاولات فاشلة كثيرة ورا بعض ممكن تكون تخمين كلمات مرور. تستاهل نتحقق منها.', 'Many failures in a row may be password guessing — worth checking.'),
    wrong: {
      'LAB-PC-04': s('هذا الجهاز فشل مرة وحدة بس ثم نجح.', 'That one failed once, then succeeded.'),
    },
    screen: {
      type: 'log',
      title: 'auth.log',
      cols: ['TIME', 'DEVICE', 'STATUS'],
      rows: [
        ['10:01', 'LAB-PC-04', 'FAILED'],
        ['10:01', 'LAB-PC-04', 'SUCCESS'],
        ['10:15', 'LAB-PC-12', 'FAILED'],
        ['10:15', 'LAB-PC-12', 'FAILED'],
        ['10:16', 'LAB-PC-12', 'FAILED'],
        ['10:16', 'LAB-PC-12', 'FAILED'],
        ['10:17', 'LAB-PC-12', 'FAILED'],
      ],
      tapCols: [1],
      hotCol: 1,
    },
  },
  {
    id: 'c-sender',
    section: 'clues',
    title: 'Fake Support',
    story: s('وصلتك رسالة تقول إنها من «الدعم الفني».', 'You received an email claiming to be from “IT Support”.'),
    mission: s('الاسم الظاهر يقول IT Support، بس وش النطاق (Domain) الحقيقي للمرسل؟ (اللي بعد @)', 'The display name says IT Support — but what is the sender’s real domain (after the @)?'),
    points: 15,
    kind: 'flag',
    format: 'DERA{domain}',
    hint: s('شوفي عنوان البريد بين علامتي < >، والجزء اللي بعد @.', 'Look at the address between < > — the part after @.'),
    learn: s('الاسم الظاهر سهل يتزوّر. العنوان الحقيقي هو الدليل — وهذا نطاق غريب مو تابع لجهتك.', 'Display names are easy to fake. The real address is the evidence — and this domain isn’t yours.'),
    wrong: {
      'IT SUPPORT': s('هذا الاسم الظاهر، مو النطاق.', 'That’s the display name, not the domain.'),
      'SUPPORT@DERA-HELP.XYZ': s('قريبة! المطلوب الجزء اللي بعد @ بس.', 'Close! Just the part after @.'),
      'DERA.LAB': s('هذا نطاق المستلمة، مو المرسل.', 'That’s the recipient’s domain.'),
    },
    screen: {
      type: 'email',
      fromName: 'IT Support',
      fromAddr: 'support@dera-help.xyz',
      to: 'student07@dera.lab',
      subject: 'Your account will be closed today!',
      body: ['Hello,', 'Click the link below to keep your account:', 'http://dera-help.xyz/keep-account', 'IT Support Team'],
    },
  },
  {
    id: 'c-file',
    section: 'clues',
    title: 'Not a Photo',
    story: s('في مجلد التنزيلات ملف يتظاهر إنه صورة.', 'A file in Downloads is pretending to be a photo.'),
    mission: s('أي ملف هو في الحقيقة برنامج؟ اكتبي اسمه كامل.', 'Which file is actually a program? Write its full name.'),
    points: 15,
    kind: 'flag',
    format: 'DERA{file.name}',
    hint: s('الامتداد الحقيقي هو اللي بعد آخر نقطة.', 'The real extension is whatever comes after the last dot.'),
    learn: s('ملف ‎.exe يعني برنامج يشتغل على جهازك. لا تفتحين مرفقات ما كنتي تتوقعينها. #لا_تفتح_مجال', 'A .exe is a program that runs on your PC. Don’t open files you weren’t expecting.'),
    wrong: {
      'NOTES.PDF': s('هذا ملف PDF عادي.', 'That’s a normal PDF.'),
      'TRIP.JPG': s('صورة عادية، امتدادها jpg فعلاً.', 'A normal photo — really .jpg.'),
    },
    screen: {
      type: 'log',
      title: 'Downloads',
      cols: ['NAME', 'TYPE', 'SIZE'],
      rows: [
        ['trip.jpg', 'JPEG image', '2.1 MB'],
        ['party.jpg.exe', 'Application', '1.4 MB'],
        ['notes.pdf', 'PDF document', '340 KB'],
      ],
      tapCols: [0],
      hotCol: 0,
    },
  },

  // ───────────── SIMPLE CODE ─────────────
  {
    id: 'k-print',
    section: 'code',
    title: 'Print Me',
    mission: s('وش الكلمة اللي بيطبعها الكود؟', 'Which word will the code print?'),
    points: 5,
    kind: 'flag',
    format: 'DERA{...}',
    hint: s('print تعرض القيمة اللي داخل المتغير color.', 'print shows the value stored in color.'),
    learn: s('print() تعرض القيمة على الشاشة. المتغير مثل صندوق فيه قيمة.', 'print() shows a value. A variable is a box holding a value.'),
    wrong: { COLOR: s('color اسم الصندوق — print تطبع اللي داخله.', 'color is the box’s name — print shows what’s inside.') },
    screen: { type: 'code', file: 'color.py', lines: ['color = "PURPLE"', 'print(color)'], output: 'PURPLE' },
  },
  {
    id: 'k-plus',
    section: 'code',
    title: 'Plus Three',
    mission: s('وش الرقم اللي بيطبعه الكود؟', 'Which number will the code print?'),
    points: 10,
    kind: 'flag',
    format: 'DERA{number}',
    hint: s('x يبدأ 4، وبعدين نزيد عليه 3.', 'x starts at 4, then we add 3.'),
    learn: s('السطر x = x + 3 يعني: خذي القيمة القديمة وزيدي عليها 3.', 'x = x + 3 means: take the old value and add 3.'),
    wrong: { '4': s('هذي القيمة قبل الإضافة.', 'That’s the value before adding.'), '3': s('هذا اللي أضفناه بس.', 'That’s only what we added.') },
    screen: { type: 'code', file: 'math.py', lines: ['x = 4', 'x = x + 3', 'print(x)'], output: '7' },
  },
  {
    id: 'k-join',
    section: 'code',
    title: 'Join the Words',
    mission: s('وش النص اللي بيطبعه الكود؟', 'What text will the code print?'),
    points: 10,
    kind: 'flag',
    format: 'DERA{TEXT}',
    hint: s('علامة + بين نصين تلصقهم ببعض بدون مسافة.', '+ between two texts glues them together with no space.'),
    learn: s('جمع النصوص بعلامة + يلصقها ببعض — وهذي فكرة بسيطة نستخدمها كثير في البرمجة.', 'Adding strings with + joins them — a simple idea used all the time.'),
    wrong: { 'CYBER GIRL': s('قريبة! + ما تضيف مسافة.', 'Close! + doesn’t add a space.') },
    screen: { type: 'code', file: 'join.py', lines: ['a = "CYBER"', 'b = "GIRL"', 'print(a + b)'], output: 'CYBERGIRL' },
  },
  // ───────────── PRACTICAL LABS (from the session) ─────────────
  {
    id: 'lab-1',
    section: 'lab',
    title: 'Lab 01 · Find My IP',
    story: s('تطبيق عملي · Networking', 'Practical lab · Networking'),
    mission: s('اعثري على عنوان IPv4 لهذا الجهاز، وأرسلي الـFlag.', 'Find this device’s IPv4 address and submit the flag.'),
    points: 15,
    kind: 'flag',
    format: 'DERA{IPv4}',
    hint: s('الشاشة فيها عنوانين متشابهين. واحد للجهاز، وواحد للـGateway.', 'Two addresses look alike: one is the device, one is the Gateway.'),
    learn: s('عنوان IPv4 هو عنوان الجهاز نفسه. الـGateway والـDNS عناوين لأجهزة ثانية يعتمد عليها الاتصال.', 'The IPv4 address belongs to the device itself; Gateway and DNS are other devices it relies on.'),
    wrong: {
      '192.168.0.1': s('هذا عنوان الـGateway (وهو نفسه الـDNS هنا)، مو عنوان الجهاز.', 'That’s the Gateway (also the DNS here), not the device.'),
      '3C-52-82-1A-7F-10': s('هذا عنوان MAC — هوية كرت الشبكة، مو عنوان IP.', 'That’s the MAC address — the network card’s ID, not an IP.'),
      'LAB-LAPTOP-04': s('هذا اسم الجهاز. المطلوب عنوان IPv4.', 'That’s the device name. We need the IPv4 address.'),
    },
    screen: {
      type: 'kv',
      title: 'Network Properties',
      status: 'Connected',
      rows: [
        { k: 'Device name', v: 'LAB-LAPTOP-04' },
        { k: 'MAC address', v: '3C-52-82-1A-7F-10' },
        { k: 'IPv4 address', v: '192.168.0.42' },
        { k: 'Default gateway', v: '192.168.0.1' },
        { k: 'DNS server', v: '192.168.0.1' },
      ],
    },
  },
  {
    id: 'lab-2',
    section: 'lab',
    title: 'Lab 02 · Fix the Connection',
    story: s('تطبيق عملي · IT Support', 'Practical lab · IT Support'),
    ticket: { id: 'HELP DESK · TICKET #2207', text: s('«رجعت من السفر، والإنترنت ما يشتغل في اللابتوب!»', '“I’m back from a trip and the internet won’t work on my laptop!”') },
    mission: s('اكتشفي المشكلة الواضحة، واختاري الإجراء الصحيح.', 'Spot the obvious problem and pick the right action.'),
    points: 15,
    kind: 'choice',
    options: [
      { id: 'reinstall', label: s('إعادة تثبيت نظام التشغيل', 'Reinstall the operating system') },
      { id: 'airplane', label: s('إيقاف وضع الطيران', 'Turn off airplane mode') },
      { id: 'router', label: s('شراء راوتر جديد', 'Buy a new router') },
    ],
    reward: 'DERA{AIRPLANE_OFF}',
    hint: s('وش الإعداد اللي ممكن نشغّله في الطيارة وننساه؟', 'Which setting do we switch on during a flight and forget?'),
    learn: s('وضع الطيران يطفّي الواي فاي والبلوتوث. ابدئي دائمًا بالحل الأبسط والأوضح قبل الحلول الكبيرة.', 'Airplane mode switches off Wi-Fi and Bluetooth. Always try the simplest, clearest fix first.'),
    wrong: {
      reinstall: s('خطوة ضخمة لمشكلة بسيطة — شوفي الإعدادات السريعة أول.', 'A huge step for a small problem — check quick settings first.'),
      router: s('الراوتر مو المشكلة؛ اللابتوب نفسه ما يشوف أي شبكة.', 'The router isn’t the issue; the laptop can’t see any network.'),
    },
    screen: {
      type: 'tiles',
      title: 'Quick Settings',
      tiles: [
        { label: 'Airplane mode', icon: 'plane', before: 'ON', after: 'OFF', bad: true },
        { label: 'Wi-Fi', icon: 'wifi', before: 'Unavailable', after: 'Connected' },
      ],
    },
  },
  {
    id: 'lab-3',
    section: 'lab',
    title: 'Lab 03 · Find the Hidden Clue',
    story: s('تطبيق عملي · Cyber Clues', 'Practical lab · Cyber Clues'),
    mission: s('ما اسم الجهاز اللي سجّل دخولًا الساعة 13:05؟', 'Which device logged in at 13:05?'),
    points: 15,
    kind: 'flag',
    format: 'DERA{DEVICE}',
    hint: s('ابدئي من عمود TIME، ثم امشي على نفس السطر.', 'Start at the TIME column, then follow the same row.'),
    learn: s('في السجلات كل سطر قصة كاملة: متى، مين، من أي جهاز، وش صار. اربطي الأعمدة ببعض.', 'Each log row is a full story: when, who, which device, what happened. Connect the columns.'),
    wrong: {
      STUDENT07: s('هذا اسم المستخدم. المطلوب اسم الجهاز.', 'That’s the username. We need the device name.'),
      'LIB-PC-03': s('هذا جهاز نورة الساعة 08:58 و13:40.', 'That’s Noura’s device at 08:58 and 13:40.'),
      'LAB-PC-07': s('هذا جهاز سارة الساعة 10:14.', 'That’s Sara’s device at 10:14.'),
    },
    screen: {
      type: 'log',
      title: 'library_access.log',
      cols: ['TIME', 'USER', 'DEVICE', 'STATUS'],
      rows: [
        ['08:58', 'noura', 'LIB-PC-03', 'SUCCESS'],
        ['10:14', 'sara', 'LAB-PC-07', 'SUCCESS'],
        ['10:16', 'sara', 'LAB-PC-07', 'LOGOUT'],
        ['13:05', 'student07', 'TABLET-X9', 'SUCCESS'],
        ['13:40', 'noura', 'LIB-PC-03', 'LOGOUT'],
      ],
      tapCols: [1, 2],
      hotCol: 2,
    },
  },
];

export const SECTIONS: { id: TrainSection; tag: string; tone: Tone; title: L10n }[] = [
  { id: 'start', tag: 'Warm-up', tone: 'ink', title: s('البداية', 'Warm-up') },
  { id: 'net', tag: 'Networking', tone: 'lime', title: s('اكتشفي معلومات الشبكة', 'Discover network details') },
  { id: 'support', tag: 'IT Support', tone: 'violet', title: s('شخّصي المشكلة واختاري الحل', 'Diagnose and pick the fix') },
  { id: 'clues', tag: 'Cyber Clues', tone: 'pink', title: s('حلّلي الأدلة واكتشفي المعلومة', 'Analyse the evidence') },
  { id: 'code', tag: 'Simple Code', tone: 'violet', title: s('اقرئي كودًا قصيرًا جدًا', 'Read very short code') },
  { id: 'lab', tag: 'Practical Labs', tone: 'ink', title: s('التطبيقات العملية من الجلسة', 'Practical labs from the session') },
];

export const toneOf = (sec: TrainSection) => SECTIONS.find((x) => x.id === sec)!.tone;
export const TRAIN_MAX = TRAINING.reduce((n, c) => n + c.points, 0);
export const trainById = (id: string) => TRAINING.find((c) => c.id === id);
