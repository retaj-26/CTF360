// ─────────────────────────────────────────────────────────────────────────────
//  CTF360 challenge definitions — CASE_001: a staff account was compromised.
//  Everything a visitor reads lives here, in Arabic (ar) and English (en).
//  Answers do NOT live here — they are in server/answers.json (organizer-only)
//  and reach the browser only as salted hashes (src/data/answerKeys.generated.ts).
// ─────────────────────────────────────────────────────────────────────────────
import type { Challenge, Option } from '../engine/types';

const same = (s: string) => ({ ar: s, en: s });
const allowBlock = (n: number): Option[] => [
  { id: `p${n}-allow`, label: { ar: 'اسمحي', en: 'Allow' } },
  { id: `p${n}-block`, label: { ar: 'احظري', en: 'Block' } },
];

export const CHALLENGES: Challenge[] = [
  // ═══════════════════════ ROOM 1 — IT SUPPORT ═══════════════════════
  {
    id: 'r1-phish',
    room: 'helpdesk',
    letter: 'A',
    title: { ar: 'رسالة التصيّد', en: 'The Phishing Email' },
    description: {
      ar: 'هذا الإيميل وصل لرزان قبل الاختراق بدقائق. افحصيه كأنك محققة، واضغطي على العلامات اللي تفضح إنه احتيال.',
      en: 'This email reached Razan minutes before the breach. Inspect it like an investigator and tap the signs that give the scam away.',
    },
    category: 'it-support',
    difficulty: 'intro',
    type: 'diagram',
    payload: {
      scene: 'phish',
      fromName: { ar: 'إدارة الموارد البشرية', en: 'HR Department' },
      fromAddr: 'hr@org-sa-secure.com',
      to: 'razan@expo.ctf360.local',
      subject: { ar: 'تحديث عاجل لبياناتك الوظيفية!!', en: 'URGENT update to your employee details!!' },
      date: 'Thu, 15 Oct 2026 · 08:02',
      headerHotspots: { from: 'h-sender', date: 'd-date', subject: 'h-urgent' },
      flagsToFind: 3,
      body: [
        { id: 'd-greet', text: { ar: 'مرحباً،', en: 'Hello,' }, block: true },
        { text: { ar: 'للحفاظ على استمرارية حسابك الوظيفي، يرجى تحديث بياناتك عبر الرابط التالي ', en: 'To keep your employee account active, please update your details using the link below ' } },
        { id: 'h-urgent', text: { ar: 'خلال 24 ساعة', en: 'within 24 hours' } },
        { text: { ar: ':', en: ':' } },
        { id: 'h-link', text: same('https://org-sa-secure.com/login'), mono: true, block: true },
        { id: 'h-urgent', text: { ar: 'في حال عدم التحديث سيتم إيقاف حسابك فوراً.', en: 'If you do not update, your account will be suspended immediately.' }, block: true },
        { id: 'd-sign', text: { ar: 'شكراً، إدارة الموارد البشرية', en: 'Thanks, HR Department' }, block: true },
      ],
    },
    stages: [1, 2, 3].map((n) => ({
      kind: 'pick' as const,
      prompt: {
        ar: `اضغط على علامة مريبة في الرسالة (${n} من 3)`,
        en: `Tap a suspicious sign in the email (${n} of 3)`,
      },
    })),
    wrongFeedback: {
      'd-greet': { ar: 'التحية عادية — الاحتيال يختبي في التفاصيل الثانية.', en: 'The greeting is normal — the scam hides elsewhere.' },
      'd-sign': { ar: 'التوقيع سهل يتزوّر، لكنه بحد ذاته مو دليل. دوّري على شي أوضح.', en: 'A signature is easy to fake, but it isn’t evidence on its own. Look for something clearer.' },
      'd-date': { ar: 'التاريخ والوقت طبيعيين — احفظي الوقت 08:02، بتحتاجينه في القبو الأخير.', en: 'The date is normal — but remember 08:02, you will need it in the final vault.' },
    },
    hints: [
      { ar: 'انتبهي لثلاث أشياء: مين المرسل فعلاً؟ وين يوديك الرابط؟ وهل الرسالة تضغط عليك بالوقت؟', en: 'Watch three things: who really sent it? where does the link go? is it pressuring you with time?' },
      {
        ar: 'النطاق org-sa-secure.com مو نطاق جهتك، والرابط يوديك لنفس النطاق المزيّف، و«24 ساعة / إيقاف فوري» أسلوب تخويف.',
        en: 'org-sa-secure.com isn’t your organisation’s domain, the link goes to that same fake domain, and “24 hours / suspended immediately” is a scare tactic.',
      },
    ],
    explanation: {
      ar: 'ثلاث علامات تفضح التصيّد: (1) عنوان المرسل من نطاق مزيّف يشبه الرسمي، (2) رابط يوديك لصفحة دخول مو تابعة لجهتك، (3) استعجال وتهديد بإيقاف الحساب عشان ما تفكرين. القاعدة: لا تضغطين، تحققي من المرسل بقناة ثانية، وبلّغي فريق الأمن. #لا_تفتح_مجال',
      en: 'Three signs give the phish away: (1) a sender on a look-alike domain, (2) a link to a login page your organisation doesn’t own, (3) urgency and threats so you don’t stop to think. The rule: don’t click, verify the sender another way, and report it.',
    },
    basePoints: 50,
    reward: 'DERA{ph1sh_sp0tt3r}',
  },
  {
    id: 'r1-calls',
    room: 'helpdesk',
    letter: 'B',
    title: { ar: 'خط الدعم الساخن', en: 'The Support Hotline' },
    description: {
      ar: 'أنتِ على خط الدعم الفني، والمكالمات ما وقفت من الصباح. اسمعي كل متصل واختاري الرد الصحيح — واحد منهم مو اللي يقول إنه هو.',
      en: 'You’re on the support hotline and the phone hasn’t stopped ringing. Hear each caller out and pick the right response — one of them isn’t who they claim to be.',
    },
    category: 'it-support',
    difficulty: 'easy',
    type: 'multiple-choice',
    payload: {
      scene: 'calls',
      calls: [
        {
          caller: { ar: 'أبو فهد', en: 'Abu Fahad' },
          role: { ar: 'موظف الاستقبال', en: 'Front desk' },
          mood: 'calm',
          message: {
            ar: 'السلام عليكم، الطابعة ما تطبع وتطلع لي رسالة «Paper Jam — الورق عالق». وش أسوي؟',
            en: 'Hi, the printer won’t print and shows “Paper Jam”. What should I do?',
          },
        },
        {
          caller: { ar: 'رزان', en: 'Razan' },
          role: { ar: 'الموارد البشرية', en: 'Human Resources' },
          mood: 'urgent',
          message: {
            ar: 'الحقوني! دخلت بياناتي في رابط وصلني على الإيميل، والحين جوالي يطلع إشعارات دخول لحسابي من مكان ما أعرفه!',
            en: 'Help! I entered my details on a link from an email, and now my phone shows login alerts from somewhere I don’t know!',
          },
        },
        {
          caller: { ar: '«م. خالد»', en: '“Eng. Khalid”' },
          role: { ar: 'يقول إنه من الإدارة العليا', en: 'Claims to be senior management' },
          mood: 'suspicious',
          message: {
            ar: 'أنا مسافر ومستعجل جداً. أعطني كلمة مرور حساب رزان الحين، وإذا ما أعطيتني بتتحملين المسؤولية!',
            en: 'I’m travelling and in a huge hurry. Give me Razan’s account password right now, or you’ll answer for it!',
          },
        },
      ],
    },
    stages: [
      {
        kind: 'choice',
        prompt: { ar: 'المكالمة 1 من 3 — وش ردّك؟', en: 'Call 1 of 3 — your response?' },
        options: [
          { id: 'c1-new', label: { ar: 'اشترِ طابعة جديدة', en: 'Buy a new printer' } },
          { id: 'c1-jam', label: { ar: 'طفِّ الطابعة، افتح الغطاء وطلّع الورق العالق بهدوء، ثم شغّلها', en: 'Turn the printer off, open the cover, gently remove the jammed paper, then restart it' } },
          { id: 'c1-windows', label: { ar: 'نعيد تثبيت ويندوز على جهازك', en: 'Let’s reinstall Windows on your PC' } },
          { id: 'c1-pass', label: { ar: 'عطني كلمة مرورك عشان أفحص الطابعة', en: 'Give me your password so I can check the printer' } },
        ],
      },
      {
        kind: 'choice',
        prompt: { ar: 'المكالمة 2 من 3 — رزان مرتبكة. وش تسوين؟', en: 'Call 2 of 3 — Razan is panicking. What do you do?' },
        options: [
          { id: 'c2-calm', label: { ar: 'أطمّنها إن الإشعارات عادية وتتجاهلها', en: 'Reassure her the alerts are normal and to ignore them' } },
          { id: 'c2-delete', label: { ar: 'تحذف الإيميل وتنسى الموضوع', en: 'Delete the email and forget about it' } },
          {
            id: 'c2-secure',
            label: {
              ar: 'تغيّر كلمة المرور فوراً من جهاز آمن، تفعّل التحقق الثنائي، وأبلّغ فريق الأمن',
              en: 'Change the password now from a safe device, turn on 2FA, and alert the security team',
            },
          },
          { id: 'c2-send', label: { ar: 'ترسل لي كلمة مرورها الجديدة عشان أتأكد منها', en: 'Send me her new password so I can check it' } },
        ],
      },
      {
        kind: 'choice',
        prompt: { ar: 'المكالمة 3 من 3 — الضغط يزيد. وش ردّك؟', en: 'Call 3 of 3 — the pressure is on. Your response?' },
        options: [
          { id: 'c3-give', label: { ar: 'أعطيه، لأنه مدير', en: 'Give it to him — he’s a manager' } },
          { id: 'c3-whatsapp', label: { ar: 'أرسلها له على واتساب بدل المكالمة', en: 'Send it on WhatsApp instead' } },
          {
            id: 'c3-verify',
            label: {
              ar: 'أرفض بأدب، وأتحقق من هويته بقناة رسمية، وأبلّغ عن المحاولة',
              en: 'Politely refuse, verify his identity through an official channel, and report the attempt',
            },
          },
          { id: 'c3-half', label: { ar: 'أعطيه أول نصها بس', en: 'Give him just the first half' } },
        ],
      },
    ],
    wrongFeedback: {
      'c1-new': { ar: 'مشكلة ورق عالق ما تحتاج فلوس — ابدئي دائماً بالأبسط.', en: 'A paper jam doesn’t need money — always start with the simplest fix.' },
      'c1-windows': { ar: 'ويندوز ما له دخل بورق عالق داخل الطابعة!', en: 'Windows has nothing to do with paper stuck inside the printer!' },
      'c1-pass': { ar: 'الدعم الفني ما يطلب كلمة مرورك أبداً — ولا يحتاجها لطابعة.', en: 'Support never asks for your password — and certainly not for a printer.' },
      'c2-calm': { ar: 'إشعارات دخول من مكان غريب = أحد دخل حسابها. هذا طارئ.', en: 'Login alerts from a strange place mean someone got in. This is an emergency.' },
      'c2-delete': { ar: 'حذف الإيميل ما يطرد المهاجم — كلمة المرور صارت معه.', en: 'Deleting the email doesn’t kick the attacker out — they have the password now.' },
      'c2-send': { ar: 'لا أحد — حتى الدعم — يحتاج يعرف كلمة مرورها.', en: 'Nobody — not even support — needs to know her password.' },
      'c3-give': { ar: 'هذي هندسة اجتماعية كلاسيكية: سلطة + استعجال + تهديد.', en: 'Classic social engineering: authority + urgency + threats.' },
      'c3-whatsapp': { ar: 'تغيير القناة ما يغيّر شي — ما زلتِ تسلّمين كلمة المرور لشخص مجهول.', en: 'Changing the channel changes nothing — you’d still hand a password to a stranger.' },
      'c3-half': { ar: 'نص كلمة المرور يسهّل تخمين الباقي. لا تعطين أي جزء.', en: 'Half a password makes the rest easy to guess. Give none of it.' },
    },
    hints: [
      { ar: 'الدعم الصح يبدأ بالأبسط، ويتصرف بسرعة مع الطوارئ، وما يطلب كلمة مرور أبداً.', en: 'Good support starts simple, acts fast in emergencies, and never asks for a password.' },
      {
        ar: 'المكالمة الثالثة هندسة اجتماعية: المهاجم ينتحل صفة مدير ويستخدم الاستعجال والتهديد عشان تتنازلين.',
        en: 'Call three is social engineering: the attacker poses as a manager and uses urgency and threats to make you give in.',
      },
    ],
    explanation: {
      ar: 'فنية الدعم الشاطرة يحل الأعطال البسيطة بخطوات بسيطة، ويعامل الاختراق كحالة طوارئ (تغيير كلمة المرور + التحقق الثنائي + إبلاغ الأمن)، ويكشف الهندسة الاجتماعية: أي طلب لكلمة مرور — مهما كانت صفة المتصل — يُرفض ويُتحقق منه بقناة رسمية.',
      en: 'A sharp support technician fixes simple faults simply, treats a compromise as an emergency (reset password + 2FA + alert security), and spots social engineering: any request for a password — whoever the caller claims to be — is refused and verified through an official channel.',
    },
    basePoints: 100,
    reward: 'DERA{n3v3r_sh4r3_p4ss}',
  },
  {
    id: 'r1-password',
    room: 'helpdesk',
    letter: 'C',
    title: { ar: 'كلمة المرور', en: 'The Password' },
    description: {
      ar: 'هذي بيانات حساب رزان قبل الاختراق. حدّدي الخطأ الأمني في كلمة المرور، ثم ابني لها كلمة مرور جديدة تصمد أمام المهاجم.',
      en: 'These are Razan’s account details before the breach. Find the security mistake in her password, then build her a new one that would hold up against the attacker.',
    },
    category: 'it-support',
    difficulty: 'medium',
    type: 'short-text',
    payload: {
      scene: 'password',
      account: { username: 'razan', password: 'Razan123' },
      reusedOn: [
        { ar: 'البريد الوظيفي', en: 'Work email' },
        { ar: 'بوابة الموارد البشرية', en: 'HR portal' },
        { ar: 'حساب التواصل الشخصي', en: 'Personal social account' },
      ],
      banned: ['razan', '123', 'password', 'qwerty', '2026', 'abc'],
      minLength: 12,
    },
    stages: [
      {
        kind: 'choice',
        prompt: { ar: 'وش المشكلة في كلمة المرور اللي فوق؟', en: 'What’s wrong with the password above?' },
        options: [
          { id: 'pw-long', label: { ar: 'طويلة جداً', en: 'It’s too long' } },
          { id: 'pw-symbols', label: { ar: 'فيها رموز كثيرة', en: 'It has too many symbols' } },
          { id: 'pw-reuse', label: { ar: 'سهلة التخمين، ومستخدمة في أكثر من حساب', en: 'It’s easy to guess and used on several accounts' } },
          { id: 'pw-fine', label: { ar: 'ما فيها أي مشكلة', en: 'Nothing is wrong with it' } },
        ],
      },
      {
        kind: 'pick',
        prompt: { ar: 'ابني كلمة مرور جديدة لرزان تحقق كل الشروط', en: 'Build Razan a new password that meets every rule' },
      },
    ],
    wrongFeedback: {
      'pw-long': { ar: '8 حروف بس — هذي قصيرة، مو طويلة!', en: 'Only 8 characters — that’s short, not long!' },
      'pw-symbols': { ar: 'ما فيها ولا رمز أصلاً.', en: 'It doesn’t contain a single symbol.' },
      'pw-fine': { ar: 'اسمها + 123، ومكررة في 3 حسابات… فيها مشاكل كثيرة!', en: 'Her name + 123, reused on 3 accounts… plenty is wrong!' },
    },
    hints: [
      { ar: 'كلمة المرور = اسم المستخدم + أرقام متسلسلة. وشوفي القائمة تحتها: وين ثاني تُستخدم؟', en: 'The password = the username + sequential digits. And look at the list under it: where else is it used?' },
      {
        ar: 'كلمة المرور القوية: 12 خانة أو أكثر، فيها حروف كبيرة وصغيرة وأرقام ورموز، وما فيها اسمك ولا 123. جرّبي عبارة مثل: Qahwa#Buraidah!77',
        en: 'A strong password: 12+ characters, upper and lower case, digits and symbols, no name and no 123. Try a passphrase like: Qahwa#Buraidah!77',
      },
    ],
    explanation: {
      ar: 'Razan123 فيها خطأين: مبنية على الاسم وأرقام متسلسلة فتنخمّن في ثواني، ومكررة في أكثر من حساب — فلما سُرقت مرة وحدة، انفتحت كل الحسابات. الحل: كلمة مرور طويلة ومختلفة لكل حساب، ومدير كلمات مرور، وتحقق ثنائي. (لا تكتبين هنا كلمة مرور تستخدمينها فعلاً — ما يتم حفظ أي شي.)',
      en: 'Razan123 has two flaws: it’s built from her name and sequential digits, so it falls in seconds, and it’s reused — so one theft opened every account. The fix: a long, unique password per account, a password manager, and 2FA. (Never type a password you really use here — nothing is stored.)',
    },
    basePoints: 150,
    reward: 'DERA{str0ng_4nd_un1qu3}',
  },

  // ═══════════════════════ ROOM 2 — NETWORK SYSTEMS ═══════════════════════
  {
    id: 'r2-link',
    room: 'network',
    letter: 'A',
    title: { ar: 'الوصلة المقطوعة', en: 'The Broken Link' },
    description: {
      ar: 'فريق الأمن يحاول يوصل لخادم المعرض عشان يوقف المهاجم، لكن الاتصال مقطوع. اقرئي سجل اختبار الاتصال، اضغطي على الوصلة المقطوعة، واختاري أول خطوة منطقية.',
      en: 'The security team needs to reach the exhibition server to stop the attacker, but the connection is down. Read the ping log, tap the broken link, and pick the most sensible first step.',
    },
    category: 'networking',
    difficulty: 'intro',
    type: 'diagram',
    payload: {
      scene: 'network',
      nodes: [
        { id: 'pc', label: { ar: 'جهاز فريق الأمن', en: 'Security team PC' }, ip: '192.168.10.25' },
        { id: 'switch', label: { ar: 'المبدّل', en: 'Switch' }, ip: '192.168.10.2' },
        { id: 'router', label: { ar: 'الموجّه', en: 'Router' }, ip: '192.168.10.1' },
        { id: 'server', label: { ar: 'خادم المعرض', en: 'Expo server' }, ip: '10.36.0.10' },
      ],
      links: [
        { id: 'link-pc-switch', from: 'pc', to: 'switch' },
        { id: 'link-switch-router', from: 'switch', to: 'router', broken: true },
        { id: 'link-router-server', from: 'router', to: 'server' },
      ],
      pingLog: [
        { target: 'switch', ok: true },
        { target: 'router', ok: false },
        { target: 'server', ok: false },
      ],
    },
    stages: [
      { kind: 'pick', prompt: { ar: 'اضغطي على الوصلة المقطوعة', en: 'Tap the broken link' } },
      {
        kind: 'choice',
        prompt: { ar: 'لقيتها! وش أول خطوة منطقية؟', en: 'Found it! What’s the most sensible first step?' },
        options: [
          { id: 'replace-server', label: { ar: 'نستبدل خادم المعرض', en: 'Replace the expo server' } },
          { id: 'reinstall-browser', label: { ar: 'نعيد تثبيت المتصفح', en: 'Reinstall the browser' } },
          { id: 'check-cable-ports', label: { ar: 'نفحص الكابل بين المبدّل والموجّه، وأضواء المنافذ', en: 'Check the cable between switch and router, and the port lights' } },
          { id: 'call-isp', label: { ar: 'نتصل بمزوّد الإنترنت', en: 'Call the internet provider' } },
        ],
      },
    ],
    wrongFeedback: {
      'link-pc-switch': { ar: 'السجل يثبت إن الجهاز يوصل للمبدّل — هذي الوصلة سليمة.', en: 'The log proves the PC reaches the switch — this link is fine.' },
      'link-router-server': { ar: 'الإشارة أصلاً ما توصل للموجّه. دوّري على أول نقطة تنقطع فيها.', en: 'The signal never even reaches the router. Find the first point where it breaks.' },
      'replace-server': { ar: 'الخادم ممكن يكون سليم — المشكلة قبل ما توصله الإشارة.', en: 'The server may be fine — the fault is before the signal gets there.' },
      'reinstall-browser': { ar: 'المتصفح ما له دخل؛ العطل في الشبكة نفسها.', en: 'The browser isn’t the issue; the network is.' },
      'call-isp': { ar: 'الخادم داخل شبكة المعرض، فمزوّد الإنترنت ما له علاقة.', en: 'The server is inside the expo network — the ISP isn’t involved.' },
    },
    hints: [
      { ar: 'اقرئي سجل ping: وين آخر جهاز ردّ بنجاح؟', en: 'Read the ping log: which was the last device that replied?' },
      { ar: 'العطل بين آخر نقطة نجحت وأول نقطة فشلت. وابدئي دائماً بالكابل والأضواء.', en: 'The fault sits between the last success and the first failure. Start with the cable and lights.' },
    ],
    explanation: {
      ar: 'الإشارة وصلت للمبدّل وفشلت عند الموجّه — إذن العطل في الوصلة بينهم. مهندسة الشبكات تبدأ من الطبقة الفيزيائية: الكابل، المنفذ، الأضواء — أسرع وأرخص خطوة.',
      en: 'The signal reached the switch and failed at the router — so the fault is the link between them. Network engineers start at the physical layer: cable, port, lights — the fastest, cheapest step.',
    },
    basePoints: 50,
    reward: 'DERA{l4y3r_0n3_f1rst}',
  },
  {
    id: 'r2-firewall',
    room: 'network',
    letter: 'C',
    title: { ar: 'حارس الجدار الناري', en: 'Firewall Guard' },
    description: {
      ar: 'أنتِ الجدار الناري! الحزم تتدفق على شبكة المعرض وحدة ورا الثانية. قرري بسرعة: تسمحين لها ولا تحظرينها؟ عندك 3 دقائق قبل ما تضعف الإشارة.',
      en: 'You are the firewall! Packets are streaming into the expo network one after another. Decide fast: allow or block? You have three minutes before the signal weakens.',
    },
    category: 'networking',
    difficulty: 'medium',
    type: 'multiple-choice',
    timeLimitSec: 180,
    payload: {
      scene: 'firewall',
      packets: [
        {
          from: { ar: 'جوال زائر', en: 'Visitor phone' },
          to: { ar: 'موقع المعرض', en: 'Expo website' },
          port: '443',
          service: 'HTTPS',
          note: { ar: 'زائر يتصفح جدول الفعاليات', en: 'A visitor browsing the schedule' },
        },
        {
          from: { ar: 'عنوان مجهول من الإنترنت', en: 'Unknown internet address' },
          to: { ar: 'جهاز رزان', en: 'Razan’s PC' },
          port: '3389',
          service: 'RDP',
          note: { ar: 'طلب تحكم عن بُعد بسطح المكتب', en: 'A remote-desktop control request' },
        },
        {
          from: { ar: 'شبكة الزوار (Wi-Fi)', en: 'Guest Wi-Fi' },
          to: { ar: 'خادم الموارد البشرية', en: 'HR file server' },
          port: '445',
          service: 'SMB',
          note: { ar: 'محاولة فتح ملفات الموظفين', en: 'Trying to open staff files' },
        },
        {
          from: { ar: 'جهاز موظف', en: 'Staff PC' },
          to: { ar: 'خادم DNS الداخلي', en: 'Internal DNS server' },
          port: '53',
          service: 'DNS',
          note: { ar: 'يسأل عن عنوان موقع العمل', en: 'Looking up the work portal address' },
        },
        {
          from: { ar: 'كاميرا المدخل', en: 'Entrance camera' },
          to: { ar: 'خادم مجهول خارج الدولة', en: 'Unknown server abroad' },
          port: '23',
          service: 'Telnet',
          note: { ar: 'اتصال غير مشفّر ما أحد طلبه', en: 'An unencrypted connection nobody asked for' },
        },
        {
          from: { ar: 'جهاز رزان', en: 'Razan’s PC' },
          to: same('org-sa-secure.com'),
          port: '443',
          service: 'HTTPS',
          note: { ar: 'الاتصال مشفّر… بس لاحظي الوجهة', en: 'The connection is encrypted… but check the destination' },
        },
      ],
    },
    stages: [1, 2, 3, 4, 5, 6].map((n) => ({
      kind: 'choice' as const,
      prompt: { ar: `الحزمة ${n} من 6 — قرارك؟`, en: `Packet ${n} of 6 — your call?` },
      options: allowBlock(n),
    })),
    wrongFeedback: {
      'p1-block': { ar: 'زائر يتصفح موقع المعرض بشكل مشفّر — هذا بالضبط اللي نبيه. اسمحي.', en: 'A visitor browsing the expo site over HTTPS — exactly what we want. Allow it.' },
      'p2-allow': { ar: 'تحكّم عن بُعد من مجهول؟! هذا باب مفتوح للمهاجم.', en: 'Remote control from a stranger?! That’s an open door for the attacker.' },
      'p3-allow': { ar: 'شبكة الزوار لازم تكون معزولة تماماً عن خوادم الموظفين.', en: 'The guest network must be fully isolated from staff servers.' },
      'p4-block': { ar: 'بدون DNS ما يقدر أحد يوصل لأي موقع — هذا اتصال داخلي ضروري.', en: 'Without DNS nobody can reach any site — this is essential internal traffic.' },
      'p5-allow': { ar: 'كاميرا تكلم خادم مجهول ببروتوكول غير مشفّر؟ غالباً مخترقة.', en: 'A camera talking to an unknown server over unencrypted Telnet? Probably hijacked.' },
      'p6-allow': { ar: 'القفل (HTTPS) يعني إن الاتصال مشفّر، مو إن الموقع آمن! هذا موقع التصيّد نفسه.', en: 'The padlock (HTTPS) means encrypted, not trustworthy! This is the phishing site itself.' },
    },
    hints: [
      { ar: 'اسألي كل مرة: هل هذا الاتصال متوقع ومطلوب للعمل؟ ولا جاي من/رايح لمكان مشبوه؟', en: 'Ask each time: is this connection expected and needed for work — or coming from / going to somewhere suspicious?' },
      {
        ar: 'اسمحي للتصفح الآمن وDNS الداخلي. احظري التحكم عن بُعد من الإنترنت، ووصول الزوار للخوادم، والكاميرا اللي تكلم الخارج، وأي اتصال بموقع التصيّد — حتى لو كان HTTPS.',
        en: 'Allow safe browsing and internal DNS. Block remote control from the internet, guests reaching servers, the camera calling abroad, and anything to the phishing domain — even over HTTPS.',
      },
    ],
    explanation: {
      ar: 'الجدار الناري يطبّق قاعدة «أقل صلاحية»: يسمح بالاتصالات اللي يحتاجها العمل فقط (HTTPS للموقع، DNS داخلي)، ويحظر الباقي: RDP المكشوف للإنترنت، وصول شبكة الزوار للخوادم، أجهزة إنترنت الأشياء اللي تكلم جهات مجهولة، والنطاقات الخبيثة. وتذكّري: HTTPS يحمي الطريق، مو الوجهة.',
      en: 'A firewall enforces least privilege: allow only what the work needs (HTTPS to the site, internal DNS) and block the rest — RDP exposed to the internet, guests reaching servers, IoT devices calling unknown hosts, malicious domains. Remember: HTTPS protects the road, not the destination.',
    },
    basePoints: 150,
    reward: 'DERA{gu4rd_th3_g4t3}',
  },
  {
    id: 'r2-wifi',
    room: 'network',
    letter: 'B',
    title: { ar: 'الواي فاي التوأم', en: 'The Evil-Twin Wi-Fi' },
    description: {
      ar: 'تبين تتصلين بشبكة المعرض، لكن جوالك يعرض شبكات متشابهة جداً. وحدة بس هي الرسمية — والباقي ممكن يكون فخ نصبه المهاجم. اختاري الصح!',
      en: 'You want to join the expo Wi-Fi, but your phone shows several look-alike networks. Only one is official — the rest could be traps set by the attacker. Pick the right one!',
    },
    category: 'networking',
    difficulty: 'easy',
    type: 'diagram',
    payload: {
      scene: 'wifi',
      poster: {
        ssid: 'CTF360-Expo',
        note: {
          ar: 'الشبكة الرسمية محمية بكلمة مرور، تلقينها مكتوبة عند مكتب الاستقبال.',
          en: 'The official network is password-protected — the password is at the reception desk.',
        },
      },
      networks: [
        { id: 'wifi-free', ssid: 'CTF360-Expo-FREE', locked: false, bars: 4, tag: { ar: 'مجانية · بدون كلمة مرور', en: 'Free · no password' } },
        { id: 'wifi-o', ssid: 'CTF36O-Expo', locked: true, bars: 3 },
        { id: 'wifi-real', ssid: 'CTF360-Expo', locked: true, bars: 3 },
        { id: 'wifi-cafe', ssid: 'Cafe_Guest', locked: false, bars: 2 },
      ],
    },
    stages: [
      { kind: 'pick', prompt: { ar: 'اضغطي على الشبكة الرسمية', en: 'Tap the official network' } },
      {
        kind: 'choice',
        prompt: { ar: 'صح! وليش الشبكة «المجانية» اللي بنفس الاسم خطيرة؟', en: 'Right! So why is the “free” network with the same name dangerous?' },
        options: [
          { id: 'w-slow', label: { ar: 'لأنها أبطأ بس', en: 'It’s just slower' } },
          { id: 'w-spy', label: { ar: 'ممكن تكون شبكة مزيّفة يتجسس فيها المهاجم على كل اللي ترسلينه', en: 'It may be a fake network where the attacker spies on everything you send' } },
          { id: 'w-battery', label: { ar: 'لأنها تستهلك البطارية', en: 'It drains the battery' } },
          { id: 'w-safe', label: { ar: 'ما فيها أي خطر، المجاني أفضل', en: 'No danger — free is better' } },
        ],
      },
    ],
    wrongFeedback: {
      'wifi-free': { ar: 'اسمها قريب، بس مفتوحة بدون كلمة مرور — والبوستر يقول إن الرسمية محمية. هذا فخ كلاسيكي!', en: 'Close name, but it’s open — and the poster says the official one is protected. Classic trap!' },
      'wifi-o': { ar: 'دقّقي في الاسم حرف حرف: فيه حرف O بدل الرقم 0!', en: 'Read it letter by letter: there’s a letter O instead of the digit 0!' },
      'wifi-cafe': { ar: 'هذي شبكة ثانية خالص، مو شبكة المعرض.', en: 'That’s a different network entirely, not the expo’s.' },
      'w-slow': { ar: 'السرعة مو المشكلة — المشكلة مين يتحكم في الشبكة.', en: 'Speed isn’t the issue — who controls the network is.' },
      'w-battery': { ar: 'البطارية ما لها علاقة بالأمان هنا.', en: 'Battery has nothing to do with security here.' },
      'w-safe': { ar: 'المجاني أحياناً يكلّفك بياناتك!', en: 'Free can cost you your data!' },
    },
    hints: [
      { ar: 'قارني كل اسم بالبوستر حرف حرف، وشوفي علامة القفل.', en: 'Compare each name with the poster letter by letter, and look for the padlock.' },
      { ar: 'الشبكة الرسمية: نفس الاسم بالضبط (بالرقم صفر) + مقفلة بكلمة مرور.', en: 'The official one: exactly the same name (with a zero) + locked with a password.' },
    ],
    explanation: {
      ar: 'المهاجم يقدر ينشئ «توأم شرير» (Evil Twin): شبكة بنفس اسم الشبكة الرسمية أو اسم قريب منه، ولما تتصلين فيها يمر كل شي ترسلينه من عنده. قبل ما تتصلين: تأكدي من الاسم الحرفي، وفضّلي الشبكات المحمية، وتجنّبي إدخال كلمات مرور على شبكة عامة.',
      en: 'An attacker can create an “evil twin”: a network with the same or a look-alike name, so everything you send passes through them. Before joining: check the exact name, prefer protected networks, and avoid typing passwords on public Wi-Fi.',
    },
    basePoints: 100,
    reward: 'DERA{n0_fr33_w1f1}',
  },

  // ═══════════════════════ ROOM 3 — PROGRAMMING ═══════════════════════
  {
    id: 'r3-script',
    room: 'code',
    letter: 'A',
    title: { ar: 'سكربت الإنذار', en: 'The Alarm Script' },
    description: {
      ar: 'هذا السكربت مفروض يطلق إنذار لكل دخول مشبوه، لكنه يرفض يشتغل. اضغطي على السطر اللي فيه الخطأ، ثم اختاري الإصلاح.',
      en: 'This script should raise an alarm for every suspicious login, but it refuses to run. Tap the line with the bug, then pick the fix.',
    },
    category: 'programming',
    difficulty: 'intro',
    type: 'code-inspection',
    payload: {
      scene: 'code',
      filename: 'alarm.py',
      language: 'python',
      pickableLines: true,
      lines: [
        '# Raise an alarm for every suspicious login',
        'alerts = ["Singapore", "Unknown-IP", "Night-login"]',
        'for alert in alerts',
        '    print("ALARM:", alert)',
        'print("Security team notified!")',
      ],
      fixedLine: { line: 3, text: 'for alert in alerts:' },
      outputAfterSolve: ['ALARM: Singapore', 'ALARM: Unknown-IP', 'ALARM: Night-login', 'Security team notified!'],
    },
    stages: [
      { kind: 'pick', prompt: { ar: 'اضغطي على السطر اللي فيه الخطأ', en: 'Tap the line with the bug' } },
      {
        kind: 'choice',
        prompt: { ar: 'كيف نصلحه؟', en: 'How do we fix it?' },
        options: [
          { id: 'fix-semicolon', label: { ar: 'فاصلة منقوطة في النهاية', en: 'A semicolon at the end' }, mono: 'for alert in alerts;' },
          { id: 'fix-parens', label: { ar: 'أقواس حول الشرط', en: 'Parentheses around it' }, mono: 'for (alert in alerts)' },
          { id: 'fix-colon', label: { ar: 'نقطتين في النهاية', en: 'A colon at the end' }, mono: 'for alert in alerts:' },
          { id: 'fix-quotes', label: { ar: 'علامات تنصيص حول alert', en: 'Quotes around alert' }, mono: 'for "alert" in alerts' },
        ],
      },
    ],
    wrongFeedback: {
      'line-1': { ar: 'هذا تعليق يبدأ بـ# — بايثون يتجاهله.', en: 'That’s a # comment — Python ignores it.' },
      'line-2': { ar: 'القائمة سليمة: أقواس مربعة ونصوص بين علامات تنصيص.', en: 'The list is fine: square brackets and quoted strings.' },
      'line-4': { ar: 'الإزاحة صحيحة — السطر داخل الحلقة.', en: 'The indentation is right — this line is inside the loop.' },
      'line-5': { ar: 'هذا السطر سليم ويشتغل بعد الحلقة.', en: 'This line is fine; it runs after the loop.' },
      'fix-semicolon': { ar: 'الفاصلة المنقوطة للغات ثانية — بايثون يحتاج نقطتين.', en: 'Semicolons are for other languages — Python needs a colon.' },
      'fix-parens': { ar: 'أسلوب لغات ثانية. بايثون أبسط.', en: 'Other languages’ style. Python is simpler.' },
      'fix-quotes': { ar: 'alert متغير؛ بين علامات تنصيص يصير نص عادي.', en: 'alert is a variable; quoting it turns it into plain text.' },
    },
    hints: [
      { ar: 'في بايثون، السطر اللي يفتح «كتلة» (for أو if) ينتهي بعلامة معيّنة.', en: 'In Python, a line that opens a block (for, if) ends with a particular symbol.' },
      { ar: 'سطر for لازم ينتهي بنقطتين : عشان بايثون يعرف إن السطور المزاحة تابعة له.', en: 'The for line must end with a colon : so Python knows the indented lines belong to it.' },
    ],
    explanation: {
      ar: 'أي سطر يفتح كتلة في بايثون — for وif وdef — لازم ينتهي بنقطتين (:) والسطور التابعة له تُزاح. بعد الإصلاح يطلق السكربت ثلاث إنذارات ويبلّغ فريق الأمن. (ما تم تشغيل أي كود فعلياً؛ المخرجات للتوضيح.)',
      en: 'Any Python line that opens a block — for, if, def — must end with a colon, and its body is indented. Fixed, the script raises three alarms and notifies security. (No code was actually run; the output is illustrative.)',
    },
    basePoints: 50,
    reward: 'DERA{c0l0n_s4v3s}',
  },
  {
    id: 'r3-trace',
    room: 'code',
    letter: 'B',
    title: { ar: 'تتبّع الكود', en: 'Trace the Code' },
    description: {
      ar: 'المهاجم كتب برنامج يخمّن رمز PIN لقفل غرفة الخوادم. اقرئي الكود سطر سطر — بدون تشغيل — وتوقّعي وش بيطبع.',
      en: 'The attacker wrote a program that guesses the server-room PIN. Read the code line by line — without running it — and predict what it prints.',
    },
    category: 'programming',
    difficulty: 'easy',
    type: 'code-inspection',
    payload: {
      scene: 'code',
      filename: 'pin_guess.py',
      language: 'python',
      lines: [
        '# How many guesses until the lock opens?',
        'correct_pin = "2580"',
        'attempts = 0',
        'for guess in ["0000", "1234", "2580", "1111"]:',
        '    attempts = attempts + 1',
        '    if guess == correct_pin:',
        '        print("Unlocked after", attempts, "tries")',
        '        break',
      ],
      outputAfterSolve: ['Unlocked after 3 tries'],
    },
    stages: [
      {
        kind: 'choice',
        prompt: { ar: 'وش بيطبع البرنامج؟', en: 'What will the program print?' },
        options: [
          { id: 't-2', label: same('Unlocked after 2 tries') },
          { id: 't-3', label: same('Unlocked after 3 tries') },
          { id: 't-4', label: same('Unlocked after 4 tries') },
          { id: 't-none', label: { ar: 'ما يطبع شي', en: 'Nothing at all' } },
        ],
      },
      {
        kind: 'choice',
        prompt: { ar: 'صح! كيف نحمي القفل من هذا النوع من الهجوم؟', en: 'Right! How do we protect the lock from this kind of attack?' },
        options: [
          { id: 'lock-print', label: { ar: 'نطبع الرمز الصحيح على الشاشة عشان ما أحد ينساه', en: 'Print the correct PIN on screen so nobody forgets it' } },
          { id: 'lock-lockout', label: { ar: 'نقفل القفل مؤقتاً بعد 3 محاولات خاطئة', en: 'Lock it temporarily after 3 wrong attempts' } },
          { id: 'lock-short', label: { ar: 'نخلي الرمز رقمين بس', en: 'Make the PIN just two digits' } },
          { id: 'lock-remove', label: { ar: 'نحذف المتغير attempts', en: 'Delete the attempts variable' } },
        ],
      },
    ],
    wrongFeedback: {
      't-2': { ar: 'تابعي العداد: 0000 ← 1، 1234 ← 2، و2580 ← ؟', en: 'Follow the counter: 0000 → 1, 1234 → 2, and 2580 → ?' },
      't-4': { ar: 'انتبهي لـ break: البرنامج يوقف أول ما يلقى الرمز، فما يوصل لـ 1111.', en: 'Watch the break: the loop stops as soon as it finds the PIN, so it never reaches 1111.' },
      't-none': { ar: 'الرمز 2580 موجود في القائمة، فالشرط بيتحقق ويطبع.', en: '2580 is in the list, so the condition is met and it prints.' },
      'lock-print': { ar: 'هذا يسهّل على المهاجم أكثر!', en: 'That makes it even easier for the attacker!' },
      'lock-short': { ar: 'رمز أقصر = تخمين أسرع. العكس تماماً.', en: 'A shorter PIN means faster guessing. The opposite of safe.' },
      'lock-remove': { ar: 'هذا بس يغيّر الطباعة، والتخمين يستمر.', en: 'That only changes the print-out; the guessing continues.' },
    },
    hints: [
      { ar: 'حطي إصبعك على كل تخمين وزيدي العداد 1، وشوفي متى يتحقق الشرط.', en: 'Point at each guess, add 1 to the counter, and see when the condition is true.' },
      { ar: 'التخمين الثالث هو الصحيح، وbreak يوقف الحلقة فوراً.', en: 'The third guess is the right one, and break stops the loop immediately.' },
    ],
    explanation: {
      ar: 'العداد يصير 3 عند التخمين الصحيح 2580، وbreak يوقف الحلقة — فيطبع Unlocked after 3 tries. هذا اسمه هجوم «القوة الغاشمة» (Brute Force): تجربة كل الاحتمالات. الحماية: قفل الحساب بعد محاولات خاطئة، ورموز أطول، وتحقق ثنائي.',
      en: 'The counter hits 3 on the correct guess 2580, and break ends the loop — so it prints Unlocked after 3 tries. This is a brute-force attack: trying every possibility. The defence: lockout after failed attempts, longer codes, and 2FA.',
    },
    basePoints: 100,
    reward: 'DERA{l0ck_4ft3r_3}',
  },
  {
    id: 'r3-secret',
    room: 'code',
    letter: 'C',
    title: { ar: 'المفتاح المخفي', en: 'The Hidden Key' },
    description: {
      ar: 'المهاجم سيطر على الخادم بمفتاح لقاه في ملف الإعدادات. المبرمج «أخفاه» بالترميز… اضغطي على النصوص الغريبة لنقلها لجهاز فك الترميز، واستخرجي المفتاح بصيغة DERA{...}.',
      en: 'The attacker took over the server with a key found in the config file. The developer “hid” it with encoding… tap the strange strings to send them to the decoder, and extract the key in the format DERA{...}.',
    },
    category: 'programming',
    difficulty: 'medium',
    type: 'flag',
    flagFormat: 'DERA{...}',
    payload: {
      scene: 'secret',
      filename: 'config.py',
      lines: [
        '# config.py — expo server settings',
        'SERVER_IP   = "10.36.0.10"',
        'DEBUG       = True',
        'FLAG_FORMAT = "DERA{example_flag}"   # just an example',
        '',
        '# TODO: remove before the expo!',
        'LOG_NOTE    = "YmFja3VwIGZpbmlzaGVkIGF0IDAyOjAwIC0gbm90aGluZyB0byBzZWUgaGVyZQ=="',
        'ADMIN_KEY   = "REVSQXtoNHJkYzBkM2RfczNjcjN0c19sMzRrfQ=="',
      ],
    },
    stages: [
      {
        kind: 'text',
        prompt: { ar: 'أدخلي المفتاح', en: 'Submit the key' },
        placeholder: same('DERA{...}'),
        mono: true,
      },
    ],
    wrongFeedback: {
      'ctf360{example_flag}': { ar: 'هذا مثال على الصيغة بس. السر الحقيقي مرمّز في مكان ثاني.', en: 'That’s only an example of the format. The real secret is encoded elsewhere.' },
      'revsqxtonhjkyzbkm2rfcznjcjn0c19smzrrfq==': { ar: 'هذا النص لسا مرمّز — فكّيه أول بالجهاز.', en: 'That’s still encoded — decode it first.' },
    },
    hints: [
      { ar: 'النصوص الطويلة اللي تنتهي بـ = غالباً Base64. اضغطي عليها وجرّبي فكّها.', en: 'Long strings ending in = are usually Base64. Tap them and try decoding.' },
      { ar: 'LOG_NOTE فخ. فكّي ADMIN_KEY بأداة Base64.', en: 'LOG_NOTE is a decoy. Decode ADMIN_KEY with the Base64 tool.' },
    ],
    explanation: {
      ar: 'المفتاح كان «مخفي» بـ Base64 — وهذا ترميز مو تشفير: أي أحد يفكه بضغطة زر بدون مفتاح. وفوق كذا كان مكتوب داخل الكود (Hardcoded Secret). الصحيح: الأسرار تُحفظ في خزنة أسرار خارج الكود، وتتغيّر فوراً إذا انكشفت.',
      en: 'The key was “hidden” with Base64 — encoding, not encryption: anyone can reverse it with one click and no key. And it was written into the code itself (a hardcoded secret). The fix: keep secrets in a secrets vault outside the code, and rotate them immediately if exposed.',
    },
    basePoints: 150,
  },
];

// ═══════════════════════ FINAL VAULT — HOW DID THE BREACH HAPPEN? ═══════════════════════
export const FINAL_CHALLENGE: Challenge = {
  id: 'final-signal',
  room: 'final',
  letter: 'Ω',
  title: { ar: 'اكتشاف سبب الاختراق', en: 'Uncover the Breach' },
  description: {
    ar: 'جمعتِ الأدلة من المسارات الثلاثة. الحين ركّبي القصة كاملة: مين دخل، ومتى، وكيف — ثم افتحي القبو برمز النهاية.',
    en: 'You’ve gathered evidence from all three tracks. Now piece the whole story together: who got in, when and how — then open the vault with the final code.',
  },
  category: 'final',
  difficulty: 'medium',
  type: 'flag',
  flagFormat: 'DERA{...}',
  payload: {
    scene: 'chain',
    log: [
      { id: 'row-1', time: '08:12', account: 'razan', place: { ar: 'بريدة', en: 'Buraidah' }, ip: '192.168.10.25', device: 'Windows', ok: true },
      { id: 'row-2', time: '08:15', account: 'razan', place: { ar: 'سنغافورة', en: 'Singapore' }, ip: '203.0.113.47', device: 'iPhone', ok: true },
      { id: 'row-3', time: '08:17', account: 'razan', place: { ar: 'بريدة', en: 'Buraidah' }, ip: '192.168.10.25', device: 'Windows', ok: true },
      { id: 'row-4', time: '08:18', account: 'razan-hr', place: { ar: 'سنغافورة', en: 'Singapore' }, ip: '203.0.113.47', device: 'iPhone', ok: false },
      { id: 'row-5', time: '09:10', account: 'razan', place: { ar: 'بريدة', en: 'Buraidah' }, ip: '192.168.10.25', device: 'Windows', ok: true },
    ],
    steps: [
      {
        id: 'st-reuse',
        title: { ar: 'نفس كلمة المرور تفتح حسابات ثانية', en: 'The same password opens other accounts' },
        text: { ar: 'جرّب كلمة المرور المسروقة على بوابة الموارد البشرية — لأنها مكررة.', en: 'Tried the stolen password on the HR portal — because it was reused.' },
      },
      {
        id: 'st-email',
        title: { ar: 'وصل بريد تصيّد', en: 'A phishing email arrives' },
        text: { ar: 'رسالة «عاجلة» من نطاق مزيّف وصلت لرزان الساعة 08:02.', en: 'An “urgent” email from a fake domain reaches Razan at 08:02.' },
      },
      {
        id: 'st-login',
        title: { ar: 'دخول من سنغافورة', en: 'A login from Singapore' },
        text: { ar: 'المهاجم دخل حساب رزان من جهاز iPhone غريب.', en: 'The attacker logs into Razan’s account from an unknown iPhone.' },
      },
      {
        id: 'st-click',
        title: { ar: 'ضغطت الرابط وأدخلت بياناتها', en: 'She clicks and enters her login' },
        text: { ar: 'صفحة دخول مزيّفة سرقت اسم المستخدم وكلمة المرور.', en: 'A fake login page steals her username and password.' },
      },
    ],
    decoys: ['CLOSE', 'WINDOW', 'LOCKED'],
  },
  stages: [
    { kind: 'pick', prompt: { ar: 'سجل الدخول: اضغطي على أخطر عملية دخول', en: 'Login log: tap the most dangerous login' } },
    { kind: 'pick', prompt: { ar: 'رتّبي تسلسل الهجوم الصحيح', en: 'Put the attack in the right order' } },
    {
      kind: 'text',
      prompt: { ar: 'رمز النهاية: اجمعي شظايا الأدلة بالترتيب', en: 'Final code: assemble the evidence fragments in order' },
      placeholder: same('DERA{...}'),
      mono: true,
    },
  ],
  wrongFeedback: {
    'row-1': { ar: 'دخول عادي من جهاز رزان المعتاد في بريدة.', en: 'A normal login from Razan’s usual PC in Buraidah.' },
    'row-3': { ar: 'هذي رزان نفسها على جهازها المعتاد.', en: 'That’s Razan herself on her usual PC.' },
    'row-5': { ar: 'دخول طبيعي — نفس المكان والجهاز.', en: 'A normal login — same place, same device.' },
    'row-4': { ar: 'محاولة مقلقة، بس فشلت. فيه دخول ناجح من نفس المكان قبلها — هذا الأخطر.', en: 'Worrying, but it failed. There’s a successful login from the same place before it — that’s worse.' },
  },
  hints: [
    {
      ar: 'في السجل: دوّري على مكان وجهاز غير معتادين ونجح فيه الدخول. وفي الترتيب: كل شي بدأ بإيميل الساعة 08:02.',
      en: 'In the log: look for an unusual place and device where the login succeeded. For the order: it all began with the 08:02 email.',
    },
    {
      ar: 'الترتيب: بريد التصيّد ← الضغط وإدخال البيانات ← الدخول من سنغافورة ← تجربة نفس كلمة المرور على حساب ثاني. والرمز: DERA{رمز_المسار1_رمز_المسار2_رمز_المسار3}',
      en: 'Order: phishing email → click and enter details → Singapore login → reusing the password elsewhere. Code: DERA{track1_track2_track3 codes}',
    },
  ],
  explanation: {
    ar: 'الاختراق ما كان «هاكر عبقري» — كان سلسلة أخطاء: رسالة تصيّد انفتحت، بيانات انكتبت في صفحة مزيفة، كلمة مرور ضعيفة ومكررة، وأسرار مكشوفة في الكود. الشظايا بالترتيب تقول «لا تفتح الباب» — رسالة حملة «لا تفتح مجال». كسر أي حلقة وحدة كان بيوقف الهجوم.',
    en: 'The breach wasn’t a genius hacker — it was a chain of mistakes: a phishing email opened, credentials typed into a fake page, a weak reused password, and secrets exposed in code. The fragments, in order, say “don’t open the door” — the لا تفتح مجال campaign. Breaking any one link would have stopped the attack.',
  },
  basePoints: 200,
  reward: 'DERA{br34ch_s0lv3d}',
};

export const ALL_CHALLENGES: Challenge[] = [...CHALLENGES, FINAL_CHALLENGE];
export const byId = (id: string) => ALL_CHALLENGES.find((c) => c.id === id)!;

// Team-facing flavour (funny Najdi lines + tutorial steps), kept in its own file.
import { FLAVOR } from './flavor';
for (const c of [...CHALLENGES, FINAL_CHALLENGE]) Object.assign(c, FLAVOR[c.id] ?? {});
