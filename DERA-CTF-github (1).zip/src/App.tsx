import { useEffect, useRef, useState } from 'react';
import { useStore, stats } from './state/store';
import { useRoute, navigate } from './router';
import { UI } from './data/ui';
import { IntroSequence } from './components/IntroSequence';
import { InvestigationHub } from './components/InvestigationHub';
import { RoomView } from './components/RoomView';
import { FinalVault } from './components/FinalVault';
import { CompletionCertificate } from './components/CompletionCertificate';
import { AdminPanel } from './components/admin/AdminPanel';
import { AuthPage } from './components/boot/AuthPage';
import { autoStartMusic, stopMusic, setTrack, musicState } from './audio/music';
import { LockedScreen } from './components/LockedScreen';
import { useTeam, useAdmin, useSettings } from './state/auth';
import { Leaderboard } from './components/Leaderboard';
import { BootHome, TrainList } from './components/boot/BootHome';
import { TrainView } from './components/boot/TrainView';
import { trainById } from './data/training';
import { AppHeader } from './components/AppHeader';
import { Atmosphere } from './components/Atmosphere';
import { PartnerStrip } from './components/Brand';
import { Dialog } from './components/Controls';
import type { RoomId } from './engine/types';

const ROOM_IDS: RoomId[] = ['helpdesk', 'network', 'code'];
const IDLE_MS = 150_000;
const IDLE_GRACE_S = 20;

/** Exhibition mode: after inactivity, offer the next visitor a clean session. */
function IdleGuard() {
  const { prefs, session, dispatch, t } = useStore();
  const [warn, setWarn] = useState(false);
  const [left, setLeft] = useState(IDLE_GRACE_S);
  const last = useRef(Date.now());
  const active = prefs.exhibition && !!session;

  useEffect(() => {
    if (!active) return;
    const bump = () => {
      last.current = Date.now();
    };
    const evs = ['pointerdown', 'keydown', 'wheel', 'touchstart'] as const;
    evs.forEach((e) => window.addEventListener(e, bump, { passive: true }));
    const id = setInterval(() => {
      if (!warn && Date.now() - last.current > IDLE_MS) {
        setWarn(true);
        setLeft(IDLE_GRACE_S);
      }
    }, 2000);
    return () => {
      evs.forEach((e) => window.removeEventListener(e, bump));
      clearInterval(id);
    };
  }, [active, warn]);

  useEffect(() => {
    if (!warn) return;
    if (left <= 0) {
      setWarn(false);
      dispatch({ type: 'reset' });
      navigate('/intro');
      return;
    }
    const id = setTimeout(() => setLeft((l) => l - 1), 1000);
    return () => clearTimeout(id);
  }, [warn, left, dispatch]);

  const stay = () => {
    last.current = Date.now();
    setWarn(false);
  };

  return (
    <Dialog open={warn && active} onClose={stay} title={t(UI.stillThere)}>
      <p className="dialog__text">
        {t(UI.idleBody)} <b className="mono">{left}</b>s
      </p>
      <div className="dialog__actions">
        <button type="button" className="btn btn--primary btn--lg" onClick={stay}>
          {t(UI.imHere)}
        </button>
      </div>
    </Dialog>
  );
}

function Footer() {
  const { t } = useStore();
  return (
    <footer className="foot no-print">
      <PartnerStrip variant="bar" />
      <p className="foot__text">
        <b>CTF360</b> — {t(UI.tagline)} · {t(UI.footer)}
      </p>
    </footer>
  );
}

export default function App() {
  const { session } = useStore();
  const team = useTeam();
  const admin = useAdmin();
  const settings = useSettings();
  const parts = useRoute();
  const [view, a, b] = parts;
  const st = stats(session);



  // Route guards.
  const KNOWN = ['home', 'train', 'login', 'register', 'intro', 'hub', 'room', 'vault', 'certificate', 'admin', 'leaderboard'];
  let route = view === 'facilitator' ? 'admin' : view && KNOWN.includes(view) ? view : 'home';
  if (route === 'train' && a && !trainById(a)) route = 'train';
  // The competition needs a signed-in team (or the admin's private test run).
  const validSession = !!session && (session.adminTest ? admin : !!team && session.teamId === team.id);
  if (!validSession && ['hub', 'room', 'vault', 'certificate'].includes(route)) route = 'intro';
  if (route === 'room' && !ROOM_IDS.includes(a as RoomId)) route = 'hub';
  if (route === 'vault' && session && !st.vaultOpen) route = 'hub';
  if (route === 'certificate' && session && !st.finalSolved) route = 'hub';

  useEffect(() => {
    const want =
      route === 'room'
        ? `/room/${a}${b ? `/${b}` : ''}`
        : route === 'leaderboard' && a === 'tv'
          ? '/leaderboard/tv'
          : route === 'train' && a && trainById(a)
            ? `/train/${a}`
            : `/${route}`;
    if (`/${parts.join('/')}` !== want) window.history.replaceState(null, '', `#${want}`);
    const titles: Record<string, string> = {
      home: 'DERA CTF — معسكر تدريبي',
      train: 'DERA CTF — التحديات التدريبية',
      intro: 'DERA CTF — المسابقة النهائية',
      hub: 'CTF360 — Control Room',
      room: 'CTF360 — Investigation',
      vault: 'CTF360 — The Last Signal',
      certificate: 'CTF360 — Certificate',
      admin: 'DERA CTF — لوحة المشرفة',
      register: 'DERA CTF — إنشاء حساب',
      login: 'DERA CTF — تسجيل الدخول',
      leaderboard: 'CTF360 — Leaderboard',
    };
    document.title = titles[route] ?? 'DERA CTF';
    document.documentElement.dataset.area = ['home', 'train', 'register', 'login', 'admin'].includes(route) ? 'boot' : 'arena';
  }, [route, a, b, parts]);

  // Organizer lock: the competition and the final vault open only when the admin says so.
  const inComp = ['hub', 'room', 'vault'].includes(route);
  const locked: null | 'competition' | 'vault' =
    !inComp || admin ? null : !settings.loaded || !settings.competitionOpen ? 'competition' : route === 'vault' && !settings.vaultOpen ? 'vault' : null;

  // Hackathon music lives in the final competition only.
  const area = ['home', 'train', 'register', 'login', 'admin'].includes(route) ? 'boot' : 'arena';
  useEffect(() => {
    if (area === 'boot') {
      stopMusic(false);
      return;
    }
    const st = musicState();
    if (st.playing) {
      if (route === 'vault' && st.track !== 'vault') setTrack('vault');
      if (route !== 'vault' && st.track === 'vault') setTrack('hack');
      return;
    }
    if (!st.on) return;
    // Browsers need a tap before audio can start.
    const go = () => autoStartMusic(route === 'vault' ? 'vault' : undefined);
    window.addEventListener('pointerdown', go, { once: true });
    window.addEventListener('keydown', go, { once: true });
    return () => {
      window.removeEventListener('pointerdown', go);
      window.removeEventListener('keydown', go);
    };
  }, [area, route]);

  const tone =
    route === 'room' ? (a as RoomId) : route === 'vault' ? (st.finalSolved ? 'restored' : 'vault') : 'default';

  if (route === 'home') return <BootHome />;
  if (route === 'register' || route === 'login') return <AuthPage mode={route} />;
  if (route === 'admin') return <AdminPanel />;
  if (route === 'train') {
    const c = a ? trainById(a) : undefined;
    return c ? <TrainView c={c} /> : <TrainList />;
  }

  if (route === 'intro')
    return (
      <>
        <Atmosphere tone="default" />
        <IntroSequence />
      </>
    );

  if (route === 'certificate') return <CompletionCertificate />;

  if (route === 'leaderboard' && a === 'tv')
    return (
      <>
        <Atmosphere tone="default" />
        <main className="tvwrap">
          <Leaderboard tv />
        </main>
      </>
    );

  return (
    <div className={`shell shell--${route}`}>
      <Atmosphere tone={tone} />
      <button type="button" className="skiplink" onClick={() => document.getElementById('main')?.focus()}>
        Skip to content
      </button>
      <AppHeader />
      <main id="main" className="shell__main" tabIndex={-1}>
        {locked ? (
          <LockedScreen kind={locked} loading={!settings.loaded} />
        ) : (
          <>
            {route === 'hub' && <InvestigationHub />}
            {route === 'room' && <RoomView roomId={a as RoomId} challengeId={b} />}
            {route === 'vault' && <FinalVault />}
          </>
        )}
        {route === 'leaderboard' && <Leaderboard />}
      </main>
      <Footer />
      <IdleGuard />
    </div>
  );
}
