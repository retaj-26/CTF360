import { accounts } from '../../engine/accounts';
import { setAdmin, setTeam } from '../../state/auth';
import { adoptTraining } from '../../state/training';
import type { TeamProfile, SavedSession } from '../../engine/accounts';

export type SignInResult =
  | { kind: 'admin' }
  | { kind: 'team'; team: TeamProfile; saved: SavedSession | null }
  | { kind: 'error'; code: 'empty' | 'bad' | 'readonly' | 'error' };

/**
 * One sign-in box for everyone: the admin's username + password opens the admin account,
 * a team name + team password opens that team. The admin check runs first.
 */
export async function signIn(user: string, pass: string): Promise<SignInResult> {
  if (!user.trim() || !pass) return { kind: 'error', code: 'empty' };
  const a = await accounts();
  if (await a.adminLogin(user, pass)) {
    setAdmin(true);
    return { kind: 'admin' };
  }
  const r = await a.login(user, pass);
  if (!r.ok) return { kind: 'error', code: r.code };
  setTeam({ id: r.team.id, name: r.team.name, avatar: r.team.avatar, token: r.token });
  adoptTraining(r.saved?.training);
  return { kind: 'team', team: r.team, saved: r.saved?.session ?? null };
}

export const SIGNIN_MSG = {
  empty: { ar: 'اكتبي اسم المستخدم (اسم الفريق) وكلمة المرور.', en: 'Enter the username (team name) and password.' },
  bad: { ar: 'اسم المستخدم أو كلمة المرور غير صحيحة.', en: 'Wrong username or password.' },
  readonly: { ar: 'هذا الجهاز ما يقدر يوصل للحسابات. ادخلي من جهاز المنظِّمة.', en: 'This device can’t reach accounts. Use the organizer’s device.' },
  error: { ar: 'تعذّر الاتصال. جرّبي مرة ثانية.', en: 'Connection failed. Try again.' },
};
