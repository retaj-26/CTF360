import { Plane, Wifi, Volume2, VolumeX, Bluetooth, Printer, FileText, BatteryMedium, Play, Lock, ArrowUp, Paperclip, type LucideIcon } from 'lucide-react';
import type { TrainChallenge, Tile } from '../../data/training';

function Win({ title, children, className = '' }: { title: string; children: React.ReactNode; className?: string }) {
  return (
    <div className={`win ${className}`} dir="ltr">
      <div className="win__bar">
        <span className="win__dots" aria-hidden="true">
          <i />
          <i />
          <i />
        </span>
        <span className="win__title">{title}</span>
      </div>
      <div className="win__body">{children}</div>
    </div>
  );
}

/** Evidence values can be tapped to drop them into the answer box. */
function Tap({ v, onTap, hot }: { v: string; onTap?: (v: string) => void; hot?: boolean }) {
  if (!onTap) return <span className={hot ? 'tapv is-hot' : 'tapv'}>{v}</span>;
  return (
    <button type="button" className={`tapv ${hot ? 'is-hot' : ''}`} onClick={() => onTap(v)} title="↧">
      {v}
    </button>
  );
}

const TILE_ICON: Record<Tile['icon'], LucideIcon> = { plane: Plane, wifi: Wifi, volume: Volume2, bt: Bluetooth, printer: Printer, paper: FileText, battery: BatteryMedium };

/**
 * Renders a challenge's evidence. `found` is the inner value of the captured flag
 * (known only after solving) and is used to highlight the evidence afterwards.
 */
export function TrainScreen({ c, solved, found, onTap }: { c: TrainChallenge; solved: boolean; found: string; onTap?: (v: string) => void }) {
  const sc = c.screen;
  const tap = solved ? undefined : onTap;
  const hot = (v: string) => solved && !!found && v.toUpperCase() === found.toUpperCase();

  switch (sc.type) {
    case 'term':
      return (
        <Win title={sc.title}>
          <pre className="term2">
            {sc.lines.map((l, i) => (
              <span key={i} className={`term2__l ${l.k ? `term2__l--${l.k}` : ''} ${l.k === 'hidden' && solved ? 'is-revealed' : ''}`}>
                {l.t}
                {l.tap && <Tap v={l.tap} onTap={tap} hot={hot(l.tap)} />}
                {'\n'}
              </span>
            ))}
          </pre>
        </Win>
      );
    case 'kv':
      return (
        <div className="kvcard" dir="ltr">
          <div className="kvcard__head">
            <span className="kvcard__status">
              <Wifi size={13} aria-hidden="true" /> {sc.status}
            </span>
            <b>{sc.title}</b>
          </div>
          {sc.rows.map((r) => (
            <div key={r.k} className={`kvcard__row ${hot(r.v) ? 'is-hot' : ''}`}>
              <span>{r.k}</span>
              <Tap v={r.v} onTap={tap} hot={hot(r.v)} />
            </div>
          ))}
        </div>
      );
    case 'log':
      return (
        <Win title={sc.title}>
          <div className="logwrap">
            <table className="logt">
              <thead>
                <tr>
                  {sc.cols.map((h) => (
                    <th key={h}>{h}</th>
                  ))}
                </tr>
              </thead>
              <tbody>
                {sc.rows.map((r, i) => (
                  <tr key={i} className={hot(r[sc.hotCol]) ? 'is-hot' : ''}>
                    {r.map((cell, j) => (
                      <td key={j} className={/FAILED/.test(cell) ? 'is-bad' : /SUCCESS/.test(cell) ? 'is-good' : ''}>
                        {sc.tapCols.includes(j) ? <Tap v={cell} onTap={tap} hot={hot(cell)} /> : cell}
                      </td>
                    ))}
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </Win>
      );
    case 'bars': {
      const max = Math.max(...sc.rows.map((r) => r.v));
      return (
        <Win title={sc.title}>
          <div className="tm">
            {sc.rows.map((r) => (
              <div key={r.app} className="tm__row">
                <Tap v={r.app} onTap={tap} hot={hot(r.app)} />
                <span className="tm__bar">
                  <i className={r.v === max ? 'is-high' : ''} style={{ inlineSize: `${Math.max((r.v / max) * 100, 4)}%` }} />
                </span>
                <b className={r.v === max ? 'is-high' : ''}>
                  {r.v}
                  {sc.unit}
                </b>
              </div>
            ))}
          </div>
        </Win>
      );
    }
    case 'code':
      return (
        <Win title={sc.file}>
          <pre className="code2">
            {sc.lines.map((l, i) => (
              <span key={i} className="code2__l">
                <span className="code2__n">{i + 1}</span>
                {l.split(/("[^"]*")/).map((part, k) =>
                  part.startsWith('"') ? (
                    <span key={k} className="code2__s">
                      {part}
                    </span>
                  ) : (
                    <span key={k}>
                      {part.split(/(print)/).map((p, z) =>
                        p === 'print' ? (
                          <span key={z} className="code2__k">
                            print
                          </span>
                        ) : (
                          p
                        ),
                      )}
                    </span>
                  ),
                )}
                {'\n'}
              </span>
            ))}
          </pre>
          <div className={`code2__out ${solved ? 'is-run' : ''}`}>
            <Play size={12} aria-hidden="true" /> output: <b>{solved ? sc.output : '???'}</b>
          </div>
        </Win>
      );
    case 'tiles':
      return (
        <div className="quick" dir="ltr">
          <b className="quick__title">{sc.title}</b>
          <div className="quick__grid">
            {sc.tiles.map((tl) => {
              const Icon = tl.icon === 'volume' && tl.bad && !solved ? VolumeX : TILE_ICON[tl.icon];
              return (
                <div key={tl.label} className={`quick__tile ${tl.bad ? (solved ? 'is-ok' : 'is-bad') : ''}`}>
                  <span>
                    <Icon size={16} aria-hidden="true" /> {tl.label}
                  </span>
                  <small>{solved ? tl.after : tl.before}</small>
                </div>
              );
            })}
          </div>
        </div>
      );
    case 'email': {
      const [local, domain] = sc.fromAddr.split('@');
      const [toLocal, toDomain] = sc.to.split('@');
      return (
        <Win title="Inbox" className="win--mail">
          <div className="mail">
            <div className="mail__row">
              <span>From</span>
              <span>
                <Tap v={sc.fromName} onTap={tap} />{' '}
                <span className="mail__addr">
                  &lt;{local}@<Tap v={domain} onTap={tap} hot={hot(domain)} />&gt;
                </span>
              </span>
            </div>
            <div className="mail__row">
              <span>To</span>
              <span className="mail__addr">
                {toLocal}@<Tap v={toDomain} onTap={tap} />
              </span>
            </div>
            <div className="mail__row mail__row--subj">
              <span>Subject</span>
              <b>{sc.subject}</b>
            </div>
            <div className="mail__body">
              {sc.body.map((p, i) => (
                <p key={i} className={p.startsWith('http') ? 'mail__link' : ''}>
                  {p}
                </p>
              ))}
            </div>
            <span className="mail__clip">
              <Paperclip size={12} aria-hidden="true" /> 0 attachments
            </span>
          </div>
        </Win>
      );
    }
    case 'login':
      return (
        <div className="loginbox" dir="ltr">
          <div className="loginbox__avatar" aria-hidden="true">
            <Lock size={22} />
          </div>
          <b>{sc.user}</b>
          <div className="loginbox__field">{solved ? '••••••••  ✓' : '••••••••'}</div>
          {solved ? (
            <p className="loginbox__ok">Welcome back!</p>
          ) : (
            <>
              <p className="loginbox__err">The password is incorrect. Try again.</p>
              <p className="loginbox__warn">
                <ArrowUp size={13} aria-hidden="true" /> Caps Lock is on
              </p>
            </>
          )}
        </div>
      );
  }
}
