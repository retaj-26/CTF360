import { useEffect, useState } from 'react';
import { Eye, EyeOff, LogIn, UserPlus, Loader2, XCircle, KeyRound, UserRound } from 'lucide-react';
import { useStore } from '../../state/store';
import { BootShell } from './BootShell';
import { RegisterPage } from './RegisterPage';
import { signIn, SIGNIN_MSG } from './signin';
import { navigate } from '../../router';

function LoginForm() {
  const { t, dispatch } = useStore();
  const [user, setUser] = useState('');
  const [pass, setPass] = useState('');
  const [show, setShow] = useState(false);
  const [busy, setBusy] = useState(false);
  const [err, setErr] = useState<null | keyof typeof SIGNIN_MSG>(null);
  const [fails, setFails] = useState(0);
  const [wait, setWait] = useState(0);

  useEffect(() => {
    if (wait <= 0) return;
    const id = setTimeout(() => setWait((w) => w - 1), 1000);
    return () => clearTimeout(id);
  }, [wait]);

  const submit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (busy || wait > 0) return;
    setBusy(true);
    const r = await signIn(user, pass);
    setBusy(false);
    if (r.kind === 'error') {
      setErr(r.code);
      if (r.code === 'bad') {
        const n = fails + 1;
        setFails(n);
        if (n >= 3) setWait(Math.min(60, 5 * 2 ** (n - 3)));
      }
      return;
    }
    setPass('');
    if (r.kind === 'admin') return navigate('/admin');
    dispatch({ type: 'login', team: r.team, saved: r.saved });
    navigate('/home');
  };

  return (
    <form className="authform" onSubmit={submit} noValidate>
      <label htmlFor="auth-user">
        <UserRound size={15} aria-hidden="true" /> {t({ ar: 'اسم المستخدم (اسم الفريق)', en: 'Username (team name)' })}
      </label>
      <input
        id="auth-user"
        className="reg__input"
        dir="auto"
        autoComplete="username"
        maxLength={40}
        value={user}
        onChange={(e) => {
          setUser(e.target.value);
          setErr(null);
        }}
      />
      <label htmlFor="auth-pass">
        <KeyRound size={15} aria-hidden="true" /> {t({ ar: 'كلمة المرور', en: 'Password' })}
      </label>
      <div className="reg__pw">
        <input
          id="auth-pass"
          className="reg__input mono"
          dir="ltr"
          type={show ? 'text' : 'password'}
          autoComplete="current-password"
          maxLength={64}
          value={pass}
          onChange={(e) => {
            setPass(e.target.value);
            setErr(null);
          }}
        />
        <button type="button" className="reg__eye" onClick={() => setShow((v) => !v)} aria-label={show ? t({ ar: 'إخفاء', en: 'Hide' }) : t({ ar: 'إظهار', en: 'Show' })}>
          {show ? <EyeOff size={18} /> : <Eye size={18} />}
        </button>
      </div>
      {err && (
        <p className="slidefb" role="alert">
          <XCircle size={18} aria-hidden="true" /> {t(SIGNIN_MSG[err])}
          {wait > 0 && ` (${wait}s)`}
        </p>
      )}
      <button type="submit" className="btn2 btn2--ink reg__submit" disabled={busy || wait > 0}>
        {busy ? <Loader2 size={18} className="spin" aria-hidden="true" /> : <LogIn size={18} aria-hidden="true" />} {t({ ar: 'دخول', en: 'Sign in' })}
      </button>
      <p className="authform__alt">
        {t({ ar: 'ما عندكم حساب؟', en: 'No account yet?' })} <a href="#/register">{t({ ar: 'أنشئي حساب الفريق', en: 'Create a team account' })}</a>
      </p>
    </form>
  );
}

export function AuthPage({ mode }: { mode: 'login' | 'register' }) {
  const { t } = useStore();
  return (
    <BootShell tab="login">
      <section className="auth">
        <header className="auth__head">
          <span className="chip chip--ink mono" dir="ltr">
            DERA CTF · ACCOUNT
          </span>
          <h1>{mode === 'login' ? t({ ar: 'تسجيل الدخول', en: 'Sign in' }) : t({ ar: 'إنشاء حساب', en: 'Create account' })}</h1>
        </header>
        <div className="auth__tabs" role="tablist">
          <a role="tab" aria-selected={mode === 'login'} className={mode === 'login' ? 'is-on' : ''} href="#/login">
            <LogIn size={16} aria-hidden="true" /> {t({ ar: 'تسجيل الدخول', en: 'Sign in' })}
          </a>
          <a role="tab" aria-selected={mode === 'register'} className={mode === 'register' ? 'is-on' : ''} href="#/register">
            <UserPlus size={16} aria-hidden="true" /> {t({ ar: 'إنشاء حساب', en: 'Create account' })}
          </a>
        </div>
        {mode === 'login' ? <LoginForm /> : <RegisterPage bare />}
      </section>
    </BootShell>
  );
}
