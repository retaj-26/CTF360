import { setTeam, flushNow } from '../../state/auth';
import { resetTraining } from '../../state/training';
import { navigate } from '../../router';

/** Logs the team out of this device: clears the local session and training copy (the saved copy stays in the database). */
export async function logoutTeam(dispatch: (a: { type: 'reset' }) => void) {
  await flushNow();
  setTeam(null);
  dispatch({ type: 'reset' });
  resetTraining();
  navigate('/home');
}
