import { useEffect, useRef, useState } from 'react';
import { Lightbulb, CheckCircle2, XCircle, ChevronsLeft, ChevronsRight, Send, Ticket, Copy, Swords, LayoutGrid, GraduationCap } from 'lucide-react';
import { useStore } from '../../state/store';
import { TRAINING, SECTIONS, toneOf, type TrainChallenge } from '../../data/training';
import { useTraining, submitTraining, capturedFlag } from '../../state/training';
import { BootShell } from './BootShell';
import { TrainScreen } from './TrainScreens';
import { ScorePill } from './BootHome';
import { navigate } from '../../router';
import { play } from '../../audio/sound';
import type { L10n } from '../../engine/types';

function Confetti() {
  return (
    <div className="confetti" aria-hidden="true">
      {Array.from({ length: 24 }).map((_, i) => (
        <i key={i} style={{ '--x': `${(i * 37) % 100}%`, '--d': `${(i % 6) * 0.08}s`, '--c': ['#C6F04A', '#8B5CF6', '#FF3D8B'][i % 3] } as React.CSSProperties} />
      ))}
    </div>
  );
}

export function TrainView({ c }: { c: TrainChallenge }) {
  const { t, prefs, session } = useStore();
  const tr = useTraining();
  const solved = !!tr.solved[c.id];
  const flag = solved ? capturedFlag(c, tr) : '';
  const found = c.kind === 'flag' ? (flag.match(/\{(.*)\}/)?.[1] ?? '') : '';
  const [text, setText] = useState('');
  const [fb, setFb] = useState<{ ok: boolean; msg?: L10n } | null>(null);
  const [wrongIds, setWrongIds] = useState<string[]>([]);
  const [hint, setHint] = useState(false);
  const [burst, setBurst] = useState(false);
  const [tries, setTries] = useState(0);
  const inputRef = useRef<HTMLInputElement>(null);
  const idx = TRAINING.findIndex((x) => x.id === c.id);
  const next = TRAINING.slice(idx + 1).find((x) => !tr.solved[x.id]) ?? TRAINING[idx + 1];
  const prev = TRAINING[idx - 1];
  const sec = SECTIONS.find((x) => x.id === c.section)!;
  const tone = toneOf(c.section);
  const Next = prefs.lang === 'ar' ? ChevronsLeft : ChevronsRight;
  const Prev = prefs.lang === 'ar' ? ChevronsRight : ChevronsLeft;
  const inSec = TRAINING.filter((x) => x.section === c.section);

  useEffect(() => {
    setText('');
    setFb(null);
    setWrongIds([]);
    setHint(false);
    setBurst(false);
    setTries(0);
    window.scrollTo({ top: 0 });
  }, [c.id]);

  const submit = (raw: string) => {
    if (solved || !raw.trim()) return;
    const v = submitTraining(c, raw);
    setFb(v);
    setTries((n) => n + 1);
    if (v.ok) {
      play('correct');
      setBurst(true);
    } else {
      play('wrong');
      if (c.kind === 'choice') setWrongIds((w) => [...w, raw]);
    }
  };

  const onTap = (v: string) => {
    play('click');
    setText(`DERA{${v}}`);
    setFb(null);
    inputRef.current?.focus();
  };

  return (
    <BootShell tab="train">
      <div className="chalbar">
        <a href="#/train" className="chalbar__back">
          <LayoutGrid size={16} aria-hidden="true" /> {t({ ar: 'لوحة التحديات', en: 'Challenge board' })}
        </a>
        <span className="chalbar__steps" aria-label={sec.tag}>
          {inSec.map((x) => (
            <a key={x.id} href={`#/train/${x.id}`} className={`${x.id === c.id ? 'is-now' : ''} ${tr.solved[x.id] ? 'is-done' : ''}`} aria-label={x.title} />
          ))}
        </span>
        <ScorePill />
      </div>

      <article className={`chal chal--${tone} ${solved ? 'is-solved' : ''}`}>
        <div className="chal__grid">
          <div className="chal__text">
            <div className="chal__meta">
              <span className={`chip chip--${tone}`}>{sec.tag}</span>
              <span className="chal__pts mono" dir="ltr">
                {c.points} PTS
              </span>
              {solved && (
                <span className="chal__solved">
                  <CheckCircle2 size={14} aria-hidden="true" /> {t({ ar: 'محلول', en: 'Solved' })}
                </span>
              )}
            </div>
            <h1 className="chal__title mono" dir="ltr">
              {c.title}
            </h1>
            {c.story && <p className="chal__story">{t(c.story)}</p>}
            {c.ticket && (
              <div className="ticket2">
                <span className="mono" dir="ltr">
                  <Ticket size={14} aria-hidden="true" /> {c.ticket.id}
                </span>
                <b>{t(c.ticket.text)}</b>
              </div>
            )}
            <h2 className="chal__mission">{t(c.mission)}</h2>
            {c.format && (
              <div className="fmtbox">
                <span>{t({ ar: 'صيغة الإجابة', en: 'Answer format' })}</span>
                <code dir="ltr">{c.format}</code>
              </div>
            )}

            {c.kind === 'choice' && (
              <div className="opts" role="group" aria-label={t(c.mission)}>
                {c.options!.map((o, i) => {
                  const wrong = wrongIds.includes(o.id);
                  return (
                    <button
                      key={o.id}
                      type="button"
                      className={`opt ${solved && tr.picks?.[c.id] === o.id ? 'is-right' : ''} ${wrong ? 'is-wrong' : ''}`}
                      disabled={solved || wrong}
                      onClick={() => submit(o.id)}
                    >
                      <span className="opt__k mono">{String.fromCharCode(65 + i)}</span>
                      <span dir="auto">{t(o.label)}</span>
                    </button>
                  );
                })}
              </div>
            )}

            {c.kind === 'flag' && !solved && (
              <>
                <form
                  className="flagin"
                  onSubmit={(e) => {
                    e.preventDefault();
                    submit(text);
                  }}
                >
                  <label htmlFor={`tin-${c.id}`} className="sr-only">
                    Flag
                  </label>
                  <input
                    ref={inputRef}
                    id={`tin-${c.id}`}
                    className="flagin__input mono"
                    dir="ltr"
                    autoComplete="off"
                    autoCapitalize="characters"
                    spellCheck={false}
                    placeholder="DERA{...}"
                    value={text}
                    onChange={(e) => {
                      setText(e.target.value);
                      setFb(null);
                    }}
                  />
                  <button type="submit" className="flagin__btn mono" disabled={!text.trim()}>
                    <Send size={16} aria-hidden="true" /> SUBMIT
                  </button>
                </form>
                {c.screen.type !== 'code' && c.id !== 'w-welcome' && (
                  <p className="chal__taptip">{t({ ar: 'تلميحة سريعة: اضغطي على أي قيمة في الدليل عشان تنحط في خانة الإجابة.', en: 'Tip: tap any value in the evidence to drop it into the answer box.' })}</p>
                )}
              </>
            )}

            {fb && !fb.ok && (
              <p className="slidefb" role="status">
                <XCircle size={18} aria-hidden="true" /> {fb.msg ? t(fb.msg) : t({ ar: 'مو هذا الحل، جرّبي خيار ثاني.', en: 'Not that one — try another option.' })}
              </p>
            )}

            {!solved && (
              <div className="hintrow">
                {hint ? (
                  <p className="hintbox">
                    <Lightbulb size={18} aria-hidden="true" /> {t(c.hint)}
                  </p>
                ) : (
                  <button
                    type="button"
                    className={`hintbtn ${tries >= 2 ? 'is-nudge' : ''}`}
                    onClick={() => {
                      play('hint');
                      setHint(true);
                    }}
                  >
                    <Lightbulb size={16} aria-hidden="true" /> {t({ ar: 'تلميح (مجاني)', en: 'Hint (free)' })}
                  </button>
                )}
              </div>
            )}
          </div>

          <div className="chal__evidence">
            <span className="chal__evlabel mono" dir="ltr">
              EVIDENCE
            </span>
            <TrainScreen c={c} solved={solved} found={found} onTap={c.kind === 'flag' ? onTap : undefined} />
          </div>
        </div>

        {solved && (
          <div className={`capture ${burst ? 'is-burst' : ''}`} role="status">
            {burst && <Confetti />}
            <div className="capture__top">
              <CheckCircle2 size={22} aria-hidden="true" />
              <b>{t({ ar: 'التقطتي العلم!', en: 'Flag captured!' })}</b>
              <span className="mono" dir="ltr">
                +{c.points} PTS
              </span>
            </div>
            <div className="capture__flagrow">
              <code className="capture__flag" dir="ltr">
                {flag}
              </code>
              <button
                type="button"
                className="capture__copy"
                aria-label={t({ ar: 'انسخي الـFlag', en: 'Copy flag' })}
                onClick={() => navigator.clipboard?.writeText(flag).catch(() => {})}
              >
                <Copy size={16} />
              </button>
            </div>
            <p className="capture__learn">
              <GraduationCap size={18} aria-hidden="true" />
              <span>
                <b>{t({ ar: 'وش تعلّمتي؟', en: 'What you learned' })}</b> {t(c.learn)}
              </span>
            </p>
          </div>
        )}

        <div className="chal__nav">
          {prev ? (
            <a className="navbtn" href={`#/train/${prev.id}`}>
              <Prev size={16} aria-hidden="true" /> {t({ ar: 'السابق', en: 'Previous' })}
            </a>
          ) : (
            <span />
          )}
          {next && next.id !== c.id ? (
            <button type="button" className={`navbtn ${solved ? 'navbtn--go' : ''}`} onClick={() => navigate(`/train/${next.id}`)}>
              {t({ ar: 'التحدي التالي', en: 'Next challenge' })} <Next size={16} aria-hidden="true" />
            </button>
          ) : (
            <a className="navbtn navbtn--go" href={session ? '#/hub' : '#/intro'}>
              <Swords size={16} aria-hidden="true" /> {t({ ar: 'للمسابقة النهائية', en: 'To the final competition' })}
            </a>
          )}
        </div>
      </article>
    </BootShell>
  );
}
