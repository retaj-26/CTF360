import { useMemo, useState } from 'react';
import { Eye, EyeOff, UserPlus, Users, KeyRound, CheckCircle2, Circle, TriangleAlert, Swords, Flag, Loader2, Image } from 'lucide-react';
import { useStore } from '../../state/store';
import { accounts, passwordStrength, type Member, type Spec } from '../../engine/accounts';
import { setTeam, useAccountsMode } from '../../state/auth';
import { adoptTraining } from '../../state/training';
import { AVATARS, Avatar, SPECS, avatarById, MEMBER_EMOJIS } from '../Avatar';
import { BootShell } from './BootShell';
import { play } from '../../audio/sound';

const LEVELS = [
  { ar: 'ضعيفة', en: 'Weak' },
  { ar: 'متوسطة', en: 'Medium' },
  { ar: 'قوية', en: 'Strong' },
  { ar: 'قوية جدًا', en: 'Very strong' },
];

export function StrengthMeter({ pw, team }: { pw: string; team: string }) {
  const { t } = useStore();
  const st = passwordStrength(pw, team);
  const items = [
    { ok: st.checks.len8, l: { ar: '8 أحرف أو أكثر', en: '8+ characters' } },
    { ok: st.checks.upper && st.checks.lower, l: { ar: 'حروف كبيرة وصغيرة (Aa)', en: 'Upper & lower case (Aa)' } },
    { ok: st.checks.digit, l: { ar: 'رقم واحد على الأقل', en: 'At least one digit' } },
    { ok: st.checks.symbol, l: { ar: 'رمز مثل ! @ # ؟', en: 'A symbol like ! @ #' } },
    { ok: st.checks.len12, l: { ar: '12 حرفًا = أقوى', en: '12 characters = stronger' } },
  ];
  return (
    <div className={`pwmeter pwmeter--${pw ? st.level : 'none'}`} aria-live="polite">
      <div className="pwmeter__bar" aria-hidden="true">
        {[0, 1, 2, 3].map((i) => (
          <i key={i} className={pw && i <= st.level ? 'is-on' : ''} />
        ))}
      </div>
      <p className="pwmeter__label">
        {t({ ar: 'قوة كلمة المرور:', en: 'Password strength:' })} <b>{pw ? t(LEVELS[st.level]) : '—'}</b>
      </p>
      <ul className="pwmeter__list">
        {items.map((it, i) => (
          <li key={i} className={it.ok ? 'is-ok' : ''}>
            {it.ok ? <CheckCircle2 size={14} aria-hidden="true" /> : <Circle size={14} aria-hidden="true" />} {t(it.l)}
          </li>
        ))}
        {st.weakWord && (
          <li className="is-bad">
            <TriangleAlert size={14} aria-hidden="true" /> {t({ ar: 'فيها كلمة سهلة التخمين (أو اسم الفريق)', en: 'Contains an easy-to-guess word (or the team name)' })}
          </li>
        )}
      </ul>
    </div>
  );
}

type Err = null | 'team' | 'taken' | 'members' | 'spec' | 'weak' | 'match' | 'readonly' | 'error';

function Wrap({ bare, children }: { bare: boolean; children: React.ReactNode }) {
  return bare ? <>{children}</> : <BootShell tab="login">{children}</BootShell>;
}

export function RegisterPage({ bare = false }: { bare?: boolean }) {
  const { t, dispatch } = useStore();
  const mode = useAccountsMode();
  const [name, setName] = useState('');
  const [avatar, setAvatar] = useState('hat-white');
  const [count, setCount] = useState(3);
  const [members, setMembers] = useState<Member[]>(Array.from({ length: 5 }, (_, i) => ({ name: '', spec: '' as Spec, emoji: MEMBER_EMOJIS[i * 3] })));
  const [pickFor, setPickFor] = useState<number | null>(null);
  const [pw, setPw] = useState('');
  const [pw2, setPw2] = useState('');
  const [show, setShow] = useState(false);
  const [err, setErr] = useState<Err>(null);
  const [busy, setBusy] = useState(false);
  const [done, setDone] = useState<null | { name: string; avatar: string; members: Member[] }>(null);
  const list = useMemo(() => members.slice(0, count), [members, count]);
  const st = passwordStrength(pw, name);

  const setM = (i: number, patch: Partial<Member>) => {
    setMembers((m) => m.map((x, j) => (j === i ? { ...x, ...patch } : x)));
    setErr(null);
  };

  const submit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (busy) return;
    if (!name.trim()) return setErr('team');
    if (list.some((m) => !m.name.trim())) return setErr('members');
    if (list.some((m) => !m.spec || (m.spec === 'other' && !m.specOther?.trim()))) return setErr('spec');
    if (st.level < 1 || !st.checks.len8) return setErr('weak');
    if (pw !== pw2) return setErr('match');
    setBusy(true);
    const a = await accounts();
    const r = await a.register({ name: name.trim(), avatar, members: list.map((m) => ({ ...m, name: m.name.trim() })), password: pw });
    setBusy(false);
    if (!r.ok) {
      play('wrong');
      return setErr(r.code === 'taken' ? 'taken' : r.code === 'readonly' ? 'readonly' : 'error');
    }
    play('unlock');
    setTeam({ id: r.team.id, name: r.team.name, avatar: r.team.avatar, token: r.token });
    adoptTraining(undefined);
    dispatch({ type: 'login', team: r.team, saved: null });
    setPw('');
    setPw2('');
    setDone({ name: r.team.name, avatar: r.team.avatar, members: r.team.members });
  };

  const ERR: Record<Exclude<Err, null>, { ar: string; en: string }> = {
    team: { ar: 'اكتبي اسم الفريق.', en: 'Enter a team name.' },
    taken: { ar: 'اسم الفريق مستخدم. اختاري اسمًا ثانيًا.', en: 'That team name is taken.' },
    members: { ar: 'اكتبي اسم كل عضوة.', en: 'Enter every member’s name.' },
    spec: { ar: 'اختاري تخصص كل عضوة (ولو «أخرى» اكتبي التخصص).', en: 'Pick each member’s specialization.' },
    weak: { ar: 'كلمة المرور ضعيفة. خليها 8 أحرف على الأقل مع أرقام وحروف كبيرة وصغيرة.', en: 'Password too weak: 8+ characters with digits and mixed case.' },
    match: { ar: 'كلمتا المرور غير متطابقتين.', en: 'Passwords don’t match.' },
    readonly: {
      ar: 'هذا الجهاز ما يقدر يحفظ الحسابات. سجّلي من جهاز المنظِّمة (أو نسخة السيرفر).',
      en: 'This device can’t save accounts. Register on the organizer’s device (or the server version).',
    },
    error: { ar: 'صار خطأ في الحفظ. جرّبي مرة ثانية.', en: 'Saving failed. Try again.' },
  };

  if (done)
    return (
      <Wrap bare={bare}>
        <section className="regdone">
          <Avatar id={done.avatar} size={96} />
          <span className="chip chip--ink mono" dir="ltr">
            TEAM REGISTERED
          </span>
          <h1>
            {t({ ar: 'أهلًا فريق', en: 'Welcome, team' })} «{done.name}»!
          </h1>
          <p>{t({ ar: 'تم حفظ حسابكم. في المسابقة النهائية تدخلون باسم الفريق وكلمة المرور فقط.', en: 'Your account is saved. In the final competition you only enter the team name and password.' })}</p>
          <ul className="regdone__members">
            {done.members.map((m, i) => (
              <li key={i}>
                <b>
                  {m.emoji} {m.name}
                </b>{' '}
                <span>{SPECS.find((x) => x.id === m.spec)?.icon} {m.spec === 'other' ? m.specOther : t(SPECS.find((x) => x.id === m.spec)!.label)}</span>
              </li>
            ))}
          </ul>
          <div className="regdone__btns">
            <a className="btn2 btn2--ink" href="#/train">
              <Flag size={16} aria-hidden="true" /> {t({ ar: 'ابدئي التدريب', en: 'Start training' })}
            </a>
            <a className="btn2 btn2--pink" href="#/intro">
              <Swords size={16} aria-hidden="true" /> {t({ ar: 'المسابقة النهائية', en: 'Final competition' })}
            </a>
          </div>
        </section>
      </Wrap>
    );

  return (
    <Wrap bare={bare}>
      <form className="reg" onSubmit={submit} noValidate>
        {!bare && <header className="reg__head">
          <span className="chip chip--ink mono" dir="ltr">
            TEAM SIGN-UP
          </span>
          <h1>{t({ ar: 'تسجيل الفريق', en: 'Register your team' })}</h1>
          <p>{t({ ar: 'سجّلي فريقك مرة وحدة. بعدها تدخلون المسابقة النهائية باسم الفريق وكلمة المرور.', en: 'Register once. Then enter the final competition with the team name and password.' })}</p>
          <p className="reg__login">
            {t({ ar: 'عندكم حساب؟', en: 'Already registered?' })} <a href="#/intro">{t({ ar: 'ادخلي من المسابقة النهائية', en: 'Log in from the final competition' })}</a>
          </p>
        </header>}

        {mode && !mode.canWrite && (
          <p className="reg__warn" role="alert">
            <TriangleAlert size={18} aria-hidden="true" /> {t(ERR.readonly)}
          </p>
        )}

        {/* 1 — team */}
        <section className="reg__card">
          <h2>
            <span className="reg__n mono">01</span> <Users size={18} aria-hidden="true" /> {t({ ar: 'اسم الفريق', en: 'Team name' })}
          </h2>
          <input
            id="reg-team"
            className={`reg__input ${err === 'team' || err === 'taken' ? 'is-invalid' : ''}`}
            dir="auto"
            maxLength={32}
            autoComplete="off"
            placeholder={t({ ar: 'مثال: صقور الشبكة', en: 'e.g. Network Falcons' })}
            value={name}
            onChange={(e) => {
              setName(e.target.value);
              setErr(null);
            }}
            aria-label={t({ ar: 'اسم الفريق', en: 'Team name' })}
          />
        </section>

        {/* 2 — avatar */}
        <section className="reg__card">
          <h2>
            <span className="reg__n mono">02</span> <Image size={18} aria-hidden="true" /> {t({ ar: 'صورة الفريق', en: 'Team picture' })}
          </h2>
          <p className="reg__help">
            {t({ ar: 'اختاري قبعة من قبعات الأمن السيبراني أو إيموجي:', en: 'Pick a cyber-security hat or an emoji:' })} <b>{t(avatarById(avatar).label)}</b>
            {avatarById(avatar).meaning && <span> — {t(avatarById(avatar).meaning!)}</span>}
          </p>
          <div className="avpick" role="radiogroup" aria-label={t({ ar: 'صورة الفريق', en: 'Team picture' })}>
            {AVATARS.map((a) => (
              <button
                key={a.id}
                type="button"
                role="radio"
                aria-checked={avatar === a.id}
                aria-label={t(a.label)}
                title={t(a.label)}
                className={`avpick__b ${avatar === a.id ? 'is-on' : ''}`}
                onClick={() => {
                  play('click');
                  setAvatar(a.id);
                }}
              >
                <Avatar id={a.id} size={48} />
                <small>{t(a.label).replace('القبعة ', '')}</small>
              </button>
            ))}
          </div>
        </section>

        {/* 3 — members */}
        <section className="reg__card">
          <h2>
            <span className="reg__n mono">03</span> <UserPlus size={18} aria-hidden="true" /> {t({ ar: 'الأعضاء وتخصصاتهم', en: 'Members & specializations' })}
          </h2>
          <div className="reg__count" role="radiogroup" aria-label={t({ ar: 'عدد الأعضاء', en: 'Number of members' })}>
            <span>{t({ ar: 'عدد الأعضاء:', en: 'Members:' })}</span>
            {[1, 2, 3, 4, 5].map((n) => (
              <button key={n} type="button" role="radio" aria-checked={count === n} className={count === n ? 'is-on' : ''} onClick={() => setCount(n)}>
                {n}
              </button>
            ))}
          </div>
          <div className="reg__members">
            {list.map((m, i) => (
              <div key={i} className="reg__member">
                <button
                  type="button"
                  className={`reg__emoji ${pickFor === i ? 'is-open' : ''}`}
                  onClick={() => setPickFor(pickFor === i ? null : i)}
                  aria-label={`${t({ ar: 'أفتار العضوة', en: 'Member avatar' })} ${i + 1}`}
                  aria-expanded={pickFor === i}
                  title={t({ ar: 'غيّري الأفتار', en: 'Change avatar' })}
                >
                  {m.emoji ?? '🙂'}
                </button>
                <input
                  className={`reg__input ${err === 'members' && !m.name.trim() ? 'is-invalid' : ''}`}
                  dir="auto"
                  maxLength={40}
                  autoComplete="off"
                  placeholder={`${t({ ar: 'اسم العضوة', en: 'Member name' })} ${i + 1}`}
                  aria-label={`${t({ ar: 'اسم العضوة', en: 'Member name' })} ${i + 1}`}
                  value={m.name}
                  onChange={(e) => setM(i, { name: e.target.value })}
                />
                <select
                  className={`reg__input reg__select ${err === 'spec' && !m.spec ? 'is-invalid' : ''}`}
                  aria-label={`${t({ ar: 'التخصص', en: 'Specialization' })} ${i + 1}`}
                  value={m.spec}
                  onChange={(e) => setM(i, { spec: e.target.value as Spec })}
                >
                  <option value="" disabled>
                    {t({ ar: 'التخصص…', en: 'Specialization…' })}
                  </option>
                  {SPECS.slice(0, 3).map((sp) => (
                    <option key={sp.id} value={sp.id}>
                      {sp.icon} {t(sp.label)}
                    </option>
                  ))}
                  <optgroup label={t({ ar: 'أخرى', en: 'Other' })}>
                    {SPECS.slice(3).map((sp) => (
                      <option key={sp.id} value={sp.id}>
                        {sp.icon} {t(sp.label).replace(/^أخرى · |^Other · /, '')}
                      </option>
                    ))}
                  </optgroup>
                </select>
                {m.spec === 'other' && (
                  <input
                    className={`reg__input reg__other ${err === 'spec' && !m.specOther?.trim() ? 'is-invalid' : ''}`}
                    dir="auto"
                    maxLength={40}
                    placeholder={t({ ar: 'اكتبي التخصص', en: 'Type the specialization' })}
                    aria-label={t({ ar: 'اكتبي التخصص', en: 'Type the specialization' })}
                    value={m.specOther ?? ''}
                    onChange={(e) => setM(i, { specOther: e.target.value })}
                  />
                )}
                {pickFor === i && (
                  <div className="emojipick" role="radiogroup" aria-label={t({ ar: 'اختاري أفتار', en: 'Pick an avatar' })}>
                    {MEMBER_EMOJIS.map((e) => (
                      <button
                        key={e}
                        type="button"
                        role="radio"
                        aria-checked={m.emoji === e}
                        className={m.emoji === e ? 'is-on' : ''}
                        onClick={() => {
                          setM(i, { emoji: e });
                          setPickFor(null);
                        }}
                      >
                        {e}
                      </button>
                    ))}
                  </div>
                )}
              </div>
            ))}
          </div>
        </section>

        {/* 4 — password */}
        <section className="reg__card">
          <h2>
            <span className="reg__n mono">04</span> <KeyRound size={18} aria-hidden="true" /> {t({ ar: 'كلمة مرور الفريق', en: 'Team password' })}
          </h2>
          <div className="reg__pw">
            <input
              className={`reg__input mono ${err === 'weak' ? 'is-invalid' : ''}`}
              dir="ltr"
              type={show ? 'text' : 'password'}
              autoComplete="new-password"
              maxLength={64}
              placeholder="••••••••"
              aria-label={t({ ar: 'كلمة المرور', en: 'Password' })}
              value={pw}
              onChange={(e) => {
                setPw(e.target.value);
                setErr(null);
              }}
            />
            <button type="button" className="reg__eye" onClick={() => setShow((v) => !v)} aria-label={show ? t({ ar: 'إخفاء', en: 'Hide' }) : t({ ar: 'إظهار', en: 'Show' })}>
              {show ? <EyeOff size={18} /> : <Eye size={18} />}
            </button>
          </div>
          <StrengthMeter pw={pw} team={name} />
          <input
            className={`reg__input mono ${err === 'match' ? 'is-invalid' : ''}`}
            dir="ltr"
            type={show ? 'text' : 'password'}
            autoComplete="new-password"
            maxLength={64}
            placeholder={t({ ar: 'أعيدي كتابة كلمة المرور', en: 'Repeat the password' })}
            aria-label={t({ ar: 'تأكيد كلمة المرور', en: 'Confirm password' })}
            value={pw2}
            onChange={(e) => {
              setPw2(e.target.value);
              setErr(null);
            }}
          />
          <p className="reg__help">{t({ ar: 'لا تستخدمون كلمة مرور حساباتكم الشخصية. كلمة المرور تُحفظ مشفّرة (Hash) وما أحد يقدر يقرأها.', en: 'Don’t reuse a personal password. It is stored only as a salted hash.' })}</p>
        </section>

        {err && (
          <p className="slidefb" role="alert">
            <TriangleAlert size={18} aria-hidden="true" /> {t(ERR[err])}
          </p>
        )}
        <button type="submit" className="btn2 btn2--ink reg__submit" disabled={busy}>
          {busy ? <Loader2 size={18} className="spin" aria-hidden="true" /> : <UserPlus size={18} aria-hidden="true" />} {t({ ar: 'سجّلي الفريق', en: 'Register team' })}
        </button>
      </form>
    </Wrap>
  );
}
