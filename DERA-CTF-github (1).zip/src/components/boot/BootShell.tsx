import type { ReactNode } from 'react';
import { Home, Flag, Swords, Trophy, LogIn, LogOut, ShieldCheck } from 'lucide-react';
import { useTeam, useAdmin, setAdmin } from '../../state/auth';
import { navigate } from '../../router';
import { Avatar } from '../Avatar';
import { logoutTeam } from './logout';
import { useStore } from '../../state/store';

const A = (f: string) => `${import.meta.env.BASE_URL}assets/${f}`;

export type BootTab = 'home' | 'train' | 'board' | 'login' | 'admin';

/** Pixel flag from the session cover — drawn as squares, not an image. */
export function PixelFlag({ size = 200 }: { size?: number }) {
  const cells: { x: number; y: number; c: string }[] = [];
  for (let y = 0; y < 13; y++) cells.push({ x: 0, y, c: 'w' }); // pole
  cells.push({ x: 1, y: 12, c: 'w' }, { x: 2, y: 12, c: 'w' }, { x: 1, y: 11, c: 'w' });
  const flag = [
    [1, 1, 1, 1, 1, 1, 1, 1, 0, 0],
    [1, 1, 1, 1, 1, 1, 1, 1, 1, 0],
    [1, 1, 1, 2, 2, 1, 1, 1, 1, 1],
    [1, 1, 1, 2, 2, 1, 1, 1, 1, 0],
    [1, 1, 1, 1, 1, 1, 1, 1, 0, 0],
  ];
  flag.forEach((row, y) => row.forEach((v, x) => v && cells.push({ x: x + 1, y: y + 1, c: v === 2 ? 'l' : 'v' })));
  const g = 13;
  return (
    <svg className="pixflag" width={size} height={(size * 14) / 12} viewBox={`0 0 ${12 * g} ${14 * g}`} aria-hidden="true">
      {cells.map((p, i) => (
        <rect
          key={i}
          x={p.x * g}
          y={p.y * g}
          width={g - 2}
          height={g - 2}
          className={`pixflag__c pixflag__c--${p.c}`}
          style={{ animationDelay: `${(p.x + p.y) * 0.05}s` }}
        />
      ))}
    </svg>
  );
}

export function BootLogos({ variant = 'head' }: { variant?: 'head' | 'all' }) {
  if (variant === 'all')
    return (
      <div className="bootlogos bootlogos--all" role="group" aria-label="partners">
        <img src={A('dera360-violet.png')} alt="جمعية درع 360 للأمن السيبراني — Dera 360 Cybersecurity" />
        <img src={A('nca.png')} alt="الهيئة الوطنية للأمن السيبراني — National Cybersecurity Authority" />
        <img src={A('la-taftah-majal-dark.png')} alt="لا تفتح مجال" />
        <img src={A('haksa.png')} alt="HAKSA Computer" />
        <img src={A('qassim-girls.png')} alt="جمعية فتاة القصيم الأهلية — Association of Qassim Girl" />
        <img src={A('tvtc-buraidah.png')} alt="المؤسسة العامة للتدريب التقني والمهني — الكلية التقنية ببريدة" />
      </div>
    );
  return null;
}

export function Dashes({ total, current, done }: { total: number; current: number; done: boolean[] }) {
  return (
    <div className="dashes" aria-hidden="true">
      {Array.from({ length: total }).map((_, i) => (
        <i key={i} className={`${done[i] ? 'is-done' : ''} ${i === current ? 'is-now' : ''}`} />
      ))}
    </div>
  );
}

export function BootShell({ tab, children, dashes }: { tab: BootTab; children: ReactNode; dashes?: ReactNode }) {
  const { t, dispatch } = useStore();
  const team = useTeam();
  const admin = useAdmin();
  const items = [
    { id: 'home', href: '#/home', icon: Home, label: t({ ar: 'الرئيسية', en: 'Home' }) },
    { id: 'train', href: '#/train', icon: Flag, label: t({ ar: 'التحديات التدريبية', en: 'Training' }) },
    { id: 'final', href: '#/intro', icon: Swords, label: t({ ar: 'المسابقة النهائية', en: 'Final competition' }) },
    { id: 'board', href: '#/leaderboard', icon: Trophy, label: t({ ar: 'لوحة الترتيب', en: 'Leaderboard' }) },
    ...(team || admin ? [] : [{ id: 'login', href: '#/login', icon: LogIn, label: t({ ar: 'تسجيل الدخول', en: 'Sign in' }) }]),
    ...(admin ? [{ id: 'admin', href: '#/admin', icon: ShieldCheck, label: t({ ar: 'لوحة المشرفة', en: 'Admin' }) }] : []),
  ];
  return (
    <div className="boot">
      <header className="boot__head">
        <div className="boot__bar">
          <a href="#/home" className="boot__brand" aria-label="DERA CTF">
            <img src={A('dera360-violet.png')} alt="جمعية درع 360 للأمن السيبراني" />
          </a>
          {dashes}
          <div className="boot__right">
            <img className="boot__mark" src={A('la-taftah-majal-dark.png')} alt="لا تفتح مجال" />
            <span className="boot__sep" aria-hidden="true" />
            <img className="boot__mark boot__mark--nca" src={A('nca.png')} alt="الهيئة الوطنية للأمن السيبراني" />
          </div>
        </div>
        <nav className="bootnav" aria-label={t({ ar: 'القائمة', en: 'Menu' })}>
          {items.map((it) => (
            <a key={it.id} href={it.href} className={`bootnav__a ${it.id === tab ? 'is-active' : ''} ${it.id === 'final' ? 'bootnav__a--final' : ''}`} aria-current={it.id === tab ? 'page' : undefined}>
              <it.icon size={16} aria-hidden="true" />
              {it.label}
            </a>
          ))}
          {admin && (
            <span className="teamchip teamchip--admin">
              <ShieldCheck size={18} aria-hidden="true" />
              <b>{t({ ar: 'المشرفة', en: 'Admin' })}</b>
              <button
                type="button"
                className="teamchip__out"
                onClick={() => {
                  setAdmin(false);
                  navigate('/home');
                }}
                aria-label={t({ ar: 'تسجيل الخروج', en: 'Log out' })}
                title={t({ ar: 'تسجيل الخروج', en: 'Log out' })}
              >
                <LogOut size={14} />
              </button>
            </span>
          )}
          {team && (
            <span className="teamchip">
              <Avatar id={team.avatar} size={26} />
              <b dir="auto">{team.name}</b>
              <button type="button" className="teamchip__out" onClick={() => logoutTeam(dispatch)} aria-label={t({ ar: 'تسجيل الخروج', en: 'Log out' })} title={t({ ar: 'تسجيل الخروج', en: 'Log out' })}>
                <LogOut size={14} />
              </button>
            </span>
          )}
        </nav>
      </header>
      <main className="boot__main" id="main" tabIndex={-1}>
        {children}
      </main>
      <footer className="boot__foot">
        <BootLogos variant="all" />
        <p>
          <span className="mono" dir="ltr">
            DERA CTF
          </span>{' '}
          | {t({ ar: 'من الفكرة إلى حل التحدي', en: 'From idea to solved challenge' })} · {t({ ar: 'جمعية درع 360 للأمن السيبراني', en: 'Dera 360 Cybersecurity Association' })}
        </p>
      </footer>
    </div>
  );
}
