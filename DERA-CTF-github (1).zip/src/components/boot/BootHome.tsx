import { useState } from 'react';
import { Search, Globe, Wrench, Code2, FlaskConical, Flag, CheckCircle2, Swords, RotateCcw, Trophy, Lock } from 'lucide-react';
import { useStore } from '../../state/store';
import { TRAINING, SECTIONS, TRAIN_MAX, type TrainSection } from '../../data/training';
import { useTraining, trainScore, resetTraining } from '../../state/training';
import { BootShell, PixelFlag } from './BootShell';

const SECTION_ICON: Record<TrainSection, typeof Globe> = { start: Flag, net: Globe, support: Wrench, clues: Search, code: Code2, lab: FlaskConical };

export function ScorePill() {
  const tr = useTraining();
  const done = TRAINING.filter((c) => tr.solved[c.id]).length;
  return (
    <span className="scorepill mono" dir="ltr">
      <Flag size={14} aria-hidden="true" /> {done}/{TRAINING.length}
      <i aria-hidden="true" />
      <b>{trainScore(tr)}</b> PTS
    </span>
  );
}

function Board() {
  const { t } = useStore();
  const tr = useTraining();
  const [filter, setFilter] = useState<TrainSection | 'all'>('all');
  const cols = SECTIONS.filter((s) => filter === 'all' || s.id === filter);
  return (
    <section className="ctfb" aria-labelledby="ctfb-title">
      <h2 id="ctfb-title" className="sr-only">
        {t({ ar: 'لوحة التحديات', en: 'Challenge board' })}
      </h2>
      <div className="ctfb__tabs" role="tablist" aria-label={t({ ar: 'الفئات', en: 'Categories' })}>
        <button type="button" role="tab" aria-selected={filter === 'all'} className={filter === 'all' ? 'is-on' : ''} onClick={() => setFilter('all')}>
          {t({ ar: 'الكل', en: 'All' })}
        </button>
        {SECTIONS.map((s) => {
          const Icon = SECTION_ICON[s.id];
          return (
            <button key={s.id} type="button" role="tab" aria-selected={filter === s.id} className={`tab--${s.tone} ${filter === s.id ? 'is-on' : ''}`} onClick={() => setFilter(s.id)}>
              <Icon size={14} aria-hidden="true" /> <span dir="ltr">{s.tag}</span>
            </button>
          );
        })}
      </div>

      <div className={`ctfb__cols ${filter !== 'all' ? 'is-single' : ''}`}>
        {cols.map((sec) => {
          const items = TRAINING.filter((c) => c.section === sec.id);
          const done = items.filter((c) => tr.solved[c.id]).length;
          const Icon = SECTION_ICON[sec.id];
          return (
            <div key={sec.id} className={`ctfcol ctfcol--${sec.tone}`}>
              <div className="ctfcol__head">
                <span className="ctfcol__icon">
                  <Icon size={18} aria-hidden="true" />
                </span>
                <div>
                  <b className="mono" dir="ltr">
                    {sec.tag}
                  </b>
                  <small>{t(sec.title)}</small>
                </div>
                <span className="ctfcol__count mono" dir="ltr">
                  {done}/{items.length}
                </span>
              </div>
              <div className="ctfcol__tiles">
                {items.map((c) => {
                  const ok = !!tr.solved[c.id];
                  return (
                    <a key={c.id} href={`#/train/${c.id}`} className={`ctile ${ok ? 'is-done' : ''}`}>
                      <span className="ctile__pts mono" dir="ltr">
                        {c.points}
                      </span>
                      <span className="ctile__name mono" dir="ltr">
                        {c.title}
                      </span>
                      <span className="ctile__state">
                        {ok ? (
                          <>
                            <CheckCircle2 size={14} aria-hidden="true" /> {t({ ar: 'محلول', en: 'Solved' })}
                          </>
                        ) : c.kind === 'choice' ? (
                          t({ ar: 'اختيار', en: 'Pick' })
                        ) : (
                          <span dir="ltr">DERA{'{…}'}</span>
                        )}
                      </span>
                    </a>
                  );
                })}
              </div>
            </div>
          );
        })}
      </div>
    </section>
  );
}

export function BootHome({ tab = 'home' }: { tab?: 'home' | 'train' }) {
  const { t, session } = useStore();
  const tr = useTraining();
  const [confirm, setConfirm] = useState(false);
  const score = trainScore(tr);
  const done = TRAINING.filter((c) => tr.solved[c.id]).length;
  const pct = Math.round((score / TRAIN_MAX) * 100);
  const first = TRAINING.find((c) => !tr.solved[c.id]);
  const all = done === TRAINING.length;

  return (
    <BootShell tab={tab}>
      <section className="camp">
        <div className="camp__text">
          <span className="chip chip--ink mono" dir="ltr">
            DERA CTF · TRAINING CAMP
          </span>
          <h1>{t({ ar: 'المعسكر التدريبي', en: 'Training camp' })}</h1>
          <p>
            {t({
              ar: `${TRAINING.length} تحدي سهل في الشبكات والدعم الفني والأدلة السيبرانية والكود. افحصي الدليل، التقطي الـFlag، واجمعي النقاط.`,
              en: `${TRAINING.length} easy challenges in networking, IT support, cyber clues and code. Inspect the evidence, capture the flag, collect points.`,
            })}
          </p>
          <div className="camp__cta">
            {first ? (
              <a className="btn2 btn2--ink" href={`#/train/${first.id}`}>
                <Flag size={16} aria-hidden="true" /> {done ? t({ ar: 'كمّلي التحديات', en: 'Continue' }) : t({ ar: 'ابدئي أول تحدي', en: 'Start the first challenge' })}
              </a>
            ) : (
              <a className="btn2 btn2--ink" href={session ? '#/hub' : '#/intro'}>
                <Swords size={16} aria-hidden="true" /> {t({ ar: 'للمسابقة النهائية', en: 'To the final competition' })}
              </a>
            )}
          </div>
        </div>
        <div className="camp__score" dir="ltr">
          <PixelFlag size={92} />
          <div className="camp__nums mono">
            <small>SCORE</small>
            <b>{String(score).padStart(3, '0')}</b>
            <small>/ {TRAIN_MAX} PTS</small>
          </div>
          <div className="camp__bar" role="progressbar" aria-valuemin={0} aria-valuemax={TRAIN_MAX} aria-valuenow={score} aria-label="score">
            <i style={{ inlineSize: `${pct}%` }} />
          </div>
          <span className="camp__flags mono">
            FLAGS {done}/{TRAINING.length}
          </span>
        </div>
      </section>

      <Board />

      <section className={`finalbox ${all ? 'is-ready' : ''}`}>
        <span className="finalbox__icon">{all ? <Swords size={24} aria-hidden="true" /> : <Lock size={22} aria-hidden="true" />}</span>
        <div>
          <b>{all ? t({ ar: 'جاهزة للمسابقة النهائية!', en: 'Ready for the final competition!' }) : t({ ar: 'المسابقة النهائية', en: 'The final competition' })}</b>
          <p>
            {t({
              ar: 'سجّلي فريقك، حلّي تحديات المسارات الثلاثة، وافتحي القبو الأخير — والترتيب يطلع مباشرة على لوحة الأفرقة.',
              en: 'Register your team, solve the three tracks, open the final vault — rankings go live on the leaderboard.',
            })}
          </p>
        </div>
        <div className="finalbox__btns">
          <a className="btn2 btn2--pink" href={session ? '#/hub' : '#/intro'}>
            <Swords size={16} aria-hidden="true" /> {t({ ar: 'ادخلي المسابقة', en: 'Enter competition' })}
          </a>
          <a className="btn2 btn2--ghost" href="#/leaderboard">
            <Trophy size={16} aria-hidden="true" /> {t({ ar: 'لوحة الترتيب', en: 'Leaderboard' })}
          </a>
        </div>
      </section>

      <div className="camp__reset">
        {confirm ? (
          <span>
            {t({ ar: 'أكيد تبين تمسحين نقاط التدريب؟', en: 'Clear training progress?' })}{' '}
            <button
              type="button"
              className="linkbtn"
              onClick={() => {
                resetTraining();
                setConfirm(false);
              }}
            >
              {t({ ar: 'نعم، امسحي', en: 'Yes, clear' })}
            </button>{' '}
            <button type="button" className="linkbtn" onClick={() => setConfirm(false)}>
              {t({ ar: 'إلغاء', en: 'Cancel' })}
            </button>
          </span>
        ) : (
          done > 0 && (
            <button type="button" className="linkbtn" onClick={() => setConfirm(true)}>
              <RotateCcw size={14} aria-hidden="true" /> {t({ ar: 'ابدئي التدريب من جديد', en: 'Restart training' })}
            </button>
          )
        )}
      </div>
    </BootShell>
  );
}

export function TrainList() {
  return <BootHome tab="train" />;
}
