import { useEffect, useState } from 'react';
import { ArrowRight, ArrowLeft, CheckCircle2, FileWarning, Stamp, ShieldCheck } from 'lucide-react';
import { useStore, roomProgress } from '../state/store';
import { roomById } from '../data/rooms';
import { byId } from '../data/challenges';
import { UI } from '../data/ui';
import { ChallengeRenderer } from './challenge/ChallengeRenderer';
import { navigate } from '../router';
import { play } from '../audio/sound';
import type { RoomId } from '../engine/types';

function RoomReport({ roomId, onClose }: { roomId: RoomId; onClose: () => void }) {
  const { t, session, progressOf } = useStore();
  const room = roomById(roomId);
  const pts = room.challengeIds.reduce((s, id) => s + progressOf(id).points, 0);
  const hints = room.challengeIds.reduce((s, id) => s + progressOf(id).hintsUsed, 0);
  useEffect(() => play('unlock'), []);
  return (
    <div className="report" role="dialog" aria-modal="true" aria-labelledby="report-title" style={{ '--accent': room.accent } as React.CSSProperties}>
      <div className="report__paper">
        <div className="report__top">
          <p className="report__kicker mono" dir="ltr">
            CASE_001 · D360_0{room.index} · {session?.id.toUpperCase()} // CLOSED
          </p>
          <div className="report__stamp" aria-hidden="true">
            <Stamp size={18} /> {t(UI.roomCleared)}
          </div>
        </div>
        <h2 id="report-title" className="report__title">
          <FileWarning size={24} aria-hidden="true" /> {t(UI.reportTitle)} — {t(room.name)}
        </h2>
        <ul className="report__list">
          {room.challengeIds.map((id) => {
            const c = byId(id);
            const p = progressOf(id);
            return (
              <li key={id}>
                <CheckCircle2 size={16} aria-hidden="true" /> <span>{t(c.title)}</span>
                <b className="mono" dir="ltr">
                  +{p.points}
                </b>
              </li>
            );
          })}
        </ul>
        <p className="report__text">{t(room.report)}</p>
        <div className="report__fragment">
          <span>{t(UI.fragmentFound)}</span>
          <span className="codeboxes" dir="ltr">
            <span className="codeboxes__grp">
              {room.fragment.split('').map((ch, i) => (
                <i key={i} style={{ animationDelay: `${0.6 + i * 0.12}s` }}>
                  {ch}
                </i>
              ))}
            </span>
          </span>
          <small dir="ltr" className="mono">
            {room.index}/3
          </small>
        </div>
        <p className="report__lesson">
          <ShieldCheck size={18} aria-hidden="true" /> <b>{t(UI.lesson)}:</b> {t(room.lesson)}
        </p>
        <p className="report__meta mono" dir="ltr">
          {pts} pts · {hints} hints
        </p>
        <button type="button" className="btn btn--primary btn--lg" autoFocus onClick={onClose}>
          {t(UI.backToHub)}
        </button>
      </div>
    </div>
  );
}

export function RoomView({ roomId, challengeId }: { roomId: RoomId; challengeId?: string }) {
  const { t, prefs, session, dispatch, progressOf } = useStore();
  const room = roomById(roomId);
  const rp = roomProgress(session, roomId);
  const firstOpen = room.challengeIds.find((id) => !progressOf(id).solved) ?? room.challengeIds[0];
  const activeId = challengeId && room.challengeIds.includes(challengeId) ? challengeId : firstOpen;
  const [showReport, setShowReport] = useState(false);

  // Pin the active challenge in the URL so solving it doesn't jump straight to the next one.
  useEffect(() => {
    if (challengeId !== activeId) window.location.replace(`#/room/${roomId}/${activeId}`);
  }, [challengeId, activeId, roomId]);

  const Back = prefs.lang === 'ar' ? ArrowRight : ArrowLeft;

  const goNext = () => {
    play('click');
    const next = room.challengeIds.find((id) => id !== activeId && !progressOf(id).solved);
    if (next) navigate(`/room/${roomId}/${next}`);
    else if (rp.complete) {
      setShowReport(true);
      dispatch({ type: 'seenReport', room: roomId });
    } else navigate('/hub');
  };

  const remainingAfter = room.challengeIds.filter((id) => id !== activeId && !progressOf(id).solved).length;
  const nextLabel = remainingAfter > 0 ? t(UI.nextChallenge) : t(UI.finishRoom);

  return (
    <div className={`room room--${roomId}`} style={{ '--accent': room.accent } as React.CSSProperties}>
      <header className="room__head">
        <a className="btn btn--ghost btn--sm room__back" href="#/hub" onClick={() => play('click')}>
          <Back size={16} aria-hidden="true" /> {t(UI.backHub)}
        </a>
        <div className="room__titles">
          <p className="kicker mono" dir="ltr">
            D360_0{room.index} // TRACK 0{room.index} · {room.category.en.toUpperCase()}
          </p>
          <div className="bignum-row">
            <span className="bignum" dir="ltr">
              0{room.index}
            </span>
            <div>
              <p className="clue-label">{t(room.clue)}</p>
              <h1 className="room__name">{t(room.category)}</h1>
            </div>
          </div>
          <p className="room__story">{t(room.story)}</p>
        </div>
        <div className="room__meter" aria-label={`${rp.done}/${rp.total}`}>
          <span className="mono" dir="ltr">
            {rp.done}/{rp.total}
          </span>
          <div className="room__meterbar">
            <i style={{ inlineSize: `${(rp.done / rp.total) * 100}%` }} />
          </div>
          {rp.complete && (
            <button
              type="button"
              className="btn btn--ghost btn--sm"
              onClick={() => {
                setShowReport(true);
              }}
            >
              <FileWarning size={16} aria-hidden="true" /> {t(UI.reportTitle)}
            </button>
          )}
        </div>
      </header>

      <nav className="tabs" aria-label={t(room.name)}>
        {room.challengeIds.map((id) => {
          const c = byId(id);
          const p = progressOf(id);
          const active = id === activeId;
          return (
            <a
              key={id}
              href={`#/room/${roomId}/${id}`}
              className={`tab ${active ? 'is-active' : ''} ${p.solved ? 'is-solved' : ''}`}
              aria-current={active ? 'page' : undefined}
              onClick={() => play('click')}
            >
              <span className="tab__letter mono">{p.solved ? '✓' : c.letter}</span>
              <span className="tab__name">{t(c.title)}</span>
              {p.solved && (
                <span className="tab__pts mono" dir="ltr">
                  +{p.points}
                </span>
              )}
            </a>
          );
        })}
      </nav>

      <ChallengeRenderer key={activeId} challenge={byId(activeId)} onNext={goNext} nextLabel={nextLabel} />

      {showReport && (
        <RoomReport
          roomId={roomId}
          onClose={() => {
            setShowReport(false);
            navigate('/hub');
          }}
        />
      )}
    </div>
  );
}
