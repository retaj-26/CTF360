import type { RoomId } from '../engine/types';

/** Original, code-drawn room illustrations (no external imagery). */
export function RoomArt({ id }: { id: RoomId }) {
  if (id === 'helpdesk')
    return (
      <svg className="art art--helpdesk" viewBox="0 0 320 180" aria-hidden="true">
        <defs>
          <radialGradient id="hd-glow" cx="50%" cy="45%" r="60%">
            <stop offset="0" stopColor="#FF6B1A" stopOpacity=".35" />
            <stop offset="1" stopColor="#FF6B1A" stopOpacity="0" />
          </radialGradient>
        </defs>
        <rect x="0" y="0" width="320" height="180" fill="url(#hd-glow)" />
        {/* desk */}
        <rect x="20" y="150" width="280" height="8" rx="2" fill="#1d2029" />
        {/* monitor */}
        <rect x="95" y="28" width="130" height="96" rx="10" fill="#14161d" stroke="#2c303b" strokeWidth="2" />
        <rect className="art__screen" x="105" y="38" width="110" height="74" rx="4" fill="#0b1a12" />
        <g className="art__ghost">
          <path d="M140 98 V68 a20 20 0 0 1 40 0 V98 l-6.6 -6 -6.7 6 -6.7 -6 -6.7 6 -6.6 -6 z" fill="#d9fbe7" opacity=".9" />
          <circle cx="153" cy="70" r="3.4" fill="#0b1a12" />
          <circle cx="167" cy="70" r="3.4" fill="#0b1a12" />
          <ellipse cx="160" cy="81" rx="4" ry="5" fill="#0b1a12" />
        </g>
        <rect x="150" y="124" width="20" height="18" fill="#1d2029" />
        <rect x="132" y="140" width="56" height="8" rx="3" fill="#23262f" />
        {/* sticky note */}
        <g className="art__sticky">
          <rect x="214" y="44" width="34" height="34" fill="#FFB347" transform="rotate(8 231 61)" />
          <path d="M219 56h22M219 63h16M219 70h20" stroke="#7a4a10" strokeWidth="2" transform="rotate(8 231 61)" />
        </g>
        {/* mug + keyboard */}
        <rect x="246" y="126" width="22" height="24" rx="4" fill="#2a2d37" />
        <path d="M268 132 a7 7 0 0 1 0 12" stroke="#2a2d37" strokeWidth="4" fill="none" />
        <rect x="60" y="138" width="64" height="12" rx="3" fill="#20232c" />
        <text x="104" y="25" className="art__err" fontFamily="JetBrains Mono, monospace" fontSize="11" fill="#FF4D5E">
          ERR 0xB00
        </text>
      </svg>
    );
  if (id === 'network')
    return (
      <svg className="art art--network" viewBox="0 0 320 180" aria-hidden="true">
        <defs>
          <radialGradient id="nw-glow" cx="50%" cy="50%" r="60%">
            <stop offset="0" stopColor="#8E5CFF" stopOpacity=".35" />
            <stop offset="1" stopColor="#8E5CFF" stopOpacity="0" />
          </radialGradient>
        </defs>
        <rect width="320" height="180" fill="url(#nw-glow)" />
        <g stroke="#3a2f5c" strokeWidth="2">
          <line x1="50" y1="120" x2="120" y2="60" />
          <line x1="120" y1="60" x2="200" y2="110" />
          <line x1="200" y1="110" x2="270" y2="50" />
          <line x1="120" y1="60" x2="200" y2="30" />
          <line x1="50" y1="120" x2="200" y2="110" />
        </g>
        <g className="art__packets" stroke="#B07CFF" strokeWidth="3" fill="none" strokeLinecap="round">
          <path d="M50 120 L120 60 L200 110 L270 50" pathLength="100" />
        </g>
        <path className="art__broken" d="M200 30 L232 18" stroke="#FF4D5E" strokeWidth="2" strokeDasharray="4 5" />
        {[
          [50, 120],
          [120, 60],
          [200, 110],
          [270, 50],
          [200, 30],
        ].map(([x, y], i) => (
          <g key={i}>
            <circle cx={x} cy={y} r="13" fill="#151225" stroke="#B07CFF" strokeWidth="2" />
            <circle className="art__led" style={{ animationDelay: `${i * 0.4}s` }} cx={x} cy={y} r="4" fill="#B07CFF" />
          </g>
        ))}
        <text x="214" y="150" fontFamily="JetBrains Mono, monospace" fontSize="11" fill="#8a7fb0">
          192.168.10.0/24
        </text>
      </svg>
    );
  return (
    <svg className="art art--code" viewBox="0 0 320 180" aria-hidden="true">
      <defs>
        <radialGradient id="cd-glow" cx="50%" cy="50%" r="60%">
          <stop offset="0" stopColor="#39FF88" stopOpacity=".22" />
          <stop offset="1" stopColor="#39FF88" stopOpacity="0" />
        </radialGradient>
      </defs>
      <rect width="320" height="180" fill="url(#cd-glow)" />
      <rect x="40" y="22" width="240" height="136" rx="10" fill="#0d1210" stroke="#1f3a2b" strokeWidth="2" />
      <circle cx="58" cy="38" r="4" fill="#FF4D5E" />
      <circle cx="72" cy="38" r="4" fill="#FFB347" />
      <circle cx="86" cy="38" r="4" fill="#39FF88" />
      <g className="art__lines">
        {[
          [60, 60, 120, '#5c7a6a'],
          [60, 76, 160, '#39FF88'],
          [76, 92, 110, '#FF6B1A'],
          [76, 108, 140, '#39FF88'],
          [60, 124, 90, '#5c7a6a'],
          [60, 140, 150, '#B07CFF'],
        ].map(([x, y, w, c], i) => (
          <rect key={i} x={x as number} y={(y as number) - 5} width={w as number} height="7" rx="3" fill={c as string} opacity=".75" style={{ animationDelay: `${i * 0.2}s` }} />
        ))}
      </g>
      <rect className="art__cursor" x="214" y="135" width="8" height="12" fill="#39FF88" />
      <text className="art__brace" x="236" y="104" fontFamily="JetBrains Mono, monospace" fontSize="40" fill="#39FF88">
        {'}'}
      </text>
    </svg>
  );
}

/** Round vault door. Bolts light up per cleared room. */
export function VaultArt({ bolts, open }: { bolts: boolean[]; open: boolean }) {
  return (
    <svg className={`vaultart ${open ? 'vaultart--open' : ''}`} viewBox="0 0 220 220" aria-hidden="true">
      <circle cx="110" cy="110" r="104" fill="#0e0f14" stroke="#262934" strokeWidth="4" />
      <circle cx="110" cy="110" r="88" fill="#12141b" stroke="#2f3340" strokeWidth="2" />
      <g className="vaultart__ring">
        {Array.from({ length: 24 }).map((_, i) => (
          <line
            key={i}
            x1="110"
            y1="30"
            x2="110"
            y2={i % 2 ? 38 : 44}
            stroke="#3a3f4e"
            strokeWidth="2"
            transform={`rotate(${i * 15} 110 110)`}
          />
        ))}
      </g>
      {bolts.map((on, i) => (
        <g key={i} transform={`rotate(${i * 120 - 90} 110 110)`}>
          <rect x="176" y="102" width="26" height="16" rx="4" className={`vaultart__bolt ${on ? 'is-on' : ''}`} />
        </g>
      ))}
      <g className="vaultart__dial">
        <circle cx="110" cy="110" r="40" fill="#181b24" stroke="#3a3f4e" strokeWidth="3" />
        {[0, 60, 120, 180, 240, 300].map((a) => (
          <rect key={a} x="106" y="62" width="8" height="18" rx="3" fill="#2b2f3b" transform={`rotate(${a} 110 110)`} />
        ))}
        <circle cx="110" cy="110" r="14" className="vaultart__core" />
      </g>
    </svg>
  );
}
