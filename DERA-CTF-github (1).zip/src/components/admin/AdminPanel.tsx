import { useCallback, useEffect, useMemo, useState } from 'react';
import {
  ShieldCheck, BookOpen, LogOut, RefreshCw, Lock, Unlock, Users, UserRound, Flag, Trophy, Activity, Swords, Crown, ChevronDown, Loader2, Trash2, KeyRound, CheckCircle2, XCircle, Lightbulb, DoorOpen, TriangleAlert, Database,
} from 'lucide-react';
import { useStore } from '../../state/store';
import { accounts, type AdminTeam, type LogEvent, type Solution, type Settings } from '../../engine/accounts';
import { setAdmin, useAdmin, useSettings } from '../../state/auth';
import { board } from '../../engine/board';
import { CHALLENGES, FINAL_CHALLENGE } from '../../data/challenges';
import { TRAINING, TRAIN_MAX, SECTIONS } from '../../data/training';
import { ROOMS } from '../../data/rooms';
import { BootShell } from '../boot/BootShell';
import { AuthPage } from '../boot/AuthPage';
import { Avatar, SPECS, specById } from '../Avatar';
import type { Challenge, L10n } from '../../engine/types';

// ── helpers ──────────────────────────────────────────────────────────────────
const COMP = [...CHALLENGES, FINAL_CHALLENGE];
const COMP_MAX = COMP.reduce((n, c) => n + c.basePoints, 0);
const trackOf = (c: Challenge) => ROOMS.find((r) => r.challengeIds.includes(c.id));
const fmtTime = (t?: number) => (t ? new Date(t).toLocaleString('en-GB', { day: '2-digit', month: '2-digit', hour: '2-digit', minute: '2-digit', second: '2-digit' }) : '—');
const fmtDur = (ms?: number) => {
  if (!ms || ms < 0) return '—';
  const s = Math.round(ms / 1000);
  return s >= 3600 ? `${Math.floor(s / 3600)}h ${Math.floor((s % 3600) / 60)}m` : `${Math.floor(s / 60)}:${String(s % 60).padStart(2, '0')}`;
};

/** Finds the human label of an option / target id anywhere inside a challenge definition. */
function findLabel(obj: unknown, id: string, depth = 0): L10n | null {
  if (!obj || typeof obj !== 'object' || depth > 7) return null;
  if (Array.isArray(obj)) {
    for (const x of obj) {
      const r = findLabel(x, id, depth + 1);
      if (r) return r;
    }
    return null;
  }
  const o = obj as Record<string, unknown>;
  if (o.id === id) {
    const l = (o.label ?? o.title ?? o.text) as L10n | undefined;
    if (l && typeof l === 'object' && 'ar' in l) return l;
  }
  for (const v of Object.values(o)) {
    const r = findLabel(v, id, depth + 1);
    if (r) return r;
  }
  return null;
}

function describeAnswer(cid: string, raw: string | undefined, lang: 'ar' | 'en') {
  if (!raw) return '';
  const c = COMP.find((x) => x.id === cid) ?? TRAINING.find((x) => x.id === cid);
  if (!c) return raw;
  const parts = raw.split(',').map((tok) => {
    const l = findLabel(c, tok.trim());
    return l ? l[lang] : tok;
  });
  return parts.join(' ← ');
}

interface TeamCalc {
  t: AdminTeam;
  compScore: number;
  compSolved: number;
  finalSolved: boolean;
  trainScore: number;
  trainSolved: number;
  pct: number;
  level: number;
  lastActive: number;
  hints: number;
  wrong: number;
  /** Last competition solve time — the tie-breaker, like the public leaderboard. */
  lastSolve: number;
}

const LEVELS: L10n[] = [
  { ar: 'لم يبدأ', en: 'Not started' },
  { ar: 'مبتدئ', en: 'Beginner' },
  { ar: 'متوسط', en: 'Intermediate' },
  { ar: 'متقدّم', en: 'Advanced' },
  { ar: 'خبير', en: 'Expert' },
];

function calc(t: AdminTeam): TeamCalc {
  const prog = t.saved?.session?.progress ?? {};
  const tr = t.saved?.training?.solved ?? {};
  const compScore = COMP.reduce((n, c) => n + (prog[c.id]?.points ?? 0), 0);
  const compSolved = CHALLENGES.filter((c) => prog[c.id]?.solved).length;
  const trainScore = TRAINING.reduce((n, c) => n + (tr[c.id] ? c.points : 0), 0);
  const trainSolved = TRAINING.filter((c) => tr[c.id]).length;
  const pct = Math.round(((trainScore / TRAIN_MAX) * 0.4 + (compScore / COMP_MAX) * 0.6) * 100);
  const level = pct === 0 && !t.events.length ? 0 : pct < 25 ? 1 : pct < 55 ? 2 : pct < 85 ? 3 : 4;
  const lastActive = Math.max(t.saved?.updatedAt ?? 0, ...t.events.map((e) => e.t), t.profile.createdAt);
  const hints = Object.values(prog).reduce((n, p) => n + (p.hintsUsed ?? 0), 0);
  const wrong = Object.values(prog).reduce((n, p) => n + (p.wrong ?? 0), 0);
  const lastSolve = Math.max(0, ...Object.values(prog).map((p) => (p.solved ? p.solvedAt ?? 0 : 0))) || Number.MAX_SAFE_INTEGER;
  return { t, lastSolve, compScore, compSolved, finalSolved: !!prog[FINAL_CHALLENGE.id]?.solved, trainScore, trainSolved, pct, level, lastActive, hints, wrong };
}

/** When a team solved a challenge (competition progress or training map). */
function solvedAt(t: AdminTeam, cid: string): number | undefined {
  const p = t.saved?.session?.progress?.[cid];
  if (p?.solved) return p.solvedAt;
  const tr = t.saved?.training?.solved?.[cid];
  return tr || undefined;
}

// ── dashboard ────────────────────────────────────────────────────────────────
type Tab = 'solutions' | 'teams' | 'challenges' | 'members' | 'activity';

export function AdminPanel() {
  const admin = useAdmin();
  return admin ? <Dashboard /> : <AuthPage mode="login" />;
}

function Dashboard() {
  const { t, prefs } = useStore();
  const settings = useSettings();
  const [data, setData] = useState<{ teams: AdminTeam[]; solutions: Record<string, Solution> } | null>(null);
  const [mode, setMode] = useState('');
  const [loading, setLoading] = useState(false);
  const [err, setErr] = useState(false);
  const [tab, setTab] = useState<Tab>('solutions');
  const [sel, setSel] = useState<string | null>(null);

  const load = useCallback(async () => {
    setLoading(true);
    try {
      const a = await accounts();
      setMode(a.mode);
      setData(await a.overview());
      setErr(false);
    } catch {
      setErr(true);
    } finally {
      setLoading(false);
    }
  }, []);

  useEffect(() => {
    void load();
    const id = setInterval(() => void load(), 15000);
    return () => clearInterval(id);
  }, [load]);

  const teams = useMemo(() => (data?.teams ?? []).map(calc).sort((a, b) => b.compScore - a.compScore || a.lastSolve - b.lastSolve || b.trainScore - a.trainScore || a.t.profile.createdAt - b.t.profile.createdAt), [data]);
  const members = teams.flatMap((c) => c.t.profile.members.map((m) => ({ ...m, team: c.t.profile })));
  const totalSolves = teams.reduce((n, c) => n + c.compSolved + (c.finalSolved ? 1 : 0) + c.trainSolved, 0);

  const toggle = async (patch: Partial<Settings>) => {
    const a = await accounts();
    const opening = patch.competitionOpen === true && !settings.competitionOpen;
    await a.setSettings({ competitionOpen: settings.competitionOpen, vaultOpen: settings.vaultOpen, openedAt: opening ? Date.now() : (settings.openedAt ?? 0), updatedAt: Date.now(), ...patch });
  };

  const selected = teams.find((c) => c.t.profile.id === sel) ?? null;

  return (
    <BootShell tab="admin">
      <section className="adm">
        <header className="adm__head">
          <div>
            <span className="chip chip--ink mono" dir="ltr">
              ADMIN · DERA CTF
            </span>
            <h1>{t({ ar: 'لوحة المشرفة', en: 'Admin dashboard' })}</h1>
            <p className="adm__mode">
              <Database size={14} aria-hidden="true" />{' '}
              {mode === 'supabase'
                ? t({ ar: 'قاعدة البيانات المشتركة (Supabase) — مباشرة لكل الأجهزة', en: 'Shared database (Supabase)' })
                : mode === 'shared'
                ? t({ ar: 'قاعدة البيانات المشتركة (حسابات وسجلات خاصة بالمشرفة فقط)', en: 'Shared database (accounts & logs visible to the admin only)' })
                : mode === 'server'
                  ? t({ ar: 'خادم المسابقة', en: 'Competition server' })
                  : t({ ar: 'هذا الجهاز فقط (تجريبي)', en: 'This device only (demo)' })}
            </p>
          </div>
          <div className="adm__headbtns">
            <button type="button" className="btn2 btn2--ghost" onClick={() => void load()} disabled={loading}>
              <RefreshCw size={16} className={loading ? 'spin' : ''} aria-hidden="true" /> {t({ ar: 'تحديث', en: 'Refresh' })}
            </button>
            <button
              type="button"
              className="btn2 btn2--ghost"
              onClick={() => {
                setAdmin(false);
                window.location.hash = '#/home';
              }}
            >
              <LogOut size={16} aria-hidden="true" /> {t({ ar: 'خروج', en: 'Sign out' })}
            </button>
          </div>
        </header>

        {err && (
          <p className="reg__warn" role="alert">
            <TriangleAlert size={18} aria-hidden="true" /> {t({ ar: 'تعذّر تحميل البيانات. افتحي اللوحة من حسابك (المالكة) أو من خادم المسابقة.', en: 'Could not load data. Open the dashboard as the owner or on the competition server.' })}
          </p>
        )}

        {/* controls */}
        <div className="adm__controls">
          <LockSwitch
            on={settings.competitionOpen}
            icon={<Swords size={20} aria-hidden="true" />}
            title={t({ ar: 'المسابقة النهائية', en: 'Final competition' })}
            text={settings.competitionOpen ? t({ ar: 'مفتوحة للفرق', en: 'Open to teams' }) : t({ ar: 'مقفلة — أنتِ فقط تقدرين تدخلين', en: 'Locked — only you can enter' })}
            onChange={(v) => void toggle({ competitionOpen: v })}
          />
          <LockSwitch
            on={settings.vaultOpen}
            icon={<DoorOpen size={20} aria-hidden="true" />}
            title={t({ ar: 'التحدي النهائي (القبو الأخير)', en: 'Final challenge (vault)' })}
            text={settings.vaultOpen ? t({ ar: 'مفتوح', en: 'Open' }) : t({ ar: 'مقفل — أنتِ فقط', en: 'Locked — only you' })}
            onChange={(v) => void toggle({ vaultOpen: v })}
          />
          <ResetAll onDone={load} />
          <a className="adm__test" href="#/intro">
            <ShieldCheck size={18} aria-hidden="true" /> {t({ ar: 'دخول تجريبي للمسابقة', en: 'Test the competition' })}
          </a>
        </div>

        <div className="adm__kpis">
          <Kpi icon={<Users size={18} />} n={teams.length} l={t({ ar: 'فريق', en: 'teams' })} />
          <Kpi icon={<UserRound size={18} />} n={members.length} l={t({ ar: 'عضوة', en: 'members' })} />
          <Kpi icon={<Flag size={18} />} n={totalSolves} l={t({ ar: 'تحدي محلول', en: 'solves' })} />
          <Kpi icon={<Trophy size={18} />} n={teams.filter((c) => c.finalSolved).length} l={t({ ar: 'فريق أنهى القبو', en: 'finished' })} />
        </div>

        <div className="ctfb__tabs" role="tablist">
          {(
            [
              ['solutions', BookOpen, { ar: 'حلول التحديات', en: 'Solutions' }],
              ['teams', Users, { ar: 'الفرق', en: 'Teams' }],
              ['challenges', Flag, { ar: 'التحديات والحلول', en: 'Challenges & solutions' }],
              ['members', UserRound, { ar: 'الأعضاء', en: 'Members' }],
              ['activity', Activity, { ar: 'النشاط المباشر', en: 'Live activity' }],
            ] as const
          ).map(([id, Icon, l]) => (
            <button key={id} type="button" role="tab" aria-selected={tab === id} className={tab === id ? 'is-on' : ''} onClick={() => setTab(id)}>
              <Icon size={14} aria-hidden="true" /> {t(l)}
            </button>
          ))}
        </div>

        {!data && loading && (
          <p className="adm__empty">
            <Loader2 size={18} className="spin" aria-hidden="true" /> {t({ ar: 'جاري التحميل…', en: 'Loading…' })}
          </p>
        )}
        {tab === 'solutions' && data && <SolutionsTab solutions={data.solutions} />}

        {data && !teams.length && tab !== 'solutions' && tab !== 'challenges' && <p className="adm__empty">{t({ ar: 'ما فيه فرق مسجّلة للحين.', en: 'No teams registered yet.' })}</p>}

        {tab === 'teams' && teams.length > 0 && (
          <>
            <div className="admtable" role="table">
              <div className="admtable__row admtable__row--head" role="row">
                <span>#</span>
                <span>{t({ ar: 'الفريق', en: 'Team' })}</span>
                <span>{t({ ar: 'الأعضاء', en: 'Members' })}</span>
                <span>{t({ ar: 'التدريب', en: 'Training' })}</span>
                <span>{t({ ar: 'المسابقة', en: 'Competition' })}</span>
                <span>{t({ ar: 'المستوى', en: 'Level' })}</span>
                <span>{t({ ar: 'آخر نشاط', en: 'Last active' })}</span>
              </div>
              {teams.map((c, i) => (
                <button key={c.t.profile.id} type="button" role="row" className={`admtable__row ${sel === c.t.profile.id ? 'is-sel' : ''}`} onClick={() => setSel(sel === c.t.profile.id ? null : c.t.profile.id)}>
                  <span className="mono">{i + 1}</span>
                  <span className="admtable__team">
                    <Avatar id={c.t.profile.avatar} size={30} /> <b dir="auto">{c.t.profile.name}</b>
                  </span>
                  <span>{c.t.profile.members.length}</span>
                  <span className="mono" dir="ltr">
                    {c.trainScore}/{TRAIN_MAX}
                  </span>
                  <span className="mono" dir="ltr">
                    {c.compScore} · {c.compSolved + (c.finalSolved ? 1 : 0)}/{COMP.length}
                  </span>
                  <span>
                    <LevelBadge level={c.level} pct={c.pct} />
                  </span>
                  <span className="mono admtable__dim" dir="ltr">
                    {fmtTime(c.lastActive)}
                  </span>
                </button>
              ))}
            </div>
            {selected && <TeamDetail c={selected} solutions={data!.solutions} onChanged={load} lang={prefs.lang} allTeams={teams} />}
          </>
        )}

        {tab === 'challenges' && data && <ChallengesTab teams={teams} solutions={data!.solutions} lang={prefs.lang} />}
        {tab === 'members' && teams.length > 0 && <MembersTab members={members} />}
        {tab === 'activity' && teams.length > 0 && <ActivityTab teams={teams} lang={prefs.lang} />}
      </section>
    </BootShell>
  );
}

function LockSwitch({ on, icon, title, text, onChange }: { on: boolean; icon: React.ReactNode; title: string; text: string; onChange: (v: boolean) => void }) {
  return (
    <button type="button" role="switch" aria-checked={on} className={`lockswitch ${on ? 'is-on' : ''}`} onClick={() => onChange(!on)}>
      <span className="lockswitch__icon">{icon}</span>
      <span className="lockswitch__text">
        <b>{title}</b>
        <small>{text}</small>
      </span>
      <span className="lockswitch__state">{on ? <Unlock size={16} aria-hidden="true" /> : <Lock size={16} aria-hidden="true" />}</span>
      <span className="lockswitch__sw" aria-hidden="true">
        <i />
      </span>
    </button>
  );
}

function Kpi({ icon, n, l }: { icon: React.ReactNode; n: number; l: string }) {
  return (
    <div className="kpi">
      <span className="kpi__icon" aria-hidden="true">
        {icon}
      </span>
      <b className="mono">{n}</b>
      <small>{l}</small>
    </div>
  );
}

function LevelBadge({ level, pct }: { level: number; pct: number }) {
  const { t } = useStore();
  return (
    <span className={`lvl lvl--${level}`}>
      <span className="lvl__bars" aria-hidden="true">
        {[1, 2, 3, 4].map((i) => (
          <i key={i} className={i <= level ? 'is-on' : ''} />
        ))}
      </span>
      {t(LEVELS[level])} <small className="mono">{pct}%</small>
    </span>
  );
}

// ── team profile ─────────────────────────────────────────────────────────────
function TeamDetail({ c, solutions, onChanged, lang, allTeams }: { c: TeamCalc; solutions: Record<string, Solution>; onChanged: () => void; lang: 'ar' | 'en'; allTeams: TeamCalc[] }) {
  const { t } = useStore();
  const p = c.t.profile;
  const prog = c.t.saved?.session?.progress ?? {};
  const [open, setOpen] = useState<string | null>(null);
  const [confirmDel, setConfirmDel] = useState(false);
  const [newPw, setNewPw] = useState('');
  const [pwMsg, setPwMsg] = useState('');

  const firstBy = (cid: string) => {
    let best: { id: string; at: number } | null = null;
    for (const x of allTeams) {
      const at = solvedAt(x.t, cid);
      if (at && (!best || at < best.at)) best = { id: x.t.profile.id, at };
    }
    return best?.id;
  };

  const evFor = (cid: string) => c.t.events.filter((e) => e.cid === cid);

  const rows = [
    ...COMP.map((ch) => {
      const pr = prog[ch.id];
      return {
        id: ch.id,
        area: 'comp' as const,
        name: `${trackOf(ch) ? t(trackOf(ch)!.name) + ' · ' : ''}${t(ch.title)}`,
        solved: !!pr?.solved,
        pts: pr?.points ?? 0,
        max: ch.basePoints,
        wrong: pr?.wrong ?? 0,
        hints: pr?.hintsUsed ?? 0,
        dur: pr?.solved && pr.openedAt && pr.solvedAt ? pr.solvedAt - pr.openedAt : undefined,
        at: pr?.solvedAt,
        answer: pr?.answers?.length ? pr.answers.map((a) => describeAnswer(ch.id, a, lang)).join(' | ') : '',
        started: !!pr?.openedAt,
      };
    }),
    ...TRAINING.map((ch) => {
      const at = c.t.saved?.training?.solved?.[ch.id];
      const evs = evFor(ch.id);
      const okEv = evs.find((e) => e.ok);
      return {
        id: ch.id,
        area: 'train' as const,
        name: `${SECTIONS.find((s) => s.id === ch.section)?.tag} · ${ch.title}`,
        solved: !!at,
        pts: at ? ch.points : 0,
        max: ch.points,
        wrong: evs.filter((e) => e.kind === 'attempt' && e.ok === false).length,
        hints: 0,
        dur: undefined,
        at: at || undefined,
        answer: okEv ? describeAnswer(ch.id, okEv.answer, lang) : (c.t.saved?.training?.flags?.[ch.id] ?? ''),
        started: evs.length > 0 || !!at,
      };
    }),
  ];

  return (
    <article className="teamdetail">
      <header className="teamdetail__head">
        <Avatar id={p.avatar} size={72} />
        <div>
          <h2 dir="auto">{p.name}</h2>
          <p className="mono admtable__dim" dir="ltr">
            ID {p.id} · {t({ ar: 'سُجّل', en: 'registered' })} {fmtTime(p.createdAt)}
          </p>
          <LevelBadge level={c.level} pct={c.pct} />
        </div>
        <div className="teamdetail__stats">
          <Kpi icon={<Flag size={16} />} n={c.trainScore} l={t({ ar: 'نقاط التدريب', en: 'training pts' })} />
          <Kpi icon={<Swords size={16} />} n={c.compScore} l={t({ ar: 'نقاط المسابقة', en: 'competition pts' })} />
          <Kpi icon={<Lightbulb size={16} />} n={c.hints} l={t({ ar: 'تلميحات', en: 'hints' })} />
          <Kpi icon={<XCircle size={16} />} n={c.wrong} l={t({ ar: 'إجابات خاطئة', en: 'wrong answers' })} />
        </div>
      </header>

      <h3>{t({ ar: 'الملف الشخصي للأعضاء', en: 'Member profiles' })}</h3>
      <ul className="memcards">
        {p.members.map((m, i) => (
          <li key={i}>
            <span className="memcards__n mono">{i + 1}</span>
            <b dir="auto">
              {m.emoji} {m.name}
            </b>
            <span>
              {specById(m.spec).icon} {m.spec === 'other' ? m.specOther : t(specById(m.spec).label)}
            </span>
          </li>
        ))}
      </ul>

      <h3>{t({ ar: 'حل التحديات (اضغطي على التحدي لعرض طريقة الحل)', en: 'Challenge solving (tap a row for the solving path)' })}</h3>
      <div className="soltable">
        <div className="soltable__row soltable__row--head">
          <span>{t({ ar: 'التحدي', en: 'Challenge' })}</span>
          <span>{t({ ar: 'الحالة', en: 'Status' })}</span>
          <span>{t({ ar: 'النقاط', en: 'Points' })}</span>
          <span>{t({ ar: 'خطأ/تلميح', en: 'Wrong/Hints' })}</span>
          <span>{t({ ar: 'المدة', en: 'Time' })}</span>
          <span>{t({ ar: 'إجابة الفريق', en: 'Team answer' })}</span>
        </div>
        {rows.map((r, i) => (
          <div key={r.id} className={`soltable__item ${i === COMP.length ? 'soltable__item--sep' : ''}`}>
            <button type="button" className={`soltable__row ${r.solved ? 'is-solved' : r.started ? 'is-started' : ''}`} onClick={() => setOpen(open === r.id ? null : r.id)} aria-expanded={open === r.id}>
              <span className="soltable__name">
                <ChevronDown size={14} className={open === r.id ? 'is-open' : ''} aria-hidden="true" />
                <small className="mono">{r.area === 'comp' ? 'COMP' : 'TRAIN'}</small> {r.name}
                {r.solved && firstBy(r.id) === p.id && (
                  <span className="firstblood" title={t({ ar: 'أول فريق حلّه', en: 'First to solve' })}>
                    <Crown size={12} aria-hidden="true" /> {t({ ar: 'الأول', en: 'First' })}
                  </span>
                )}
              </span>
              <span>{r.solved ? <CheckCircle2 size={16} className="ok" aria-label="solved" /> : r.started ? t({ ar: 'بدأ', en: 'started' }) : '—'}</span>
              <span className="mono" dir="ltr">
                {r.pts}/{r.max}
              </span>
              <span className="mono" dir="ltr">
                {r.wrong}/{r.hints}
              </span>
              <span className="mono" dir="ltr">
                {fmtDur(r.dur)}
              </span>
              <span className="soltable__ans" dir="auto">
                {r.answer || '—'}
              </span>
            </button>
            {open === r.id && <SolvePath events={evFor(r.id)} cid={r.id} solution={solutions[r.id]} lang={lang} solvedAtTime={r.at} />}
          </div>
        ))}
      </div>

      <div className="teamdetail__actions">
        <form
          className="teamdetail__pw"
          onSubmit={async (e) => {
            e.preventDefault();
            if (newPw.length < 8) return setPwMsg(t({ ar: '8 أحرف على الأقل', en: 'At least 8 characters' }));
            const a = await accounts();
            const ok = await a.resetPassword(p.id, newPw);
            setPwMsg(ok ? t({ ar: 'تم تغيير كلمة المرور ✓', en: 'Password changed ✓' }) : t({ ar: 'تعذّر التغيير', en: 'Failed' }));
            setNewPw('');
          }}
        >
          <KeyRound size={16} aria-hidden="true" />
          <input className="reg__input mono" dir="ltr" placeholder={t({ ar: 'كلمة مرور جديدة للفريق', en: 'New team password' })} value={newPw} onChange={(e) => setNewPw(e.target.value)} aria-label="new password" />
          <button type="submit" className="btn2 btn2--ghost">
            {t({ ar: 'تغيير', en: 'Change' })}
          </button>
          {pwMsg && <small>{pwMsg}</small>}
        </form>
        {confirmDel ? (
          <span className="teamdetail__del">
            {t({ ar: 'حذف الفريق وكل سجلاته نهائيًا؟', en: 'Delete this team and all its records?' })}
            <button
              type="button"
              className="btn2 btn2--pink"
              onClick={async () => {
                const a = await accounts();
                await a.deleteTeam(p.id);
                await board.remove(p.id);
                setConfirmDel(false);
                onChanged();
              }}
            >
              {t({ ar: 'نعم، احذفي', en: 'Yes, delete' })}
            </button>
            <button type="button" className="btn2 btn2--ghost" onClick={() => setConfirmDel(false)}>
              {t({ ar: 'إلغاء', en: 'Cancel' })}
            </button>
          </span>
        ) : (
          <button type="button" className="btn2 btn2--ghost" onClick={() => setConfirmDel(true)}>
            <Trash2 size={16} aria-hidden="true" /> {t({ ar: 'حذف الفريق', en: 'Delete team' })}
          </button>
        )}
      </div>
    </article>
  );
}

const KIND: Record<LogEvent['kind'], L10n> = {
  open: { ar: 'فتح التحدي', en: 'Opened' },
  hint: { ar: 'طلب تلميح', en: 'Hint' },
  attempt: { ar: 'محاولة', en: 'Attempt' },
  solve: { ar: 'حلّ نهائي', en: 'Solved' },
};

function SolvePath({ events, cid, solution, lang, solvedAtTime }: { events: LogEvent[]; cid: string; solution?: Solution; lang: 'ar' | 'en'; solvedAtTime?: number }) {
  const { t } = useStore();
  const ch = COMP.find((x) => x.id === cid);
  const tr = TRAINING.find((x) => x.id === cid);
  return (
    <div className="solpath">
      <div className="solpath__team">
        <b>{t({ ar: 'طريقة حل الفريق (بالترتيب)', en: 'How the team solved it (in order)' })}</b>
        {events.length ? (
          <ol>
            {events.map((e, i) => (
              <li key={i} className={e.ok === true ? 'is-ok' : e.ok === false ? 'is-bad' : ''}>
                <span className="mono" dir="ltr">
                  {fmtTime(e.t)}
                </span>
                <span>
                  {t(KIND[e.kind])}
                  {e.stage !== undefined && ch && ch.stages.length > 1 ? ` · ${t({ ar: 'مرحلة', en: 'stage' })} ${e.stage + 1}` : ''}
                </span>
                {e.answer !== undefined && (
                  <span className="solpath__ans" dir="auto">
                    {e.ok ? <CheckCircle2 size={13} aria-hidden="true" /> : <XCircle size={13} aria-hidden="true" />} {describeAnswer(cid, e.answer, lang)}
                  </span>
                )}
              </li>
            ))}
          </ol>
        ) : (
          <p className="admtable__dim">
            {solvedAtTime ? t({ ar: 'تم الحل قبل تفعيل السجل التفصيلي.', en: 'Solved before detailed logging.' }) : t({ ar: 'ما فيه نشاط مسجّل.', en: 'No recorded activity.' })}
          </p>
        )}
      </div>
      <OfficialSolution cid={cid} solution={solution} challenge={ch} train={tr} />
    </div>
  );
}

function OfficialSolution({ cid, solution, challenge, train }: { cid: string; solution?: Solution; challenge?: Challenge; train?: (typeof TRAINING)[number] }) {
  const { t } = useStore();
  return (
    <div className="solpath__official">
      <b>{t({ ar: 'الحل الرسمي', en: 'Official solution' })}</b>
      {solution ? (
        <>
          <p className="solpath__key" dir="auto">
            {solution.answer}
          </p>
          <ol>
            {solution.steps.map((s, i) => (
              <li key={i}>{s}</li>
            ))}
          </ol>
        </>
      ) : (
        <p className="admtable__dim">{t({ ar: `مفتاح الإجابة موجود في ملفات المنظِّمة (${cid}).`, en: `Answer key is in the organizer files (${cid}).` })}</p>
      )}
      {challenge?.explanation && <p className="solpath__exp">{t(challenge.explanation)}</p>}
      {train && <p className="solpath__exp">{t(train.learn)}</p>}
    </div>
  );
}

// ── challenges ───────────────────────────────────────────────────────────────
function ChallengesTab({ teams, solutions, lang }: { teams: TeamCalc[]; solutions: Record<string, Solution>; lang: 'ar' | 'en' }) {
  const { t } = useStore();
  const [open, setOpen] = useState<string | null>(null);
  const list = [
    ...COMP.map((c) => ({ id: c.id, area: 'COMP', name: `${trackOf(c) ? t(trackOf(c)!.name) + ' · ' : ''}${t(c.title)}`, pts: c.basePoints })),
    ...TRAINING.map((c) => ({ id: c.id, area: 'TRAIN', name: `${SECTIONS.find((s) => s.id === c.section)?.tag} · ${c.title}`, pts: c.points })),
  ];
  return (
    <div className="chlist">
      {list.map((ch) => {
        const solvers = teams
          .map((x) => ({ x, at: solvedAt(x.t, ch.id) }))
          .filter((s) => s.at)
          .sort((a, b) => a.at! - b.at!);
        const tried = teams.filter((x) => x.t.events.some((e) => e.cid === ch.id) || x.t.saved?.session?.progress?.[ch.id]?.openedAt).length;
        const first = solvers[0];
        return (
          <div key={ch.id} className="chlist__item">
            <button type="button" className="chlist__row" onClick={() => setOpen(open === ch.id ? null : ch.id)} aria-expanded={open === ch.id}>
              <ChevronDown size={14} className={open === ch.id ? 'is-open' : ''} aria-hidden="true" />
              <small className="mono">{ch.area}</small>
              <b dir="auto">{ch.name}</b>
              <span className="mono" dir="ltr">
                {ch.pts} pts
              </span>
              <span>
                {t({ ar: 'حلّه', en: 'solved' })} <b className="mono">{solvers.length}</b>/{tried || 0}
              </span>
              <span className="chlist__first">
                {first ? (
                  <>
                    <Crown size={14} aria-hidden="true" /> <Avatar id={first.x.t.profile.avatar} size={22} /> <span dir="auto">{first.x.t.profile.name}</span>
                    <small className="mono" dir="ltr">
                      {fmtTime(first.at)}
                    </small>
                  </>
                ) : (
                  <span className="admtable__dim">{t({ ar: 'ما أحد حلّه بعد', en: 'No solves yet' })}</span>
                )}
              </span>
            </button>
            {open === ch.id && (
              <div className="chlist__body">
                <OfficialSolution cid={ch.id} solution={solutions[ch.id]} challenge={COMP.find((c) => c.id === ch.id)} train={TRAINING.find((c) => c.id === ch.id)} />
                <div className="chlist__solvers">
                  <b>{t({ ar: 'الفرق اللي حلّته (بالترتيب)', en: 'Teams that solved it (in order)' })}</b>
                  {solvers.length ? (
                    <ol>
                      {solvers.map(({ x, at }, i) => {
                        const evs = x.t.events.filter((e) => e.cid === ch.id && e.answer !== undefined);
                        const wrong = evs.filter((e) => !e.ok);
                        const good = evs.filter((e) => e.ok);
                        return (
                          <li key={x.t.profile.id}>
                            <span className="mono">{i + 1}</span>
                            {i === 0 && <Crown size={14} className="crown" aria-hidden="true" />}
                            <Avatar id={x.t.profile.avatar} size={22} /> <b dir="auto">{x.t.profile.name}</b>
                            <small className="mono" dir="ltr">
                              {fmtTime(at)}
                            </small>
                            <span className="chlist__tries">
                              {t({ ar: 'محاولات خاطئة', en: 'wrong' })}: {wrong.length}
                              {wrong.length > 0 && (
                                <em dir="auto">
                                  {' '}
                                  ({wrong
                                    .slice(-4)
                                    .map((e) => describeAnswer(ch.id, e.answer, lang))
                                    .join(' · ')}
                                  )
                                </em>
                              )}
                            </span>
                            {good.length > 0 && (
                              <span className="chlist__good" dir="auto">
                                <CheckCircle2 size={13} aria-hidden="true" /> {good.map((e) => describeAnswer(ch.id, e.answer, lang)).join(' | ')}
                              </span>
                            )}
                          </li>
                        );
                      })}
                    </ol>
                  ) : (
                    <p className="admtable__dim">—</p>
                  )}
                </div>
              </div>
            )}
          </div>
        );
      })}
    </div>
  );
}

// ── members ──────────────────────────────────────────────────────────────────
function MembersTab({ members }: { members: (TeamCalc['t']['profile']['members'][number] & { team: TeamCalc['t']['profile'] })[] }) {
  const { t } = useStore();
  const counts = SPECS.map((s) => ({ s, n: members.filter((m) => m.spec === s.id).length }));
  const max = Math.max(1, ...counts.map((c) => c.n));
  return (
    <div className="memtab">
      <div className="memtab__bars">
        <b>{t({ ar: 'توزيع التخصصات', en: 'Specializations' })}</b>
        {counts.map(({ s, n }) => (
          <div key={s.id} className="memtab__bar">
            <span>
              {s.icon} {t(s.label)}
            </span>
            <span className="memtab__track">
              <i style={{ inlineSize: `${(n / max) * 100}%` }} />
            </span>
            <b className="mono">{n}</b>
          </div>
        ))}
      </div>
      <div className="admtable">
        <div className="admtable__row admtable__row--head admtable__row--3">
          <span>{t({ ar: 'العضوة', en: 'Member' })}</span>
          <span>{t({ ar: 'التخصص', en: 'Specialization' })}</span>
          <span>{t({ ar: 'الفريق', en: 'Team' })}</span>
        </div>
        {members.map((m, i) => (
          <div key={i} className="admtable__row admtable__row--3">
            <b dir="auto">
              {m.emoji} {m.name}
            </b>
            <span>
              {specById(m.spec).icon} {m.spec === 'other' ? m.specOther : t(specById(m.spec).label)}
            </span>
            <span className="admtable__team">
              <Avatar id={m.team.avatar} size={24} /> <span dir="auto">{m.team.name}</span>
            </span>
          </div>
        ))}
      </div>
    </div>
  );
}

// ── activity ─────────────────────────────────────────────────────────────────
function ActivityTab({ teams, lang }: { teams: TeamCalc[]; lang: 'ar' | 'en' }) {
  const { t } = useStore();
  const feed = teams
    .flatMap((x) => x.t.events.map((e) => ({ e, p: x.t.profile })))
    .sort((a, b) => b.e.t - a.e.t)
    .slice(0, 150);
  const nameOf = (cid: string) => {
    const c = COMP.find((x) => x.id === cid);
    if (c) return t(c.title);
    return TRAINING.find((x) => x.id === cid)?.title ?? cid;
  };
  return (
    <ol className="feed">
      {feed.map(({ e, p }, i) => (
        <li key={i} className={e.ok === true ? 'is-ok' : e.ok === false ? 'is-bad' : ''}>
          <span className="mono" dir="ltr">
            {fmtTime(e.t)}
          </span>
          <span className="admtable__team">
            <Avatar id={p.avatar} size={22} /> <b dir="auto">{p.name}</b>
          </span>
          <span>
            {t(KIND[e.kind])} · <small className="mono">{e.area === 'comp' ? 'COMP' : 'TRAIN'}</small> {nameOf(e.cid)}
          </span>
          {e.answer !== undefined && (
            <span className="solpath__ans" dir="auto">
              {e.ok ? <CheckCircle2 size={13} aria-hidden="true" /> : <XCircle size={13} aria-hidden="true" />} {describeAnswer(e.cid, e.answer, lang)}
            </span>
          )}
        </li>
      ))}
      {!feed.length && <p className="adm__empty">{t({ ar: 'ما فيه نشاط للحين.', en: 'No activity yet.' })}</p>}
    </ol>
  );
}

// ── all official solutions ───────────────────────────────────────────────────
function SolutionsTab({ solutions }: { solutions: Record<string, Solution> }) {
  const { t } = useStore();
  const [q, setQ] = useState('');
  const missing = !Object.keys(solutions).length;
  const groups: { title: string; items: { id: string; name: string; pts: number; challenge?: Challenge; train?: (typeof TRAINING)[number] }[] }[] = [
    ...ROOMS.map((r) => ({
      title: `${t({ ar: 'المسابقة النهائية', en: 'Final competition' })} · ${t(r.name)}`,
      items: r.challengeIds.map((id) => COMP.find((c) => c.id === id)!).map((c) => ({ id: c.id, name: t(c.title), pts: c.basePoints, challenge: c })),
    })),
    { title: `${t({ ar: 'المسابقة النهائية', en: 'Final competition' })} · ${t({ ar: 'التحدي النهائي', en: 'Final challenge' })}`, items: [{ id: FINAL_CHALLENGE.id, name: t(FINAL_CHALLENGE.title), pts: FINAL_CHALLENGE.basePoints, challenge: FINAL_CHALLENGE }] },
    ...SECTIONS.map((sec) => ({
      title: `${t({ ar: 'المعسكر التدريبي', en: 'Training camp' })} · ${sec.tag}`,
      items: TRAINING.filter((c) => c.section === sec.id).map((c) => ({ id: c.id, name: c.title, pts: c.points, train: c })),
    })),
  ];
  const match = (x: { id: string; name: string }) => !q.trim() || `${x.name} ${x.id} ${solutions[x.id]?.answer ?? ''}`.toLowerCase().includes(q.trim().toLowerCase());
  return (
    <div className="soltab">
      <p className="soltab__note">
        <BookOpen size={16} aria-hidden="true" />{' '}
        {t({ ar: 'الحل الرسمي لكل تحدي: الإجابة الصحيحة وخطوات الحل والشرح. هذي الصفحة تظهر لحسابك فقط.', en: 'The official answer, steps and explanation for every challenge. Visible to your account only.' })}
      </p>
      {missing && (
        <p className="reg__warn">
          <TriangleAlert size={18} aria-hidden="true" /> {t({ ar: 'الحلول ما وصلت لهذا الجهاز. افتحي اللوحة من حسابك على الرابط المنشور أو من خادم المسابقة.', en: 'Solutions are not available on this device. Open the dashboard from your account or the competition server.' })}
        </p>
      )}
      <input className="reg__input soltab__search" dir="auto" placeholder={t({ ar: 'ابحثي عن تحدي…', en: 'Search a challenge…' })} value={q} onChange={(e) => setQ(e.target.value)} aria-label="search" />
      {groups.map((g) => {
        const items = g.items.filter(match);
        if (!items.length) return null;
        return (
          <section key={g.title} className="soltab__group">
            <h3>{g.title}</h3>
            <div className="soltab__grid">
              {items.map((it) => (
                <article key={it.id} className="soltab__card">
                  <header>
                    <b dir="auto">{it.name}</b>
                    <span className="mono" dir="ltr">
                      {it.pts} pts
                    </span>
                  </header>
                  {it.challenge && <p className="soltab__desc">{t(it.challenge.description)}</p>}
                  {it.train && <p className="soltab__desc">{t(it.train.mission)}</p>}
                  <OfficialSolution cid={it.id} solution={solutions[it.id]} challenge={it.challenge} train={it.train} />
                </article>
              ))}
            </div>
          </section>
        );
      })}
    </div>
  );
}

/** Wipes all teams (accounts, logs and leaderboard) — for a clean start before the event. */
function ResetAll({ onDone }: { onDone: () => void }) {
  const { t } = useStore();
  const [step, setStep] = useState(0);
  const [busy, setBusy] = useState(false);
  if (step === 0)
    return (
      <button type="button" className="adm__reset" onClick={() => setStep(1)}>
        <Trash2 size={16} aria-hidden="true" /> {t({ ar: 'تصفير لوحة الترتيب', en: 'Reset leaderboard' })}
      </button>
    );
  return (
    <div className="adm__reset adm__reset--confirm" role="alert">
      <span>{t({ ar: 'يمسح كل الفرق وحساباتهم ونقاطهم نهائيًا. متأكدة؟', en: 'Deletes every team, account and score. Sure?' })}</span>
      <button
        type="button"
        className="btn2 btn2--pink"
        disabled={busy}
        onClick={async () => {
          setBusy(true);
          const a = await accounts();
          await a.resetAll();
          for (const tm of board.current()) await board.remove(tm.id);
          setBusy(false);
          setStep(0);
          onDone();
        }}
      >
        {t({ ar: 'نعم، صفّري', en: 'Yes, reset' })}
      </button>
      <button type="button" className="btn2 btn2--ghost" onClick={() => setStep(0)}>
        {t({ ar: 'إلغاء', en: 'Cancel' })}
      </button>
    </div>
  );
}
