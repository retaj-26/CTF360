import { useEffect, useState } from 'react';
import { ShieldCheck, Eye, EyeOff, Loader2 } from 'lucide-react';
import { useStore } from '../../state/store';
import { accounts, type Solution } from '../../engine/accounts';
import type { Challenge } from '../../engine/types';

/**
 * Admin-only box inside a competition challenge: the correct answer and how to solve it.
 * Teams never see this; the solution itself is read from the admin-only store.
 */
export function AdminAnswer({ challenge }: { challenge: Challenge }) {
  const { t } = useStore();
  const [sol, setSol] = useState<Solution | null | undefined>(undefined);
  const [open, setOpen] = useState(true);

  useEffect(() => {
    let live = true;
    setSol(undefined);
    void accounts()
      .then((a) => a.getSolution(challenge.id))
      .then((s) => live && setSol(s));
    return () => {
      live = false;
    };
  }, [challenge.id]);

  return (
    <aside className="adminans" aria-label={t({ ar: 'للمشرفة فقط', en: 'Admin only' })}>
      <button type="button" className="adminans__head" onClick={() => setOpen((v) => !v)} aria-expanded={open}>
        <ShieldCheck size={18} aria-hidden="true" />
        <b>{t({ ar: 'للمشرفة فقط — الإجابة وطريقة الحل', en: 'Admin only — answer & solution' })}</b>
        {open ? <EyeOff size={16} aria-hidden="true" /> : <Eye size={16} aria-hidden="true" />}
      </button>
      {open && (
        <div className="adminans__body">
          {sol === undefined ? (
            <p>
              <Loader2 size={16} className="spin" aria-hidden="true" /> {t({ ar: 'جاري التحميل…', en: 'Loading…' })}
            </p>
          ) : sol ? (
            <>
              <p className="adminans__key" dir="auto">
                {sol.answer}
              </p>
              <ol>
                {sol.steps.map((st, i) => (
                  <li key={i}>{st}</li>
                ))}
              </ol>
            </>
          ) : (
            <p>{t({ ar: 'الحل ما وصل لهذا الجهاز. افتحي من حسابك على الرابط المنشور أو من خادم المسابقة.', en: 'Solution unavailable on this device.' })}</p>
          )}
          <p className="adminans__exp">
            <b>{t({ ar: 'الشرح:', en: 'Explanation:' })}</b> {t(challenge.explanation)}
          </p>
        </div>
      )}
    </aside>
  );
}
