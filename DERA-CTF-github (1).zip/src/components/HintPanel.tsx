import { logEvent } from '../state/auth';
import { FileSearch, Lightbulb } from 'lucide-react';
import { useStore } from '../state/store';
import { UI } from '../data/ui';
import { play } from '../audio/sound';
import type { Challenge } from '../engine/types';
import { pointsFor } from '../engine/scoring';

export function HintPanel({ challenge, overTime }: { challenge: Challenge; overTime: boolean }) {
  const { t, progressOf, dispatch } = useStore();
  const p = progressOf(challenge.id);
  const free = challenge.difficulty === 'intro';
  const worth = p.solved ? p.points : pointsFor(challenge.basePoints, p.hintsUsed, overTime, free);
  const canHint = !p.solved && p.hintsUsed < 2;

  return (
    <aside className="hints" aria-label={t(UI.hint)}>
      <div className="hints__worth">
        <span>{p.solved ? t(UI.solvedBadge) : t(UI.worth)}</span>
        <b className="mono" dir="ltr">
          {worth}
          <small>/{challenge.basePoints}</small>
        </b>
      </div>
      <ol className="hints__files">
        {challenge.hints.map((h, i) => {
          const shown = i < p.hintsUsed || p.solved;
          return (
            <li key={i} className={`evfile ${shown ? 'is-open' : ''}`}>
              <div className="evfile__tab mono" dir="ltr">
                <FileSearch size={14} aria-hidden="true" /> CASE-{challenge.id.toUpperCase()}-{i + 1}
              </div>
              {shown ? (
                <p className="evfile__text">{t(h)}</p>
              ) : (
                <p className="evfile__sealed" aria-hidden="true">
                  ███████ ████ ██████ ███
                  <br />
                  ████ ███████ ██
                </p>
              )}
            </li>
          );
        })}
      </ol>
      <button
        type="button"
        className="btn btn--hint"
        disabled={!canHint}
        onClick={() => {
          play('hint');
          logEvent({ area: 'comp', cid: challenge.id, kind: 'hint' });
          dispatch({ type: 'hint', id: challenge.id });
        }}
      >
        <Lightbulb size={18} aria-hidden="true" />
        {canHint ? (
          <>
            {t(UI.hint)} {p.hintsUsed + 1}/2 <small>{free ? t({ ar: 'مجاني 🎁', en: 'free' }) : t(UI.hintCost)}</small>
          </>
        ) : p.solved ? (
          t(UI.solvedBadge)
        ) : (
          t(UI.hintsExhausted)
        )}
      </button>
    </aside>
  );
}
