import { useState } from 'react';
import { RotateCcw, UserRoundPlus, Trophy, Flag } from 'lucide-react';
import { useStore, stats } from '../state/store';
import { UI } from '../data/ui';
import { Wordmark } from './Brand';
import { SettingsMenu } from './Controls';
import { MusicPlayer } from './MusicPlayer';
import { SessionResetDialog } from './SessionResetDialog';

export function AppHeader() {
  const { t, session, prefs } = useStore();
  const st = stats(session);
  const [resetOpen, setResetOpen] = useState(false);
  return (
    <header className="apphead">
      <a href="#/hub" className="apphead__brand" aria-label="CTF360 — hub">
        <Wordmark size="sm" />
      </a>
      {session && (
        <div className="apphead__agent" aria-live="polite">
          <span className="apphead__dot" />
          <span className="apphead__label">{t(UI.agent)}</span>
          <b dir="auto">{session.codename}</b>
          <span className="apphead__sep" />
          <span className="apphead__label">{t(UI.score)}</span>
          <b className="mono apphead__score" dir="ltr">
            {st.score}
          </b>
        </div>
      )}
      <div className="apphead__ctl">
        <a className="ctl" href="#/home" aria-label={t({ ar: 'المعسكر التدريبي', en: 'Bootcamp' })}>
          <Flag size={18} aria-hidden="true" />
          <span className="ctl__label ctl__label--hide-sm">{t({ ar: 'المعسكر التدريبي', en: 'Bootcamp' })}</span>
        </a>
        <a className="ctl ctl--board" href="#/leaderboard" aria-label={t(UI.leaderboard)}>
          <Trophy size={18} aria-hidden="true" />
          <span className="ctl__label ctl__label--hide-sm">{t(UI.leaderboard)}</span>
        </a>
        <MusicPlayer />
        <SettingsMenu />
        {session && (
          <button
            type="button"
            className={`ctl ${prefs.exhibition ? 'ctl--danger ctl--wide' : ''}`}
            onClick={() => setResetOpen(true)}
            aria-label={prefs.exhibition ? t(UI.nextVisitor) : t(UI.reset)}
          >
            {prefs.exhibition ? <UserRoundPlus size={18} aria-hidden="true" /> : <RotateCcw size={18} aria-hidden="true" />}
            <span className={prefs.exhibition ? '' : 'ctl__label ctl__label--hide-sm'}>
              {prefs.exhibition ? t(UI.nextVisitor) : t(UI.reset)}
            </span>
          </button>
        )}
      </div>
      <SessionResetDialog open={resetOpen} onClose={() => setResetOpen(false)} />
    </header>
  );
}
