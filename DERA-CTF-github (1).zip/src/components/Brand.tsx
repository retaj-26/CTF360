import { useStore } from '../state/store';
import { UI } from '../data/ui';

/** Typographic CTF360 identity (platform name). Partner marks are never redrawn — see PartnerStrip. */
export function Wordmark({ size = 'md' }: { size?: 'xs' | 'sm' | 'md' | 'lg' | 'xl' }) {
  return (
    <span className={`wordmark wordmark--${size}`} aria-label="CTF360" dir="ltr">
      <span className="wordmark__ctf">CTF</span>
      <span className="wordmark__360">
        <svg className="wordmark__ring" viewBox="0 0 100 100" preserveAspectRatio="none" aria-hidden="true">
          <circle cx="50" cy="50" r="44" className="wordmark__ring-track" />
          <circle cx="50" cy="50" r="44" className="wordmark__ring-sweep" />
        </svg>
        360
      </span>
    </span>
  );
}

const ASSET = (f: string) => `${import.meta.env.BASE_URL}assets/${f}`;

/**
 * Official partner logos, cropped (not redrawn) from the supplied reference image,
 * shown on a light plate so their original colours stay intact on the dark theme.
 */
export function PartnerStrip({ variant = 'bar', withSlogan = true }: { variant?: 'bar' | 'plate' | 'print'; withSlogan?: boolean }) {
  const { t } = useStore();
  return (
    <div className={`partners partners--${variant}`} role="group" aria-label={t(UI.partners)}>
      <img
        className="partners__logo partners__logo--dera"
        src={ASSET('dera360-logo.png')}
        alt="جمعية درع 360 للأمن السيبراني — Dera 360 Cybersecurity"
        width={436}
        height={157}
      />
      <span className="partners__divider" aria-hidden="true" />
      <span className="partners__collab">
        <img className="partners__with" src={ASSET('in-collaboration-with.png')} alt="بالتعاون مع" width={191} height={58} />
        <img
          className="partners__logo partners__logo--tvtc"
          src={ASSET('tvtc-buraidah-technical-college-logo.png')}
          alt="المؤسسة العامة للتدريب التقني والمهني — الكلية التقنية ببريدة — Technical and Vocational Training Corporation, Technical College in Buraidah"
          width={323}
          height={127}
        />
      </span>
      {withSlogan && (
        <img
          className="partners__logo partners__logo--slogan"
          src={ASSET('la-taftah-majal-branding.png')}
          alt="#لا_تفتح_مجال"
          width={535}
          height={146}
        />
      )}
    </div>
  );
}

/** Decorative pixel-square clusters, like the printed case cards. */
const PIX: [number, number, 'l' | 'v' | 'p'][] = [
  [0, 0, 'l'], [1, 0, 'l'], [0, 1, 'l'], [2, 1, 'v'], [3, 0, 'v'], [1, 2, 'p'], [4, 2, 'l'], [0, 3, 'v'], [2, 3, 'l'], [5, 0, 'p'],
];
export function Pixels({ corner = 'tl', size = 9 }: { corner?: 'tl' | 'tr' | 'bl' | 'br'; size?: number }) {
  const g = size + 3;
  return (
    <svg className={`pixels pixels--${corner}`} width={g * 6} height={g * 4} viewBox={`0 0 ${g * 6} ${g * 4}`} aria-hidden="true">
      {PIX.map(([x, y, c], i) => (
        <rect key={i} x={x * g} y={y * g} width={size} height={size} className={`px px--${c}`} style={{ animationDelay: `${i * 0.37}s` }} />
      ))}
    </svg>
  );
}

/** "CYBER ESCAPE · D360_0X" footer used on every case card. */
export function CardFoot({ code }: { code: string }) {
  return (
    <div className="cardfoot mono" dir="ltr" aria-hidden="true">
      <span>CYBER ESCAPE</span>
      <span>{code}</span>
    </div>
  );
}
