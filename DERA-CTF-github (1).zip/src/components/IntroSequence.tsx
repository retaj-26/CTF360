import { useEffect, useRef, useState } from 'react';
import { ChevronsLeft, ChevronsRight, TriangleAlert, Trophy, Users, UserPlus, Flag, KeyRound, Eye, EyeOff, Loader2, ShieldCheck } from 'lucide-react';
import { useStore } from '../state/store';
import { useTeam, useAdmin } from '../state/auth';
import { signIn, SIGNIN_MSG } from './boot/signin';
import { UI } from '../data/ui';
import { PartnerStrip, Wordmark, Pixels, CardFoot } from './Brand';
import { SettingsMenu } from './Controls';
import { MusicPlayer } from './MusicPlayer';
import { autoStartMusic } from '../audio/music';
import { unlockAudio } from '../audio/engine';
import { navigate } from '../router';
import { play } from '../audio/sound';

type Phase = 'boot' | 'type' | 'scan' | 'warn' | 'name';

/** Types text out character by character (instantly when motion is reduced). */
function Typed({ text, speed = 28, onDone, active = true }: { text: string; speed?: number; onDone?: () => void; active?: boolean }) {
  const { reducedMotion } = useStore();
  const [n, setN] = useState(reducedMotion ? text.length : 0);
  const done = useRef(false);
  useEffect(() => {
    if (!active) return;
    if (reducedMotion) {
      setN(text.length);
      if (!done.current) {
        done.current = true;
        onDone?.();
      }
      return;
    }
    setN(0);
    done.current = false;
    let i = 0;
    const id = setInterval(() => {
      i++;
      setN(i);
      if (i % 2 === 0) play('type');
      if (i >= text.length) {
        clearInterval(id);
        if (!done.current) {
          done.current = true;
          onDone?.();
        }
      }
    }, speed);
    return () => clearInterval(id);
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [text, active, reducedMotion]);
  return (
    <span>
      {text.slice(0, n)}
      {n < text.length && <span className="caret" />}
    </span>
  );
}

function Counter({ to, run }: { to: number; run: boolean }) {
  const [v, setV] = useState(0);
  useEffect(() => {
    if (!run) return;
    let i = 0;
    const id = setInterval(() => {
      i++;
      setV(Math.min(to, i));
      if (i >= to) clearInterval(id);
    }, 900 / to);
    return () => clearInterval(id);
  }, [run, to]);
  return <b className="scan__num">{v}</b>;
}

export function IntroSequence() {
  const { t, prefs, session, dispatch, reducedMotion } = useStore();
  const team = useTeam();
  const [phase, setPhase] = useState<Phase>(reducedMotion ? 'warn' : 'boot');
  const [line, setLine] = useState(reducedMotion ? 3 : 0);
  const [scanPct, setScanPct] = useState(reducedMotion ? 100 : 0);
  const Arrow = prefs.lang === 'ar' ? ChevronsLeft : ChevronsRight;

  useEffect(() => {
    if (phase !== 'boot') return;
    const id = setTimeout(() => setPhase('type'), 1100);
    return () => clearTimeout(id);
  }, [phase]);

  useEffect(() => {
    if (phase !== 'scan') return;
    const start = performance.now();
    const DURATION = 3200;
    let raf = 0;
    const tick = (now: number) => {
      const p = Math.min(1, (now - start) / DURATION);
      setScanPct(Math.round(p * 100));
      if (p < 1) raf = requestAnimationFrame(tick);
      else setTimeout(() => setPhase('warn'), 500);
    };
    raf = requestAnimationFrame(tick);
    return () => cancelAnimationFrame(raf);
  }, [phase]);

  useEffect(() => {
    if (phase === 'warn') play('alarm');
  }, [phase]);

  const skip = () => {
    play('click');
    setLine(3);
    setScanPct(100);
    setPhase('warn');
  };

  const enter = () => {
    autoStartMusic();
    play('crt');
    dispatch({ type: 'pref', patch: { introSeen: true } });
    if (session && (session.adminTest || (team && session.teamId === team.id))) navigate('/hub');
    else setPhase('name');
  };



  const scanning = phase === 'scan' || phase === 'warn' || phase === 'name';
  const showWarn = phase === 'warn' || phase === 'name';

  return (
    <div className={`intro intro--${phase}`}>
      <div className="intro__bar">
        <PartnerStrip variant="bar" />
      </div>

      <div className="intro__controls">
        <a className="ctl" href="#/home">
          <Flag size={18} aria-hidden="true" /> <span className="ctl__label">{t({ ar: 'المعسكر التدريبي', en: 'Bootcamp' })}</span>
        </a>
        <MusicPlayer />
        <SettingsMenu />
      </div>

      <main className="intro__stage">
        {/* Card 1 — the cover card */}
        <section className="cover" aria-label="CTF360">
          <Pixels corner="tr" />
          <Pixels corner="bl" />
          <div className="cover__text">
            <Wordmark size="lg" />
            <h1 className="cover__title">{t({ ar: 'غرفة الهروب السيبرانية', en: 'The Cyber Escape Room' })}</h1>
            <span className="pill">CASE_001</span>
            <p className="cover__tag">{t(UI.tagline)}</p>
            <ul className="cover__verbs">
              {[
                { ar: 'اكتشفي', en: 'Discover' },
                { ar: 'حلّلي', en: 'Analyse' },
                { ar: 'أمّني', en: 'Secure' },
                { ar: 'أنهي الاختراق', en: 'End the breach' },
              ].map((v, i) => (
                <li key={i} style={{ animationDelay: `${0.4 + i * 0.15}s` }}>
                  {t(v)}
                </li>
              ))}
            </ul>
          </div>
          <Hacker />
          <CardFoot code="D360_01" />
        </section>

        {/* Card 2 — the case card */}
        <section className="casecard" aria-live="polite">
          <Pixels corner="tl" />
          <p className="casecard__id mono" dir="ltr">
            CASE_001
          </p>
          <div className="casecard__alert" aria-hidden="true">
            <TriangleAlert size={64} strokeWidth={1.8} />
          </div>
          <div className="term" dir="ltr" lang={prefs.lang}>
            <div className="term__lines" dir={prefs.lang === 'ar' ? 'rtl' : 'ltr'}>
              {phase !== 'boot' && (
                <p className="term__l term__l--division">
                  <Typed text={t(UI.introDivision)} onDone={() => setLine((l) => Math.max(l, 1))} />
                </p>
              )}
              {line >= 1 && (
                <p className="term__l term__l--report">
                  <Typed text={t(UI.introReport)} onDone={() => setLine((l) => Math.max(l, 2))} />
                </p>
              )}
              {line >= 2 && (
                <p className="term__l term__l--alert">
                  <Typed
                    text={t(UI.introAlert)}
                    onDone={() => {
                      setLine((l) => Math.max(l, 3));
                      setTimeout(() => setPhase((p) => (p === 'type' ? 'scan' : p)), 500);
                    }}
                  />
                </p>
              )}
              {phase === 'boot' && <span className="caret" />}
            </div>

            {scanning && (
              <div className="scan" role="status">
                <div className="scan__head">
                  <span>{t(UI.scanning)}</span>
                  <span dir="ltr">{scanPct}%</span>
                </div>
                <div className="scan__bar">
                  <i style={{ inlineSize: `${scanPct}%` }} />
                </div>
                <ul className="scan__found">
                  <li className={scanPct > 25 ? 'is-on' : ''}>
                    <Counter to={3} run={scanPct > 25} /> {t(UI.scanRooms)}
                  </li>
                  <li className={scanPct > 55 ? 'is-on' : ''}>
                    <Counter to={9} run={scanPct > 55} /> {t(UI.scanArtifacts)}
                  </li>
                  <li className={`scan__secret ${scanPct > 85 ? 'is-on' : ''}`}>
                    <Counter to={1} run={scanPct > 85} /> {t(UI.scanSecret)}
                  </li>
                </ul>
              </div>
            )}
          </div>

          {showWarn && (
            <div className="casecard__cta">
              <h2 className="intro__warn">{t(UI.warning)}</h2>
              {phase === 'warn' && (
                <div className="intro__cta">
                  <button type="button" className="btn btn--primary btn--huge" onClick={enter}>
                    {t(UI.enter)} <Arrow size={22} aria-hidden="true" />
                  </button>
                  <div className="intro__cta-row">
                    <a className="btn btn--ghost btn--lg" href="#/leaderboard">
                      <Trophy size={18} aria-hidden="true" /> {t(UI.leaderboard)}
                    </a>
                  </div>
                </div>
              )}

              {phase === 'name' && <TeamLoginForm />}
            </div>
          )}
          <CardFoot code="CTF360" />
        </section>
      </main>

      {!showWarn && (
        <button type="button" className="intro__skip btn btn--ghost" onClick={skip}>
          {t(UI.skip)} <Arrow size={16} aria-hidden="true" />
        </button>
      )}
    </div>
  );
}

/** Halftone hooded figure — drawn in code, no external imagery. */
function Hacker() {
  return (
    <svg className="hacker" viewBox="0 0 300 340" aria-hidden="true">
      <defs>
        <pattern id="halftone" width="6" height="6" patternUnits="userSpaceOnUse">
          <circle cx="3" cy="3" r="1.7" className="hacker__dot" />
        </pattern>
        <linearGradient id="hackerFade" x1="0" y1="0" x2="0" y2="1">
          <stop offset="0" stopColor="#fff" stopOpacity="1" />
          <stop offset=".75" stopColor="#fff" stopOpacity=".8" />
          <stop offset="1" stopColor="#fff" stopOpacity="0" />
        </linearGradient>
        <mask id="hackerMask">
          <rect width="300" height="340" fill="url(#hackerFade)" />
        </mask>
        <radialGradient id="faceGlow" cx="50%" cy="60%" r="60%">
          <stop offset="0" stopColor="#1a1030" />
          <stop offset="1" stopColor="#05030a" />
        </radialGradient>
      </defs>
      <g mask="url(#hackerMask)">
        <path
          d="M150 18 C94 18 60 62 58 122 C56 162 68 192 78 206 L58 240 C36 252 16 276 8 340 L292 340 C284 276 264 252 242 240 L222 206 C232 192 244 162 242 122 C240 62 206 18 150 18 Z"
          fill="url(#halftone)"
        />
        <path d="M150 70 C116 70 100 102 102 142 C104 178 124 204 150 210 C176 204 196 178 198 142 C200 102 184 70 150 70 Z" fill="url(#faceGlow)" />
        <g className="hacker__eyes">
          <rect x="122" y="140" width="16" height="5" rx="1" />
          <rect x="162" y="140" width="16" height="5" rx="1" />
        </g>
      </g>
    </svg>
  );
}

/** Final competition sign-in: team name + password only (accounts are created on #/register). */
function TeamLoginForm() {
  const { t, prefs, dispatch } = useStore();
  const admin = useAdmin();
  const [name, setName] = useState('');
  const [pw, setPw] = useState('');
  const [show, setShow] = useState(false);
  const [busy, setBusy] = useState(false);
  const [err, setErr] = useState<null | 'empty' | 'bad' | 'readonly' | 'error'>(null);
  const Arrow = prefs.lang === 'ar' ? ChevronsLeft : ChevronsRight;

  const submit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (busy) return;
    unlockAudio();
    setBusy(true);
    const r = await signIn(name, pw);
    setBusy(false);
    if (r.kind === 'error') {
      play('wrong');
      return setErr(r.code);
    }
    autoStartMusic();
    play('unlock');
    if (r.kind === 'admin') dispatch({ type: 'start', codename: 'تجربة المشرفة' });
    else dispatch({ type: 'login', team: r.team, saved: r.saved });
    navigate('/hub');
  };

  const MSG = SIGNIN_MSG;

  return (
    <form className="codename teamform" onSubmit={submit} noValidate>
      <h3 className="codename__title">
        <Users size={20} aria-hidden="true" /> {t({ ar: 'تسجيل الدخول', en: 'Sign in' })}
      </h3>
      <p className="codename__help">{t({ ar: 'اسم المستخدم (اسم الفريق) وكلمة المرور.', en: 'Username (team name) and password.' })}</p>
      <label className="teamform__label" htmlFor="login-team">
        {t({ ar: 'اسم المستخدم', en: 'Username' })}
      </label>
      <input
        id="login-team"
        className={`input ${err === 'empty' && !name.trim() ? 'is-invalid' : ''}`}
        dir="auto"
        autoFocus
        maxLength={32}
        autoComplete="username"
        spellCheck={false}
        value={name}
        onChange={(e) => {
          setName(e.target.value);
          setErr(null);
        }}
      />
      <label className="teamform__label" htmlFor="login-pw">
        <KeyRound size={14} aria-hidden="true" /> {t({ ar: 'كلمة المرور', en: 'Password' })}
      </label>
      <div className="codename__row">
        <input
          id="login-pw"
          className={`input mono ${err === 'bad' ? 'is-invalid' : ''}`}
          dir="ltr"
          type={show ? 'text' : 'password'}
          autoComplete="current-password"
          maxLength={64}
          value={pw}
          onChange={(e) => {
            setPw(e.target.value);
            setErr(null);
          }}
        />
        <button type="button" className="btn btn--ghost" onClick={() => setShow((v) => !v)} aria-label={show ? t({ ar: 'إخفاء', en: 'Hide' }) : t({ ar: 'إظهار', en: 'Show' })}>
          {show ? <EyeOff size={18} /> : <Eye size={18} />}
        </button>
      </div>
      {err && (
        <p className="feedback feedback--bad" role="alert">
          {t(MSG[err])}
        </p>
      )}
      <button type="submit" className="btn btn--primary btn--lg" disabled={busy}>
        {busy ? <Loader2 size={20} className="spin" aria-hidden="true" /> : null} {t({ ar: 'دخول', en: 'Sign in' })} <Arrow size={20} aria-hidden="true" />
      </button>
      <a className="btn btn--ghost teamform__add" href="#/register">
        <UserPlus size={16} aria-hidden="true" /> {t({ ar: 'ما عندكم حساب؟ أنشئي حساب الفريق', en: 'No account? Create one' })}
      </a>
      {admin && (
        <button
          type="button"
          className="btn btn--ghost btn--sm"
          onClick={() => {
            dispatch({ type: 'start', codename: 'تجربة المشرفة' });
            navigate('/hub');
          }}
        >
          <ShieldCheck size={16} aria-hidden="true" /> {t({ ar: 'دخول تجريبي كمشرفة (لا يظهر في الترتيب)', en: 'Admin test run (not ranked)' })}
        </button>
      )}
    </form>
  );
}
