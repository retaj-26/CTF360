import { Lock, Flag, Trophy, Loader2 } from 'lucide-react';
import { useStore } from '../state/store';
import { useTeam } from '../state/auth';
import { Avatar } from './Avatar';
import { Pixels, CardFoot } from './Brand';

/** Shown while the organizer keeps the final competition (or the final vault) closed. Opens live. */
export function LockedScreen({ kind, loading }: { kind: 'competition' | 'vault'; loading?: boolean }) {
  const { t } = useStore();
  const team = useTeam();
  return (
    <section className="locked" aria-live="polite">
      <Pixels corner="tr" />
      <div className="locked__icon">{loading ? <Loader2 size={46} className="spin" aria-hidden="true" /> : <Lock size={46} aria-hidden="true" />}</div>
      <p className="locked__code mono" dir="ltr">
        {kind === 'vault' ? 'FINAL_VAULT · LOCKED' : 'FINAL_ROUND · LOCKED'}
      </p>
      <h1>
        {loading
          ? t({ ar: 'جاري التحقق…', en: 'Checking…' })
          : kind === 'vault'
            ? t({ ar: 'التحدي النهائي مقفل', en: 'The final challenge is locked' })
            : t({ ar: 'المسابقة النهائية مقفلة حاليًا', en: 'The final competition is locked' })}
      </h1>
      {!loading && (
        <p>
          {kind === 'vault'
            ? t({ ar: 'خلصتوا المسارات! القبو الأخير يفتح لما تفتحه المشرفة — الصفحة بتتحدّث لحالها.', en: 'Tracks done! The final vault opens when the organizer unlocks it — this page updates by itself.' })
            : t({ ar: 'المشرفة بتفتح المسابقة عند بدايتها. خليكم على هذي الصفحة، بتنفتح تلقائيًا.', en: 'The organizer opens it when the round starts. Stay here — it opens automatically.' })}
        </p>
      )}
      {team && (
        <p className="locked__team">
          <Avatar id={team.avatar} size={32} /> {t({ ar: 'فريقكم جاهز:', en: 'Your team is ready:' })} <b dir="auto">{team.name}</b>
        </p>
      )}
      <div className="locked__btns">
        {kind === 'vault' ? (
          <a className="btn btn--ghost btn--lg" href="#/hub">
            {t({ ar: 'غرفة التحكم', en: 'Control room' })}
          </a>
        ) : (
          <a className="btn btn--ghost btn--lg" href="#/train">
            <Flag size={18} aria-hidden="true" /> {t({ ar: 'تدرّبي بالمعسكر', en: 'Practise in the camp' })}
          </a>
        )}
        <a className="btn btn--ghost btn--lg" href="#/leaderboard">
          <Trophy size={18} aria-hidden="true" /> {t({ ar: 'لوحة الترتيب', en: 'Leaderboard' })}
        </a>
      </div>
      <CardFoot code="LOCKED" />
    </section>
  );
}
