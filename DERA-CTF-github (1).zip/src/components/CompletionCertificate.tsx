import { Printer, ArrowRight, ArrowLeft } from 'lucide-react';
import { useStore, stats } from '../state/store';
import { UI } from '../data/ui';
import { CHALLENGES } from '../data/challenges';
import { PartnerStrip, Wordmark } from './Brand';
import { formatDuration } from './FinalVault';

export function CompletionCertificate() {
  const { t, session, prefs } = useStore();
  if (!session) return null;
  const st = stats(session);
  const Back = prefs.lang === 'ar' ? ArrowRight : ArrowLeft;
  const date = new Date(session.finishedAt ?? Date.now());
  const elapsed = (session.finishedAt ?? Date.now()) - session.startedAt;
  return (
    <div className="certwrap">
      <div className="certwrap__bar no-print">
        <a className="btn btn--ghost" href="#/vault">
          <Back size={16} aria-hidden="true" /> {t(UI.vault)}
        </a>
        <button type="button" className="btn btn--primary" onClick={() => window.print()}>
          <Printer size={18} aria-hidden="true" /> {t(UI.print)}
        </button>
      </div>

      <article className="cert" aria-label={t(UI.certificate)}>
        <div className="cert__frame">
          <PartnerStrip variant="print" withSlogan={false} />
          <div className="cert__center">
          <div className="cert__brand">
            <Wordmark size="md" />
          </div>
          <p className="cert__kicker">{t(UI.certTitle)}</p>
          <p className="cert__lead">{t(UI.certBody)}</p>
          <h1 className="cert__name" dir="auto">
            {session.codename}
          </h1>
          {session.members?.length ? <p className="cert__members">{session.members.join(' · ')}</p> : null}
          <p className="cert__body">{t(UI.certBody2)}</p>
          <dl className="cert__stats">
            <div>
              <dt>{t(UI.score)}</dt>
              <dd dir="ltr">
                {st.score} / {st.maxScore}
              </dd>
            </div>
            <div>
              <dt>{t(UI.challengesDone)}</dt>
              <dd dir="ltr">
                {st.solved + (st.finalSolved ? 1 : 0)} / {CHALLENGES.length + 1}
              </dd>
            </div>
            <div>
              <dt>{t(UI.elapsed)}</dt>
              <dd dir="ltr">{formatDuration(elapsed)}</dd>
            </div>
            <div>
              <dt>{t(UI.certDate)}</dt>
              <dd>{date.toLocaleDateString(prefs.lang === 'ar' ? 'ar-SA-u-ca-gregory-nu-latn' : 'en-GB', { year: 'numeric', month: 'long', day: 'numeric' })}</dd>
            </div>
          </dl>
          </div>
          <div className="cert__foot">
            <img
              className="cert__slogan"
              src={`${import.meta.env.BASE_URL}assets/la-taftah-majal-branding.png`}
              alt="#لا_تفتح_مجال"
              width={535}
              height={146}
            />
            <svg className="cert__seal" viewBox="0 0 100 100" aria-hidden="true">
              <circle cx="50" cy="50" r="46" fill="none" stroke="#6D28D9" strokeWidth="2" />
              <circle cx="50" cy="50" r="38" fill="none" stroke="#6D28D9" strokeWidth="1" strokeDasharray="2 3" />
              <path d="M50 26 l17 7 v13 c0 12 -8 20 -17 24 c-9 -4 -17 -12 -17 -24 v-13 z" fill="#6D28D9" opacity=".12" stroke="#6D28D9" strokeWidth="2" />
              <path d="M42 50 l6 6 l11 -12" fill="none" stroke="#1b1d22" strokeWidth="3.5" strokeLinecap="round" strokeLinejoin="round" />
              <text x="50" y="84" textAnchor="middle" fontSize="8" fontFamily="JetBrains Mono, monospace" fill="#1b1d22" letterSpacing="1">
                VERIFIED
              </text>
            </svg>
            <p className="cert__session mono" dir="ltr">
              {t(UI.certSession)}: {session.id.toUpperCase()} · CTF360 · {date.getFullYear()}
            </p>
          </div>
        </div>
      </article>
    </div>
  );
}
