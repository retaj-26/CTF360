import { useSyncExternalStore } from 'react';
import { Music, Pause, SkipForward, Volume2 } from 'lucide-react';
import { musicState, subscribeMusic, toggleMusic, nextTrack, setVolume } from '../audio/music';

let snap = musicState();
const sub = (f: () => void) =>
  subscribeMusic(() => {
    snap = musicState();
    f();
  });

/** Hackathon music control: play/pause, next track, volume. */
export function MusicPlayer({ compact = false }: { compact?: boolean }) {
  const s = useSyncExternalStore(sub, () => snap);
  return (
    <div className={`musicp ${s.playing ? 'is-on' : ''} ${compact ? 'musicp--compact' : ''}`}>
      <button type="button" className="musicp__play" onClick={toggleMusic} aria-pressed={s.playing} aria-label={s.playing ? 'إيقاف الموسيقى' : 'تشغيل الموسيقى'} title={s.playing ? 'إيقاف الموسيقى' : 'تشغيل الموسيقى'}>
        {s.playing ? <Pause size={16} aria-hidden="true" /> : <Music size={16} aria-hidden="true" />}
        <span className="musicp__eq" aria-hidden="true">
          <i />
          <i />
          <i />
          <i />
        </span>
        {!compact && <span className="musicp__name">{s.playing ? s.trackName : 'شغّلي الحماس 🔥'}</span>}
      </button>
      {s.playing && (
        <>
          <button type="button" className="musicp__btn" onClick={nextTrack} aria-label="الأغنية التالية" title="الأغنية التالية">
            <SkipForward size={15} aria-hidden="true" />
          </button>
          <label className="musicp__vol" title="مستوى الصوت">
            <Volume2 size={15} aria-hidden="true" />
            <input type="range" min={0} max={1} step={0.05} value={s.volume} onChange={(e) => setVolume(Number(e.target.value))} aria-label="مستوى الصوت" />
          </label>
        </>
      )}
    </div>
  );
}
