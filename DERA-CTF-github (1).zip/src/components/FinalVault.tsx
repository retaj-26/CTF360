import { useAdmin } from '../state/auth';
import { AdminAnswer } from './admin/AdminAnswer';
import { useEffect, useMemo, useState } from 'react';
import { Award, CheckCircle2, Delete, Eraser, ListOrdered, RotateCcw, Trophy, XCircle, Home, Timer, ScrollText, KeyRound } from 'lucide-react';
import { useStore, stats } from '../state/store';
import { FINAL_CHALLENGE, CHALLENGES } from '../data/challenges';
import { ROOMS } from '../data/rooms';
import { UI } from '../data/ui';
import type { ChainPayload, TextStage } from '../engine/types';
import { useSubmit } from './challenge/useSubmit';
import { FlagSubmissionChallenge } from './challenge/AnswerWidgets';
import { HintPanel } from './HintPanel';
import { EmergencyLights } from './Atmosphere';
import { SessionResetDialog } from './SessionResetDialog';
import { Pixels, CardFoot } from './Brand';
import { useBoard } from './Leaderboard';
import { play } from '../audio/sound';

export function formatDuration(ms: number) {
  const s = Math.max(0, Math.round(ms / 1000));
  const h = Math.floor(s / 3600);
  const m = Math.floor((s % 3600) / 60);
  const sec = s % 60;
  return h ? `${h}:${String(m).padStart(2, '0')}:${String(sec).padStart(2, '0')}` : `${m}:${String(sec).padStart(2, '0')}`;
}

const RESTORE_STEPS = [
  { ar: 'حظر النطاق org-sa-secure.com وتنبيه الموظفين', en: 'Blocking org-sa-secure.com and alerting staff' },
  { ar: 'إنهاء جلسات جهاز iPhone الدخيل', en: 'Killing the intruder iPhone’s sessions' },
  { ar: 'كلمة مرور جديدة لرزان + تحقق ثنائي', en: 'New password for Razan + 2FA' },
  { ar: 'تغيير ADMIN_KEY ونقله لخزنة الأسرار', en: 'Rotating ADMIN_KEY into a secrets vault' },
  { ar: 'إغلاق المجال… نهائياً', en: 'Closing the door… for good' },
];

function Restoration({ onDone }: { onDone: () => void }) {
  const { t, reducedMotion } = useStore();
  const [n, setN] = useState(reducedMotion ? RESTORE_STEPS.length : 0);
  useEffect(() => {
    if (n >= RESTORE_STEPS.length) {
      const id = setTimeout(onDone, reducedMotion ? 200 : 900);
      return () => clearTimeout(id);
    }
    const id = setTimeout(() => {
      play('click');
      setN((x) => x + 1);
    }, 600);
    return () => clearTimeout(id);
  }, [n, onDone, reducedMotion]);
  return (
    <div className="restoring" role="status" aria-live="polite">
      <div className="restoring__ring" aria-hidden="true" />
      <ul className="restoring__list">
        {RESTORE_STEPS.map((s, i) => (
          <li key={i} className={i < n ? 'is-done' : i === n ? 'is-now' : ''}>
            <span className="mono" dir="ltr">
              {i < n ? '[ OK ]' : i === n ? '[ .. ]' : '[    ]'}
            </span>
            {t(s)}
          </li>
        ))}
      </ul>
    </div>
  );
}

function Laurel({ flip = false }: { flip?: boolean }) {
  // Leaves placed along a quadratic stem, angled with the curve's tangent.
  const P0 = [44, 116], P1 = [6, 70], P2 = [30, 6];
  const at = (t: number) => [0, 1].map((k) => (1 - t) ** 2 * P0[k] + 2 * (1 - t) * t * P1[k] + t * t * P2[k]);
  const tan = (t: number) => [0, 1].map((k) => 2 * (1 - t) * (P1[k] - P0[k]) + 2 * t * (P2[k] - P1[k]));
  const leaves = [0.12, 0.28, 0.44, 0.6, 0.76, 0.92].flatMap((tt) => {
    const [x, y] = at(tt);
    const [dx, dy] = tan(tt);
    const ang = (Math.atan2(dy, dx) * 180) / Math.PI;
    return [
      { x, y, a: ang - 40, o: -1 },
      { x, y, a: ang + 40, o: 1 },
    ];
  });
  return (
    <svg className={`laurel ${flip ? 'laurel--flip' : ''}`} viewBox="0 0 60 120" aria-hidden="true">
      <path d={`M${P0} Q${P1} ${P2}`} fill="none" stroke="currentColor" strokeWidth="2.5" strokeLinecap="round" />
      {leaves.map((l, i) => (
        <ellipse key={i} cx={l.x} cy={l.y} rx="8" ry="3.4" fill="currentColor" transform={`rotate(${l.a} ${l.x} ${l.y}) translate(${7 * l.o * 0} 0) translate(7 0)`} />
      ))}
    </svg>
  );
}

function Restored() {
  const { t, session } = useStore();
  const st = stats(session);
  const { teams } = useBoard();
  const [resetOpen, setResetOpen] = useState(false);
  if (!session) return null;
  const rank = teams.findIndex((x) => x.id === session.id) + 1;
  const elapsed = (session.finishedAt ?? Date.now()) - session.startedAt;
  const flag = (session.progress[FINAL_CHALLENGE.id]?.answers[2] ?? '').replace(/\s+/g, '').toUpperCase();
  return (
    <section className="restored" aria-labelledby="restored-title">
      <div className="restored__card">
        <Pixels corner="tl" />
        <Pixels corner="br" />
        <div className="restored__trophy">
          <Laurel />
          <Trophy size={64} aria-hidden="true" />
          <Laurel flip />
        </div>
        <h1 id="restored-title" className="restored__title">
          {t(UI.solvedCase)}
        </h1>
        <p className="restored__sub">{t(UI.solvedCaseSub)}</p>
        <p className="restored__en mono" dir="ltr">
          SYSTEM RESTORED
        </p>
        <p className="restored__ar" lang="ar" dir="rtl">
          تم استعادة النظام بنجاح
        </p>
        <div className="restored__time">
          <Timer size={20} aria-hidden="true" />
          <span>{t(UI.elapsed)}</span>
          <b className="mono" dir="ltr">
            {formatDuration(elapsed)}
          </b>
        </div>
        {rank > 0 && (
          <a className="restored__rank" href="#/leaderboard">
            <Trophy size={20} aria-hidden="true" /> {t(UI.yourRank)}: <b className="mono">#{rank}</b> {t(UI.of)} <span className="mono">{teams.length}</span>
          </a>
        )}
        <p className="restored__flag mono" dir="ltr">
          {flag} · <bdi dir="rtl">#لا_تفتح_مجال</bdi>
        </p>
        <dl className="restored__stats">
          <div>
            <dt>{t(UI.agent)}</dt>
            <dd dir="auto">{session.codename}</dd>
          </div>
          <div>
            <dt>{t(UI.score)}</dt>
            <dd className="mono" dir="ltr">
              {st.score}/{st.maxScore}
            </dd>
          </div>
          <div>
            <dt>{t(UI.challengesDone)}</dt>
            <dd className="mono" dir="ltr">
              {st.solved + (st.finalSolved ? 1 : 0)}/{CHALLENGES.length + 1}
            </dd>
          </div>
          <div>
            <dt>{t(UI.hintsUsed)}</dt>
            <dd className="mono" dir="ltr">
              {st.hints}
            </dd>
          </div>
        </dl>
        <p className="restored__moral">{t(FINAL_CHALLENGE.cheer ?? FINAL_CHALLENGE.explanation)}</p>
        <p className="restored__aware">{t(UI.awareness)}</p>
        <div className="restored__actions">
          <a className="btn btn--primary btn--lg" href="#/certificate">
            <Award size={18} aria-hidden="true" /> {t(UI.viewCertificate)}
          </a>
          <a className="btn btn--ghost btn--lg" href="#/hub">
            <Home size={18} aria-hidden="true" /> {t(UI.backHub)}
          </a>
          <button type="button" className="btn btn--ghost btn--lg" onClick={() => setResetOpen(true)}>
            <RotateCcw size={18} aria-hidden="true" /> {t(UI.restart)}
          </button>
        </div>
        <CardFoot code="D360_04" />
      </div>
      <SessionResetDialog open={resetOpen} onClose={() => setResetOpen(false)} />
    </section>
  );
}

export function FinalVault() {
  const { t, progressOf, session } = useStore();
  const admin = useAdmin();
  const c = FINAL_CHALLENGE;
  const payload = c.payload as ChainPayload;
  const p = progressOf(c.id);
  const { submit, feedback, wrongIds, busy, cooling, cooldownPct, justSolved } = useSubmit(c);
  const [order, setOrder] = useState<string[]>(() => (p.stage > 1 ? p.answers[1].split(',') : []));
  const [parts, setParts] = useState<string[]>([]);
  const [text, setText] = useState('');
  const [phase, setPhase] = useState<'puzzle' | 'restoring' | 'restored'>(p.solved ? 'restored' : 'puzzle');

  useEffect(() => {
    if (justSolved) {
      play('restore');
      setPhase('restoring');
    }
  }, [justSolved]);

  useEffect(() => {
    if (p.stage === 2 && p.answers[1]) setOrder(p.answers[1].split(','));
  }, [p.stage, p.answers]);

  const chips = useMemo(() => {
    const frs = ROOMS.map((r) => r.fragment);
    return [frs[1], payload.decoys[0], frs[2], payload.decoys[1], frs[0], payload.decoys[2]];
  }, [payload.decoys]);

  if (!session) return null;
  const locked = busy || cooling;
  const logDone = p.stage > 0 || p.solved;
  const orderDone = p.stage > 1 || p.solved;
  const picked = p.answers[0];

  const place = (id: string) => {
    if (orderDone || order.includes(id) || order.length >= payload.steps.length) return;
    play('click');
    setOrder((o) => [...o, id]);
  };
  const compose = (ps: string[]) => `DERA{${ps.join('_')}}`;
  const addChip = (f: string) => {
    play('click');
    const next = [...parts, f];
    setParts(next);
    setText(compose(next));
  };
  const undoChip = () => {
    const next = parts.slice(0, -1);
    setParts(next);
    setText(next.length ? compose(next) : '');
  };

  return (
    <div className={`vaultroom vaultroom--${phase}`}>
      <EmergencyLights restored={phase !== 'puzzle'} />
      {phase === 'restoring' && <Restoration onDone={() => setPhase('restored')} />}
      {phase === 'restored' && <Restored />}
      {phase === 'puzzle' && (
        <div className="vaultroom__grid">
          <div className="vaultroom__main">
            <Pixels corner="tr" />
            <header className="vaultroom__head">
              <p className="kicker mono" dir="ltr">
                D360_04 // FINAL VAULT
              </p>
              <div className="bignum-row">
                <span className="bignum bignum--lime" dir="ltr">
                  04
                </span>
                <div>
                  <p className="clue-label">{t({ ar: 'الدليل الرابع', en: 'Evidence 04' })}</p>
                  <h1>{t(c.title)}</h1>
                </div>
              </div>
              {c.bio && (
                <p className="najdi">
                  <span className="najdi__face" aria-hidden="true">
                    🗣️
                  </span>
                  <span>{t(c.bio)}</span>
                </p>
              )}
              <p className="vaultroom__story">{t(c.description)}</p>
              {admin && <AdminAnswer challenge={c} />}
              <p className="vaultroom__intro">{t(UI.finalIntro)}</p>
            </header>

            {/* Stage 1 — login log */}
            <section className={`vstage ${logDone ? 'is-done' : ''}`}>
              <h2 className="stage__prompt">
                <span className="stage__step mono">1/3</span> <ScrollText size={18} aria-hidden="true" /> {t(c.stages[0].prompt)}
              </h2>
              <div className="loglog" role="table" aria-label={t(UI.loginLog)}>
                <div className="loglog__row loglog__row--head" role="row">
                  <span role="columnheader">{t(UI.colTime)}</span>
                  <span role="columnheader">{t(UI.colAccount)}</span>
                  <span role="columnheader">{t(UI.colPlace)}</span>
                  <span role="columnheader">{t(UI.colDevice)}</span>
                  <span role="columnheader">{t(UI.colStatus)}</span>
                </div>
                {payload.log.map((r) => (
                  <button
                    key={r.id}
                    type="button"
                    role="row"
                    className={`loglog__row ${picked === r.id ? 'is-right' : ''} ${wrongIds.includes(r.id) ? 'is-wrong' : ''}`}
                    disabled={logDone || locked}
                    onClick={() => void submit(r.id)}
                  >
                    <span role="cell" className="mono">
                      <bdi>{r.time}</bdi>
                    </span>
                    <span role="cell" className="mono">
                      <bdi>{r.account}</bdi>
                    </span>
                    <span role="cell">
                      {t(r.place)}
                      <small className="mono">
                        <bdi>{r.ip}</bdi>
                      </small>
                    </span>
                    <span role="cell" className="mono">
                      <bdi>{r.device}</bdi>
                    </span>
                    <span role="cell" className={r.ok ? 'st-ok' : 'st-bad'}>
                      {r.ok ? t(UI.success) : t(UI.failed)}
                    </span>
                  </button>
                ))}
              </div>
            </section>

            {/* Stage 2 — attack order */}
            {logDone && (
              <section className={`vstage chain ${orderDone ? 'is-done' : ''}`}>
                <h2 className="stage__prompt">
                  <span className="stage__step mono">2/3</span> <ListOrdered size={18} aria-hidden="true" /> {t(c.stages[1].prompt)}
                </h2>
                <ol className="order">
                  {payload.steps.map((_, i) => {
                    const st = payload.steps.find((s) => s.id === order[i]);
                    return (
                      <li key={i} className={`order__slot ${st ? 'is-filled' : ''}`}>
                        <span className="order__n mono">{i + 1}</span>
                        {st ? (
                          <button
                            type="button"
                            className="order__card"
                            disabled={orderDone}
                            onClick={() => !orderDone && setOrder((o) => o.filter((x) => x !== st.id))}
                          >
                            <b>{t(st.title)}</b>
                          </button>
                        ) : (
                          <span className="order__empty">{t(UI.tapToPlace)}</span>
                        )}
                      </li>
                    );
                  })}
                </ol>
                {!orderDone && (
                  <>
                    <ul className="chain__pool">
                      {payload.steps.map((st) => (
                        <li key={st.id}>
                          <button type="button" className={`evcard ${order.includes(st.id) ? 'is-used' : ''}`} disabled={order.includes(st.id) || locked} onClick={() => place(st.id)}>
                            <b>{t(st.title)}</b>
                            <span>{t(st.text)}</span>
                          </button>
                        </li>
                      ))}
                    </ul>
                    <div className="chain__actions">
                      <button type="button" className="btn btn--ghost" onClick={() => setOrder([])} disabled={!order.length}>
                        <Eraser size={16} aria-hidden="true" /> {t(UI.clearChain)}
                      </button>
                      <button type="button" className="btn btn--primary" disabled={order.length < payload.steps.length || locked} onClick={() => void submit(order.join(','))}>
                        <ListOrdered size={18} aria-hidden="true" /> {t(UI.checkChain)}
                      </button>
                    </div>
                  </>
                )}
              </section>
            )}

            {/* Stage 3 — final code */}
            {orderDone && (
              <section className="vstage flagbuild">
                <h2 className="stage__prompt">
                  <span className="stage__step mono">3/3</span> <KeyRound size={18} aria-hidden="true" /> {t(c.stages[2].prompt)}
                </h2>
                <div className="codeboxes" dir="ltr" aria-hidden="true">
                  {ROOMS.map((r) => (
                    <span key={r.id} className="codeboxes__grp" style={{ '--accent': r.accent } as React.CSSProperties}>
                      {r.fragment.split('').map((ch, i) => (
                        <i key={i}>{ch}</i>
                      ))}
                    </span>
                  ))}
                </div>
                <div className="flagbuild__chips" role="group" aria-label={t(UI.fragments)}>
                  {chips.map((f) => (
                    <button key={f} type="button" className="fragchip mono" dir="ltr" onClick={() => addChip(f)} disabled={locked}>
                      {f}
                    </button>
                  ))}
                  <button type="button" className="fragchip fragchip--undo" onClick={undoChip} disabled={!parts.length}>
                    <Delete size={16} aria-hidden="true" /> {t(UI.backspace)}
                  </button>
                </div>
                <FlagSubmissionChallenge
                  inputId="final-flag"
                  stage={c.stages[2] as TextStage}
                  value={text}
                  onChange={(v) => {
                    setText(v);
                    setParts([]);
                  }}
                  disabled={locked}
                  busy={busy}
                  onSubmit={() => void submit(text)}
                />
                <p className="flagbuild__slogan">
                  <bdi dir="rtl">#لا_تفتح_مجال</bdi>
                </p>
              </section>
            )}

            {feedback && (
              <div className={`feedback feedback--${feedback.kind}`} role="status">
                {feedback.kind === 'ok' ? <CheckCircle2 size={20} aria-hidden="true" /> : <XCircle size={20} aria-hidden="true" />}
                <span>{t(feedback.msg)}</span>
                {cooling && (
                  <span className="feedback__cool">
                    <i style={{ inlineSize: `${cooldownPct}%` }} />
                  </span>
                )}
              </div>
            )}
            <CardFoot code="D360_04" />
          </div>
          <HintPanel challenge={c} overTime={false} />
        </div>
      )}
    </div>
  );
}
