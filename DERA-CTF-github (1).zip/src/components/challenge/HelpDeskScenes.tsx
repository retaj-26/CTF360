import { useMemo, useState } from 'react';
import { Mail, Paperclip, PhoneCall, PhoneIncoming, Check, Eye, EyeOff, KeyRound, ShieldAlert, ShieldCheck, X, Siren } from 'lucide-react';
import { useStore } from '../../state/store';
import { UI } from '../../data/ui';
import { play } from '../../audio/sound';
import type { CallsPayload, PasswordPayload, PhishPayload } from '../../engine/types';
import type { SceneProps } from './sceneProps';

// ───────────────────────── Phishing email: tap the red flags ─────────────────────────
export function PhishScene({ payload, pickActive, passed, wrongIds, solved, locked, onPick }: SceneProps<PhishPayload>) {
  const { t } = useStore();
  const found = new Set(passed);

  const Spot = ({ id, children, className = '' }: { id: string; children: React.ReactNode; className?: string }) => {
    const isFound = found.has(id);
    const isWrong = wrongIds.includes(id);
    return (
      <button
        type="button"
        className={`spot ${className} ${isFound ? 'is-found' : ''} ${isWrong ? 'is-wrong' : ''}`}
        disabled={!pickActive || locked || isFound || solved}
        onClick={() => onPick(id)}
      >
        {children}
        {isFound && <span className="spot__tag" aria-hidden="true">!</span>}
      </button>
    );
  };

  return (
    <div className="scene phish">
      <div className="phish__bar">
        <span className="win-dots" aria-hidden="true">
          <i />
          <i />
          <i />
        </span>
        <Mail size={15} aria-hidden="true" />
        <span>{t({ ar: 'رسالة من البريد الإلكتروني', en: 'Email message' })}</span>
        <span className="phish__count mono" aria-live="polite">
          {t(UI.phishFound)} {found.size}/{payload.flagsToFind}
        </span>
      </div>
      <div className="phish__paper">
        <dl className="phish__head">
          <div>
            <dt>{t(UI.from)}:</dt>
            <dd>
              <Spot id={payload.headerHotspots.from}>
                {t(payload.fromName)} <span className="mono" dir="ltr">&lt;{payload.fromAddr}&gt;</span>
              </Spot>
            </dd>
          </div>
          <div>
            <dt>{t(UI.to)}:</dt>
            <dd className="mono" dir="ltr">
              {payload.to}
            </dd>
          </div>
          <div>
            <dt>{t(UI.subject)}:</dt>
            <dd>
              <Spot id={payload.headerHotspots.subject}>
                <b>{t(payload.subject)}</b>
              </Spot>
            </dd>
          </div>
          <div>
            <dt aria-hidden="true" />
            <dd>
              <Spot id={payload.headerHotspots.date} className="spot--quiet">
                <span className="mono" dir="ltr">
                  {payload.date}
                </span>
              </Spot>
            </dd>
          </div>
        </dl>
        <div className="phish__body">
          {payload.body.map((seg, i) => {
            const content = seg.mono ? (
              <span className="mono phish__link" dir="ltr">
                {t(seg.text)}
              </span>
            ) : (
              t(seg.text)
            );
            const node = seg.id ? <Spot id={seg.id}>{content}</Spot> : <span>{content}</span>;
            return seg.block ? (
              <p key={i} className="phish__p">
                {node}
              </p>
            ) : (
              <span key={i}>{node}</span>
            );
          })}
        </div>
        <div className="phish__attach">
          <Paperclip size={14} aria-hidden="true" /> <span className="mono" dir="ltr">Update_Form.html</span>
        </div>
      </div>
    </div>
  );
}

// ───────────────────────── Support hotline: three calls ─────────────────────────
export function CallsScene({ payload, stage, solved }: SceneProps<CallsPayload>) {
  const { t } = useStore();
  const current = Math.min(stage, payload.calls.length - 1);
  const c = payload.calls[current];
  return (
    <div className="scene calls">
      <ol className="calls__queue" aria-label={t(UI.incoming)}>
        {payload.calls.map((call, i) => {
          const done = i < stage || solved;
          const now = i === current && !solved;
          return (
            <li key={i} className={`${done ? 'is-done' : ''} ${now ? 'is-now' : ''}`}>
              <span className="calls__dot">{done ? <Check size={14} aria-hidden="true" /> : i + 1}</span>
              <span>{t(call.caller)}</span>
            </li>
          );
        })}
      </ol>
      {!solved && (
        <div className={`call call--${c.mood}`} key={current}>
          <div className="call__head">
            <span className="call__avatar" aria-hidden="true">
              {c.mood === 'suspicious' ? '?' : t(c.caller).replace(/[«»"“”]/g, '').trim().charAt(0)}
            </span>
            <div className="call__who">
              <b>{t(c.caller)}</b>
              <span>{t(c.role)}</span>
            </div>
            <span className="call__live">
              {c.mood === 'urgent' ? <Siren size={16} aria-hidden="true" /> : c.mood === 'suspicious' ? <ShieldAlert size={16} aria-hidden="true" /> : <PhoneIncoming size={16} aria-hidden="true" />}
              {t(UI.callerOn)}
            </span>
          </div>
          <p className="call__bubble">
            <PhoneCall size={16} aria-hidden="true" /> {t(c.message)}
          </p>
          <div className="call__wave" aria-hidden="true">
            {Array.from({ length: 28 }).map((_, i) => (
              <i key={i} style={{ animationDelay: `${(i % 7) * 0.09}s` }} />
            ))}
          </div>
        </div>
      )}
    </div>
  );
}

// ───────────────────────── Password: spot the flaw, build a strong one ─────────────────────────
function crackSeconds(pw: string): number {
  let pool = 0;
  if (/[a-z]/.test(pw)) pool += 26;
  if (/[A-Z]/.test(pw)) pool += 26;
  if (/[0-9]/.test(pw)) pool += 10;
  if (/[^A-Za-z0-9]/.test(pw)) pool += 33;
  if (!pool) return 0;
  // 10 billion guesses per second (a fast offline cracking rig).
  return Math.pow(pool, pw.length) / 1e10;
}

function humanTime(sec: number, lang: 'ar' | 'en') {
  const units: [number, string, string][] = [
    [3.15e7 * 1e6, 'مليون سنة', 'million years'],
    [3.15e7 * 1000, 'ألف سنة', 'thousand years'],
    [3.15e7, 'سنة', 'years'],
    [86400, 'يوم', 'days'],
    [3600, 'ساعة', 'hours'],
    [60, 'دقيقة', 'minutes'],
    [1, 'ثانية', 'seconds'],
  ];
  if (sec < 1) return lang === 'ar' ? 'أقل من ثانية' : 'under a second';
  if (sec > 3.15e7 * 1e9) return lang === 'ar' ? 'أكثر من مليار سنة' : 'over a billion years';
  for (const [n, ar, en] of units) {
    if (sec >= n) {
      const v = Math.round(sec / n);
      return `${v.toLocaleString('en-US')} ${lang === 'ar' ? ar : en}`;
    }
  }
  return '';
}

export function PasswordScene({ payload, pickActive, solved, locked, onPick, stage }: SceneProps<PasswordPayload>) {
  const { t, prefs } = useStore();
  const [show, setShow] = useState(false);
  const [pw, setPw] = useState('');
  const [peek, setPeek] = useState(false);

  const rules = useMemo(() => {
    const lower = pw.toLowerCase();
    return [
      { ok: pw.length >= payload.minLength, label: UI.ruleLen },
      { ok: /[A-Z]/.test(pw), label: UI.ruleUpper },
      { ok: /[a-z]/.test(pw), label: UI.ruleLower },
      { ok: /[0-9]/.test(pw), label: UI.ruleDigit },
      { ok: /[^A-Za-z0-9\s]/.test(pw), label: UI.ruleSymbol },
      { ok: pw.length > 0 && !payload.banned.some((b) => lower.includes(b)), label: UI.ruleBanned },
    ];
  }, [pw, payload]);
  const passedCount = rules.filter((r) => r.ok).length;
  const allOk = passedCount === rules.length;
  const level = !pw ? 0 : allOk ? 4 : Math.min(3, Math.floor((passedCount / rules.length) * 4));
  const sec = rules[5].ok ? crackSeconds(pw) : 0;

  return (
    <div className="scene pwscene">
      <div className="acct">
        <p className="acct__title">
          <KeyRound size={16} aria-hidden="true" /> {t(UI.accountData)}
        </p>
        <div className="acct__row">
          <span>{t(UI.username)}</span>
          <code dir="ltr">{payload.account.username}</code>
        </div>
        <div className="acct__row">
          <span>{t(UI.password)}</span>
          <code dir="ltr" className="acct__pw">
            {show ? payload.account.password : '•'.repeat(payload.account.password.length)}
          </code>
          <button type="button" className="ctl ctl--ghost" onClick={() => setShow((s) => !s)} aria-label={t(UI.password)}>
            {show ? <EyeOff size={16} /> : <Eye size={16} />}
          </button>
        </div>
        <p className="acct__note">{t(UI.usedOn)}</p>
        <ul className="acct__reuse">
          {payload.reusedOn.map((r, i) => (
            <li key={i}>
              <span className="mono" dir="ltr">
                {show ? payload.account.password : '••••••••'}
              </span>
              {t(r)}
            </li>
          ))}
        </ul>
      </div>

      {(stage >= 1 || solved) && (
        <div className={`builder ${solved ? 'is-done' : ''}`}>
          <p className="acct__title">
            <ShieldCheck size={16} aria-hidden="true" /> {t(UI.builder)}
          </p>
          {!solved && (
            <>
              <div className="builder__field">
                <label htmlFor="pw-builder" className="sr-only">
                  {t(UI.builder)}
                </label>
                <input
                  id="pw-builder"
                  className="input input--mono"
                  dir="ltr"
                  type={peek ? 'text' : 'password'}
                  autoComplete="off"
                  spellCheck={false}
                  value={pw}
                  disabled={!pickActive || locked}
                  placeholder="Qahwa#Buraidah!77"
                  onChange={(e) => setPw(e.target.value)}
                />
                <button type="button" className="ctl" onClick={() => setPeek((p) => !p)} aria-label="show">
                  {peek ? <EyeOff size={16} /> : <Eye size={16} />}
                </button>
              </div>
              <div className={`meter5 meter5--${level}`} aria-label={t(UI.strength[level])}>
                {[1, 2, 3, 4].map((n) => (
                  <i key={n} className={level >= n ? 'is-on' : ''} />
                ))}
                <span>{pw ? t(UI.strength[level]) : '—'}</span>
              </div>
              <ul className="rules">
                {rules.map((r, i) => (
                  <li key={i} className={r.ok ? 'is-ok' : ''}>
                    {r.ok ? <Check size={14} aria-hidden="true" /> : <X size={14} aria-hidden="true" />} {t(r.label)}
                  </li>
                ))}
              </ul>
              <p className="builder__crack">
                {t(UI.crackTime)}: <b>{pw ? humanTime(sec, prefs.lang) : '—'}</b>
              </p>
              <p className="builder__warn">{t(UI.builderWarn)}</p>
              <button
                type="button"
                className="btn btn--primary"
                disabled={!allOk || !pickActive || locked}
                onClick={() => {
                  play('click');
                  onPick('strong-ok');
                }}
              >
                <ShieldCheck size={18} aria-hidden="true" /> {t(UI.usePassword)}
              </button>
            </>
          )}
        </div>
      )}
    </div>
  );
}
