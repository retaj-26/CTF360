import type { Challenge } from '../../engine/types';

export interface SceneProps<P> {
  challenge: Challenge;
  payload: P;
  /** Index of the stage the visitor is on (equals stages.length once solved). */
  stage: number;
  /** True while the current stage expects the visitor to click something in the scene. */
  pickActive: boolean;
  /** Correct answers of already-passed stages (index 0 is usually the scene pick). */
  passed: string[];
  /** Ids the visitor tried that were wrong (for this attempt). */
  wrongIds: string[];
  solved: boolean;
  locked: boolean;
  onPick: (id: string) => void;
  /** For code scenes: tapping a flag token fills the answer box. */
  onChip?: (text: string) => void;
}
