import { forwardRef } from 'react';
import { Send } from 'lucide-react';
import { useStore } from '../../state/store';
import { UI } from '../../data/ui';
import type { ChoiceStage, TextStage } from '../../engine/types';

export function MultipleChoiceChallenge({
  stage,
  onChoose,
  wrongIds,
  rightId,
  disabled,
  variant = '',
}: {
  variant?: string;
  stage: ChoiceStage;
  onChoose: (id: string) => void;
  wrongIds: string[];
  rightId?: string;
  disabled: boolean;
}) {
  const { t } = useStore();
  return (
    <div className={`choices choices--${variant}`} role="group" aria-label={t(stage.prompt)}>
      {stage.options.map((o, i) => {
        const right = rightId === o.id;
        const wrong = wrongIds.includes(o.id);
        return (
          <button
            key={o.id}
            type="button"
            className={`choice choice--${o.id.split('-').pop()} ${right ? 'is-right' : ''} ${wrong ? 'is-wrong' : ''}`}
            disabled={disabled || (!!rightId && !right)}
            onClick={() => onChoose(o.id)}
          >
            <span className="choice__key mono" aria-hidden="true">
              {variant === 'firewall' ? (o.id.endsWith('allow') ? '✓' : '✕') : String.fromCharCode(65 + i)}
            </span>
            <span className="choice__text">
              {t(o.label)}
              {o.mono && (
                <code className="choice__mono" dir="ltr">
                  {o.mono}
                </code>
              )}
            </span>
          </button>
        );
      })}
    </div>
  );
}

export const FlagSubmissionChallenge = forwardRef<
  HTMLInputElement,
  {
    stage: TextStage;
    value: string;
    onChange: (v: string) => void;
    onSubmit: () => void;
    disabled: boolean;
    busy: boolean;
    inputId: string;
  }
>(function FlagSubmissionChallenge({ stage, value, onChange, onSubmit, disabled, busy, inputId }, ref) {
  const { t } = useStore();
  return (
    <form
      className="flagform"
      onSubmit={(e) => {
        e.preventDefault();
        if (!disabled && value.trim()) onSubmit();
      }}
    >
      <label htmlFor={inputId} className="sr-only">
        {t(stage.prompt)}
      </label>
      <input
        ref={ref}
        id={inputId}
        className={`input ${stage.mono ? 'input--mono' : ''}`}
        dir={stage.mono ? 'ltr' : 'auto'}
        value={value}
        placeholder={t(stage.placeholder)}
        autoComplete="off"
        autoCapitalize="off"
        autoCorrect="off"
        spellCheck={false}
        disabled={disabled}
        onChange={(e) => onChange(e.target.value)}
      />
      <button type="submit" className="btn btn--primary" disabled={disabled || !value.trim()}>
        <Send size={18} aria-hidden="true" /> {busy ? t(UI.checking) : t(UI.submit)}
      </button>
    </form>
  );
});
