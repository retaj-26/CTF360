import { logEvent } from '../../state/auth';
import { useCallback, useEffect, useRef, useState } from 'react';
import { useStore } from '../../state/store';
import { checkAnswer } from '../../engine/validate';
import { WRONG_COOLDOWN_MS } from '../../engine/scoring';
import { UI } from '../../data/ui';
import { play } from '../../audio/sound';
import type { Challenge, L10n } from '../../engine/types';
import type { NormMode } from '../../engine/normalize';

export type Feedback = { kind: 'ok' | 'bad' | 'error'; msg: L10n } | null;

function modeFor(c: Challenge, stageIdx: number): NormMode {
  const st = c.stages[stageIdx];
  if (!st || st.kind !== 'text') return 'id';
  if (c.type === 'flag') return 'flag';
  if (c.type === 'decoder') return 'phrase';
  return 'text';
}

/** Shared answer-submission flow: validation, feedback, cooldown, scoring dispatch. */
export function useSubmit(challenge: Challenge) {
  const { dispatch, progressOf } = useStore();
  const p = progressOf(challenge.id);
  const [feedback, setFeedback] = useState<Feedback>(null);
  const [wrongIds, setWrongIds] = useState<string[]>([]);
  const [busy, setBusy] = useState(false);
  const [cooldownUntil, setCooldownUntil] = useState(0);
  const [now, setNow] = useState(Date.now());
  const [justSolved, setJustSolved] = useState(false);
  const stageRef = useRef(p.stage);
  stageRef.current = p.stage;

  // Reset transient UI when switching challenge.
  useEffect(() => {
    setFeedback(null);
    setWrongIds([]);
    setJustSolved(false);
    setCooldownUntil(0);
  }, [challenge.id]);

  useEffect(() => {
    if (cooldownUntil <= Date.now()) return;
    const id = setInterval(() => {
      setNow(Date.now());
      if (Date.now() >= cooldownUntil) clearInterval(id);
    }, 100);
    return () => clearInterval(id);
  }, [cooldownUntil]);

  const cooling = cooldownUntil > now;
  const cooldownPct = cooling ? Math.round(((cooldownUntil - now) / WRONG_COOLDOWN_MS) * 100) : 0;

  const submit = useCallback(
    async (answer: string) => {
      if (busy || p.solved || cooldownUntil > Date.now()) return false;
      const stage = stageRef.current;
      setBusy(true);
      try {
        const v = await checkAnswer(challenge.id, stage, answer, modeFor(challenge, stage));
        logEvent({ area: 'comp', cid: challenge.id, stage, kind: v.correct && stage >= challenge.stages.length - 1 ? 'solve' : 'attempt', answer, ok: v.correct });
        if (v.correct) {
          play('correct');
          setWrongIds([]);
          if (stage >= challenge.stages.length - 1) {
            dispatch({ type: 'solve', id: challenge.id, answer });
            setJustSolved(true);
            setFeedback({ kind: 'ok', msg: UI.correct });
          } else {
            dispatch({ type: 'stage', id: challenge.id, answer });
            setFeedback({ kind: 'ok', msg: UI.correct });
          }
          return true;
        }
        play('wrong');
        dispatch({ type: 'wrong', id: challenge.id });
        setWrongIds((w) => [...w, answer]);
        setFeedback({ kind: 'bad', msg: challenge.wrongFeedback?.[answer] ?? challenge.wrongFeedback?.[v.normalized] ?? UI.wrong });
        const until = Date.now() + WRONG_COOLDOWN_MS;
        setNow(Date.now());
        setCooldownUntil(until);
        return false;
      } catch {
        setFeedback({ kind: 'error', msg: UI.serverError });
        return false;
      } finally {
        setBusy(false);
      }
    },
    [busy, p.solved, cooldownUntil, challenge, dispatch],
  );

  return { submit, feedback, setFeedback, wrongIds, busy, cooling, cooldownPct, justSolved };
}
