import { useState, type ReactNode } from 'react';
import { FileCode2, Terminal, RadioTower, Unlock, ClipboardCheck } from 'lucide-react';
import { useStore } from '../../state/store';
import { UI } from '../../data/ui';
import { DECODERS } from '../../engine/decoders';
import { play } from '../../audio/sound';
import type { CodePayload, SecretPayload } from '../../engine/types';
import type { SceneProps } from './sceneProps';

const KW = /^(for|in|def|return|if|else|import|from|True|False|None|print|break)$/;

type Chip = { re: RegExp; on: (s: string) => void };

/** Minimal, safe Python highlighter: produces React nodes, never HTML strings. */
export function highlight(line: string, chip?: Chip): ReactNode[] {
  const out: ReactNode[] = [];
  let k = 0;
  const push = (s: string, cls?: string) => {
    if (!s) return;
    if (chip) {
      const re = new RegExp(chip.re.source, 'g');
      let last = 0;
      let m: RegExpExecArray | null;
      let any = false;
      while ((m = re.exec(s))) {
        any = true;
        if (m.index > last) out.push(<span key={k++} className={cls}>{s.slice(last, m.index)}</span>);
        const val = m[0];
        out.push(
          <button key={k++} type="button" className={`flagchip ${cls ?? ''}`} onClick={() => chip.on(val)}>
            {val}
          </button>,
        );
        last = m.index + val.length;
      }
      if (any) {
        if (last < s.length) out.push(<span key={k++} className={cls}>{s.slice(last)}</span>);
        return;
      }
    }
    out.push(<span key={k++} className={cls}>{s}</span>);
  };
  const plain = (s: string) =>
    s.split(/(\b\w+\b)/).forEach((part) => {
      if (!part) return;
      if (KW.test(part)) push(part, 'tok-kw');
      else if (/^\d+$/.test(part)) push(part, 'tok-num');
      else if (/^[A-Z_]{3,}$/.test(part)) push(part, 'tok-const');
      else push(part);
    });
  let rest = line;
  while (rest.length) {
    const hash = rest.indexOf('#');
    const quote = rest.indexOf('"');
    if (hash !== -1 && (quote === -1 || hash < quote)) {
      plain(rest.slice(0, hash));
      push(rest.slice(hash), 'tok-com');
      break;
    }
    if (quote !== -1) {
      const end = rest.indexOf('"', quote + 1);
      plain(rest.slice(0, quote));
      const stop = end === -1 ? rest.length : end + 1;
      push(rest.slice(quote, stop), 'tok-str');
      rest = rest.slice(stop);
      continue;
    }
    plain(rest);
    break;
  }
  return out;
}

function CodeBlock({
  filename,
  lines,
  render,
}: {
  filename: string;
  lines: string[];
  render: (line: string, i: number) => ReactNode;
}) {
  return (
    <>
      <div className="code__bar">
        <span className="win-dots" aria-hidden="true">
          <i />
          <i />
          <i />
        </span>
        <FileCode2 size={15} aria-hidden="true" />
        <span className="mono" dir="ltr">
          {filename}
        </span>
        <span className="code__lang mono">python</span>
      </div>
      <pre className="code__pre" dir="ltr">
        {lines.map((l, i) => render(l, i))}
      </pre>
    </>
  );
}

export function CodeInspectionChallenge({ payload, pickActive, passed, wrongIds, solved, locked, onPick }: SceneProps<CodePayload>) {
  const { t } = useStore();
  const picked = passed[0];
  return (
    <div className="scene code">
      <CodeBlock
        filename={payload.filename}
        lines={payload.lines}
        render={(line, i) => {
          const id = `line-${i + 1}`;
          const isFixed = solved && payload.fixedLine?.line === i + 1;
          const shown = isFixed ? payload.fixedLine!.text : line;
          const content = highlight(shown);
          const cls = `code__line ${picked === id || isFixed ? 'is-right' : ''} ${wrongIds.includes(id) ? 'is-wrong' : ''}`;
          return payload.pickableLines ? (
            <button key={i} type="button" className={cls} disabled={!pickActive || locked} onClick={() => onPick(id)} aria-label={`line ${i + 1}: ${line}`}>
              <span className="code__ln">{i + 1}</span>
              <code>{content.length ? content : ' '}</code>
            </button>
          ) : (
            <div key={i} className={cls}>
              <span className="code__ln">{i + 1}</span>
              <code>{content.length ? content : ' '}</code>
            </div>
          );
        }}
      />
      {solved && payload.outputAfterSolve && (
        <div className="term term--small code__out" dir="ltr">
          <p className="term__sys">
            <Terminal size={14} aria-hidden="true" /> {t(UI.output)}
          </p>
          {payload.outputAfterSolve.map((l, i) => (
            <p key={i} className="ok" style={{ animationDelay: `${i * 0.25}s` }}>
              {l}
            </p>
          ))}
        </div>
      )}
    </div>
  );
}

const B64 = /[A-Za-z0-9+/]{24,}={0,2}/;

export function SecretScene({ payload, solved, onChip }: SceneProps<SecretPayload>) {
  const { t } = useStore();
  const [input, setInput] = useState('');
  const [mode, setMode] = useState<'base64' | 'hex'>('base64');
  const [out, setOut] = useState<{ ok: boolean; text: string } | null>(null);

  const load = (s: string) => {
    play('click');
    setInput(s);
    setOut(null);
  };
  const run = () => {
    const r = DECODERS[mode](input);
    if (r.ok) {
      play('correct');
      setOut({ ok: true, text: r.text });
    } else {
      play('wrong');
      setOut({ ok: false, text: t(UI.decodeError) });
    }
  };
  const flag = out?.ok ? out.text.match(/DERA\{[^}\s]+\}/)?.[0] : undefined;

  return (
    <div className="scene code secret">
      {!solved && <p className="scene__tip">{t(UI.tapString)}</p>}
      <CodeBlock
        filename={payload.filename}
        lines={payload.lines}
        render={(line, i) => {
          const content = highlight(line, solved ? undefined : { re: B64, on: load });
          return (
            <div key={i} className="code__line">
              <span className="code__ln">{i + 1}</span>
              <code>{content.length ? content : ' '}</code>
            </div>
          );
        }}
      />
      <div className="decoder decoder--inline">
        <div className="decoder__head">
          <RadioTower size={16} aria-hidden="true" />
          <span>{t(UI.decoder)}</span>
        </div>
        <label className="decoder__field">
          <span>{t(UI.decoderInput)}</span>
          <textarea
            id="secret-decoder-in"
            className="input input--mono decoder__in"
            dir="ltr"
            rows={2}
            spellCheck={false}
            value={input}
            placeholder="…"
            onChange={(e) => setInput(e.target.value)}
          />
        </label>
        <div className="decoder__tools">
          <div className="seg seg--big" role="radiogroup" aria-label={t(UI.decoder)}>
            {(['base64', 'hex'] as const).map((m) => (
              <button
                key={m}
                type="button"
                role="radio"
                aria-checked={mode === m}
                className={`seg__btn ${mode === m ? 'is-active' : ''}`}
                onClick={() => {
                  play('click');
                  setMode(m);
                  setOut(null);
                }}
              >
                {t(UI[m])}
              </button>
            ))}
          </div>
          <button type="button" className="btn btn--primary" onClick={run} disabled={!input.trim()}>
            <Unlock size={18} aria-hidden="true" /> {t(UI.decode)}
          </button>
        </div>
        <div className={`decoder__out ${out ? (out.ok ? 'is-ok' : 'is-bad') : ''}`} aria-live="polite">
          <span className="decoder__outlabel">{t(UI.decoderOutput)}</span>
          <output dir="ltr" className="mono">
            {out ? out.text : '_'}
          </output>
          {flag && !solved && (
            <button type="button" className="btn btn--sm btn--success decoder__use" onClick={() => onChip?.(flag)}>
              <ClipboardCheck size={16} aria-hidden="true" /> {t(UI.copyFlag)}
            </button>
          )}
        </div>
      </div>
    </div>
  );
}
