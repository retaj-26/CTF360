import { logEvent, useAdmin } from '../../state/auth';
import { AdminAnswer } from '../admin/AdminAnswer';
import { useEffect, useRef, useState } from 'react';
import { Flag, CheckCircle2, XCircle, Timer, ChevronsLeft, ChevronsRight, GraduationCap, AlertOctagon, Lock } from 'lucide-react';
import { useStore } from '../../state/store';
import { UI } from '../../data/ui';
import type {
  CallsPayload,
  Challenge,
  CodePayload,
  DecoderPayload,
    FirewallPayload,
  NetworkPayload,
  PasswordPayload,
  PhishPayload,
  SecretPayload,
  SubnetPayload,
  WifiPayload,
} from '../../engine/types';
import { HintPanel } from '../HintPanel';
import { CallsScene, PasswordScene, PhishScene } from './HelpDeskScenes';
import { FirewallScene, NetworkDiagramChallenge, SubnetScene, WifiScene } from './NetworkDiagram';
import { DecoderChallenge } from './Decoder';
import { CodeInspectionChallenge, SecretScene } from './CodeInspection';
import { MultipleChoiceChallenge, FlagSubmissionChallenge } from './AnswerWidgets';
import { useSubmit } from './useSubmit';
import type { SceneProps } from './sceneProps';

function useCountdown(challenge: Challenge, openedAt: number | undefined, solved: boolean) {
  const [now, setNow] = useState(Date.now());
  useEffect(() => {
    if (!challenge.timeLimitSec || solved) return;
    const id = setInterval(() => setNow(Date.now()), 500);
    return () => clearInterval(id);
  }, [challenge.timeLimitSec, solved]);
  if (!challenge.timeLimitSec || !openedAt) return { left: null as number | null, over: false };
  const left = Math.max(0, Math.ceil(challenge.timeLimitSec - (now - openedAt) / 1000));
  return { left, over: left === 0 };
}

function Scene(props: SceneProps<unknown>) {
  const pl = props.challenge.payload;
  switch (pl.scene) {
    case 'phish':
      return <PhishScene {...(props as SceneProps<PhishPayload>)} payload={pl} />;
    case 'calls':
      return <CallsScene {...(props as SceneProps<CallsPayload>)} payload={pl} />;
    case 'password':
      return <PasswordScene {...(props as SceneProps<PasswordPayload>)} payload={pl} />;
    case 'firewall':
      return <FirewallScene {...(props as SceneProps<FirewallPayload>)} payload={pl} />;
    case 'wifi':
      return <WifiScene {...(props as SceneProps<WifiPayload>)} payload={pl} />;
    case 'secret':
      return <SecretScene {...(props as SceneProps<SecretPayload>)} payload={pl} />;
    case 'network':
      return <NetworkDiagramChallenge {...(props as SceneProps<NetworkPayload>)} payload={pl} />;
    case 'subnet':
      return <SubnetScene {...(props as SceneProps<SubnetPayload>)} payload={pl} />;
    case 'decoder':
      return <DecoderChallenge {...(props as SceneProps<DecoderPayload>)} payload={pl} />;
    case 'code':
      return <CodeInspectionChallenge {...(props as SceneProps<CodePayload>)} payload={pl} />;
    default:
      return null;
  }
}

export function ChallengeRenderer({ challenge, onNext, nextLabel }: { challenge: Challenge; onNext: () => void; nextLabel: string }) {
  const { t, prefs, progressOf, dispatch } = useStore();
  const admin = useAdmin();
  const p = progressOf(challenge.id);
  const { submit, feedback, wrongIds, busy, cooling, cooldownPct, justSolved } = useSubmit(challenge);
  const [text, setText] = useState('');
  const inputRef = useRef<HTMLInputElement>(null);
  const solvedRef = useRef<HTMLDivElement>(null);
  const { left, over } = useCountdown(challenge, p.openedAt, p.solved);
  const Arrow = prefs.lang === 'ar' ? ChevronsLeft : ChevronsRight;

  useEffect(() => {
    if (!p.openedAt) logEvent({ area: 'comp', cid: challenge.id, kind: 'open' });
    dispatch({ type: 'open', id: challenge.id });
    setText('');
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [challenge.id, dispatch]);

  useEffect(() => {
    if (justSolved) solvedRef.current?.scrollIntoView({ behavior: 'smooth', block: 'nearest' });
  }, [justSolved]);

  const stageIdx = Math.min(p.stage, challenge.stages.length - 1);
  const stage = challenge.stages[stageIdx];
  const locked = busy || cooling;
  const decoderGate = challenge.payload.scene === 'decoder' && challenge.payload.requireDecode && !p.decoded && !p.solved;

  const sceneProps: SceneProps<unknown> = {
    challenge,
    payload: challenge.payload,
    stage: p.stage,
    pickActive: !p.solved && stage.kind === 'pick',
    passed: p.answers,
    wrongIds,
    solved: p.solved,
    locked,
    onPick: (id) => void submit(id),
    onChip: (s) => {
      setText(s);
      inputRef.current?.focus();
    },
  };

  return (
    <article className={`challenge ${p.solved ? 'is-solved' : ''} ${justSolved ? 'just-solved' : ''}`} aria-labelledby={`ch-${challenge.id}`}>
      <div className="challenge__main">
        <header className="challenge__head">
          <div className="challenge__tags">
            <span className="tag tag--letter mono">{challenge.letter}</span>
            <span className={`tag tag--${challenge.difficulty}`}>{t(UI[challenge.difficulty])}</span>
            <span className="tag mono" dir="ltr">
              {challenge.basePoints} pts
            </span>
            {left !== null && !p.solved && (
              <span className={`tag tag--timer ${over ? 'is-over' : left < 30 ? 'is-low' : ''}`} role="timer">
                <Timer size={14} aria-hidden="true" />{' '}
                {over ? (
                  t(UI.timeUp)
                ) : (
                  <>
                    {t(UI.timeLeft)}{' '}
                    <b className="mono" dir="ltr">
                      {Math.floor(left / 60)}:{String(left % 60).padStart(2, '0')}
                    </b>
                  </>
                )}
              </span>
            )}
          </div>
          <h2 id={`ch-${challenge.id}`} className="challenge__title">
            {t(challenge.title)}
          </h2>
          {challenge.bio && (
            <p className="najdi">
              <span className="najdi__face" aria-hidden="true">
                🗣️
              </span>
              <span>{t(challenge.bio)}</span>
            </p>
          )}
          <p className="challenge__desc">{t(challenge.description)}</p>
          {challenge.tutorial && !p.solved && (
            <ol className="tutorial" aria-label={t({ ar: 'خطوات التحدي التجريبي', en: 'Guided steps' })}>
              <li className="tutorial__head">
                <GraduationCap size={16} aria-hidden="true" /> {t({ ar: 'تحدي تجريبي تعليمي — امشي معي خطوة خطوة', en: 'Guided challenge — step by step' })}
              </li>
              {challenge.tutorial.map((st, i) => (
                <li key={i}>
                  <b className="mono">{i + 1}</b> {t(st)}
                </li>
              ))}
            </ol>
          )}
        </header>
        {admin && <AdminAnswer challenge={challenge} />}

        <Scene {...sceneProps} />

        {!p.solved && (
          <section className="stage" aria-live="polite">
            {challenge.stages.length > 1 && (
              <p className="stage__step mono">
                {t(UI.step)} {stageIdx + 1} {t(UI.of)} {challenge.stages.length}
              </p>
            )}
            <h3 className="stage__prompt">{t(stage.prompt)}</h3>
            {stage.kind === 'choice' && (
              <MultipleChoiceChallenge variant={challenge.payload.scene} stage={stage} wrongIds={wrongIds} disabled={locked} onChoose={(id) => void submit(id)} />
            )}
            {stage.kind === 'text' &&
              (decoderGate ? (
                <p className="stage__gate">
                  <Lock size={16} aria-hidden="true" /> {t(UI.decodeFirst)}
                </p>
              ) : (
                <FlagSubmissionChallenge
                  ref={inputRef}
                  inputId={`in-${challenge.id}`}
                  stage={stage}
                  value={text}
                  onChange={setText}
                  disabled={locked}
                  busy={busy}
                  onSubmit={() => void submit(text)}
                />
              ))}
          </section>
        )}

        {feedback && !p.solved && (
          <div className={`feedback feedback--${feedback.kind}`} role="status">
            {feedback.kind === 'ok' ? (
              <CheckCircle2 size={20} aria-hidden="true" />
            ) : feedback.kind === 'error' ? (
              <AlertOctagon size={20} aria-hidden="true" />
            ) : (
              <XCircle size={20} aria-hidden="true" />
            )}
            <span>{t(feedback.msg)}</span>
            {cooling && (
              <span className="feedback__cool" aria-label={t(UI.cooldown)}>
                <i style={{ inlineSize: `${cooldownPct}%` }} />
              </span>
            )}
          </div>
        )}

        {p.solved && (
          <section className="solved" ref={solvedRef} aria-live="polite">
            <div className="solved__burst" aria-hidden="true">
              {Array.from({ length: 12 }).map((_, i) => (
                <i key={i} style={{ '--a': `${i * 30}deg` } as React.CSSProperties} />
              ))}
            </div>
            <div className="solved__head">
              <CheckCircle2 size={28} aria-hidden="true" />
              <div>
                <p className="solved__title">{t(UI.correct)}</p>
                <p className="solved__pts mono" dir="ltr">
                  +{p.points} {t(UI.earned)}
                </p>
              </div>
            </div>
            {challenge.reward && (
              <p className="solved__flag">
                <Flag size={16} aria-hidden="true" /> {t({ ar: 'تم التقاط العلم', en: 'Flag captured' })}
                <code dir="ltr">{challenge.reward}</code>
              </p>
            )}
            {challenge.cheer && <p className="solved__cheer">{t(challenge.cheer)}</p>}
            <button type="button" className="btn btn--success btn--lg" onClick={onNext}>
              {nextLabel} <Arrow size={18} aria-hidden="true" />
            </button>
          </section>
        )}
      </div>
      <HintPanel challenge={challenge} overTime={over} />
    </article>
  );
}
