import { Fragment, useState } from 'react';
import { Monitor, Network, Router, Server, Zap, Eye, EyeOff, ShieldCheck, ShieldX, ArrowRight, ArrowLeft, BrickWall, Lock, LockOpen } from 'lucide-react';
import { useStore } from '../../state/store';
import { UI } from '../../data/ui';
import type { FirewallPayload, NetworkPayload, SubnetPayload, WifiPayload } from '../../engine/types';
import type { SceneProps } from './sceneProps';

const NODE_ICON: Record<string, typeof Monitor> = { pc: Monitor, switch: Network, router: Router, server: Server };

export function NetworkDiagramChallenge({ payload, pickActive, passed, wrongIds, solved, locked, onPick }: SceneProps<NetworkPayload>) {
  const { t } = useStore();
  const picked = passed[0];
  const nodeById = (id: string) => payload.nodes.find((n) => n.id === id)!;
  return (
    <div className="scene netscene">
      <div className="netmap" role="group" aria-label="network diagram">
        {payload.nodes.map((n, i) => {
          const Icon = NODE_ICON[n.id] ?? Server;
          const link = payload.links[i];
          const isRight = link && picked === link.id;
          const fixed = isRight && solved;
          const isWrong = link && wrongIds.includes(link.id);
          return (
            <Fragment key={n.id}>
              <div className={`netnode netnode--${n.id}`}>
                <span className="netnode__icon">
                  <Icon size={28} aria-hidden="true" />
                </span>
                <b>{t(n.label)}</b>
                <code dir="ltr">{n.ip}</code>
              </div>
              {link && (
                <button
                  type="button"
                  className={`netlink ${link.broken && !fixed ? 'is-broken' : ''} ${isRight ? 'is-right' : ''} ${fixed ? 'is-fixed' : ''} ${isWrong ? 'is-wrong' : ''}`}
                  disabled={!pickActive || locked}
                  onClick={() => onPick(link.id)}
                  aria-label={`${t(n.label)} ↔ ${t(nodeById(link.to).label)}`}
                >
                  <span className="netlink__cable" />
                  <span className="netlink__packet" />
                  {link.broken && !fixed && (
                    <span className="netlink__spark" aria-hidden="true">
                      <Zap size={16} />
                    </span>
                  )}
                </button>
              )}
            </Fragment>
          );
        })}
      </div>

      <div className="term term--small pinglog" dir="ltr">
        <p className="term__sys">{t(UI.pingLog)}</p>
        {payload.pingLog.map((p) => {
          const n = nodeById(p.target);
          return (
            <p key={p.target} className={p.ok ? 'ok' : 'bad'}>
              <span className="term__dim">$ ping {n.ip}</span>
              <span dir={t({ ar: 'rtl', en: 'ltr' })}>
                {t(UI.pingFrom)} {t(n.label)} → {p.ok ? t(UI.reply) : t(UI.timeout)}
              </span>
            </p>
          );
        })}
      </div>
    </div>
  );
}

export function SubnetScene({ payload }: SceneProps<SubnetPayload>) {
  const { t } = useStore();
  const [show, setShow] = useState(false);
  const host = payload.host.split('.');
  const mask = payload.mask.split('.');
  return (
    <div className="scene subnet">
      <div className="subnet__cards">
        <div className="subnet__card">
          <span>{t(UI.yourHost)}</span>
          <code dir="ltr">{payload.host}</code>
        </div>
        <div className="subnet__card subnet__card--mask">
          <span>{t(UI.mask)}</span>
          <code dir="ltr">{payload.mask}</code>
        </div>
      </div>
      <button type="button" className="btn btn--ghost btn--sm" aria-expanded={show} onClick={() => setShow((s) => !s)}>
        {show ? <EyeOff size={16} aria-hidden="true" /> : <Eye size={16} aria-hidden="true" />} {t(UI.howMask)}
      </button>
      {show && (
        <div className="octets" dir="ltr">
          {host.map((o, i) => (
            <div key={i} className={`octet ${mask[i] === '255' ? 'octet--fixed' : 'octet--free'}`}>
              <code className="octet__mask">{mask[i]}</code>
              <code className="octet__val">{mask[i] === '255' ? o : '?'}</code>
              <span className="octet__rule" dir={t({ ar: 'rtl', en: 'ltr' })}>
                {mask[i] === '255' ? t(UI.mustMatch) : t(UI.free)}
              </span>
            </div>
          ))}
        </div>
      )}
    </div>
  );
}

export function FirewallScene({ payload, stage, passed, solved }: SceneProps<FirewallPayload>) {
  const { t, prefs } = useStore();
  const Arrow = prefs.lang === 'ar' ? ArrowLeft : ArrowRight;
  const current = Math.min(stage, payload.packets.length - 1);
  const p = payload.packets[current];
  return (
    <div className="scene fw">
      <div className="fw__bar">
        <BrickWall size={16} aria-hidden="true" /> {t(UI.firewall)}
        <span className="fw__count mono" dir="ltr">
          {passed.length}/{payload.packets.length}
        </span>
      </div>
      <ol className="fw__track" aria-hidden="true">
        {payload.packets.map((_, i) => {
          const a = passed[i];
          const cls = a ? (a.endsWith('allow') ? 'is-allow' : 'is-block') : i === current && !solved ? 'is-now' : '';
          return (
            <li key={i} className={cls}>
              {a ? a.endsWith('allow') ? <ShieldCheck size={14} /> : <ShieldX size={14} /> : i + 1}
            </li>
          );
        })}
      </ol>
      {!solved && (
        <div className="packet" key={current}>
          <span className="packet__label mono">
            {t(UI.packet)} #{String(current + 1).padStart(2, '0')}
          </span>
          <div className="packet__route">
            <b>{t(p.from)}</b>
            <Arrow size={18} aria-hidden="true" className="packet__arrow" />
            <b>{t(p.to)}</b>
          </div>
          <div className="packet__meta">
            <span className="chip mono" dir="ltr">
              {t(UI.port)} {p.port}
            </span>
            <span className="chip chip--alt mono" dir="ltr">
              {p.service}
            </span>
          </div>
          <p className="packet__note">{t(p.note)}</p>
        </div>
      )}
    </div>
  );
}

export function WifiScene({ payload, pickActive, passed, wrongIds, solved, locked, onPick }: SceneProps<WifiPayload>) {
  const { t } = useStore();
  const picked = passed[0];
  return (
    <div className="scene wifi">
      <div className="wifi__poster">
        <span className="wifi__posterlabel">{t({ ar: 'بوستر المعرض', en: 'Expo poster' })}</span>
        <p>
          {t({ ar: 'شبكة الواي فاي الرسمية:', en: 'Official Wi-Fi network:' })} <b className="mono" dir="ltr">{payload.poster.ssid}</b> <Lock size={14} aria-hidden="true" />
        </p>
        <small>{t(payload.poster.note)}</small>
      </div>
      <div className="phone">
        <div className="phone__bar mono" dir="ltr">
          <span>09:41</span>
          <span>Wi-Fi</span>
        </div>
        <p className="phone__title">{t({ ar: 'اختاري شبكة', en: 'Choose a network' })}</p>
        <ul className="wifi__list">
          {payload.networks.map((n) => {
            const isRight = picked === n.id;
            const isWrong = wrongIds.includes(n.id);
            return (
              <li key={n.id}>
                <button
                  type="button"
                  className={`wifi__net ${isRight ? 'is-right' : ''} ${isWrong ? 'is-wrong' : ''}`}
                  disabled={!pickActive || locked || (solved && !isRight)}
                  onClick={() => onPick(n.id)}
                >
                  <span className="wifi__bars" aria-hidden="true">
                    {[1, 2, 3, 4].map((b) => (
                      <i key={b} className={b <= n.bars ? 'is-on' : ''} style={{ blockSize: `${b * 25}%` }} />
                    ))}
                  </span>
                  <span className="wifi__ssid mono" dir="ltr">
                    {n.ssid}
                  </span>
                  {n.tag && <span className="wifi__tag">{t(n.tag)}</span>}
                  <span className={`wifi__lock wifi__lock--${n.locked ? 'locked' : 'open'}`} aria-label={n.locked ? t({ ar: 'محمية', en: 'locked' }) : t({ ar: 'مفتوحة', en: 'open' })}>
                    {n.locked ? <Lock size={18} /> : <LockOpen size={18} />}
                  </span>
                </button>
              </li>
            );
          })}
        </ul>
      </div>
    </div>
  );
}
