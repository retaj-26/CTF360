import { useState } from 'react';
import { RadioTower, RotateCcw, Unlock } from 'lucide-react';
import { useStore } from '../../state/store';
import { UI } from '../../data/ui';
import { DECODERS } from '../../engine/decoders';
import { play } from '../../audio/sound';
import type { DecoderPayload } from '../../engine/types';
import type { SceneProps } from './sceneProps';

export function DecoderChallenge({ challenge, payload, solved }: SceneProps<DecoderPayload>) {
  const { t, dispatch, progressOf } = useStore();
  const [mode, setMode] = useState(payload.defaultMode ?? payload.modes[0]);
  const [input, setInput] = useState(payload.input);
  const [out, setOut] = useState<{ ok: boolean; text: string } | null>(null);
  const decoded = progressOf(challenge.id).decoded;

  const run = () => {
    const r = DECODERS[mode](input);
    if (r.ok) {
      play('correct');
      setOut({ ok: true, text: r.text });
      // Only count a decode of the original signal as "used the decoder".
      if (input.trim() === payload.input.trim() && !decoded) dispatch({ type: 'decoded', id: challenge.id });
    } else {
      play('wrong');
      setOut({ ok: false, text: t(UI.decodeError) });
    }
  };

  return (
    <div className="scene decoder">
      <div className="decoder__head">
        <RadioTower size={18} aria-hidden="true" />
        <span>{t(UI.decoder)}</span>
        <span className="decoder__label">{t(payload.signalLabel)}</span>
      </div>
      <label className="decoder__field">
        <span>{t(UI.decoderInput)}</span>
        <textarea
          className="input input--mono decoder__in"
          dir="ltr"
          rows={payload.input.length > 60 ? 3 : 2}
          spellCheck={false}
          value={input}
          onChange={(e) => setInput(e.target.value)}
        />
      </label>
      <div className="decoder__tools">
        {payload.modes.length > 1 && (
          <div className="seg seg--big" role="radiogroup" aria-label={t(UI.decoder)}>
            {payload.modes.map((m) => (
              <button
                key={m}
                type="button"
                role="radio"
                aria-checked={mode === m}
                className={`seg__btn ${mode === m ? 'is-active' : ''}`}
                onClick={() => {
                  play('click');
                  setMode(m);
                  setOut(null);
                }}
              >
                {t(UI[m])}
              </button>
            ))}
          </div>
        )}
        <button type="button" className="btn btn--primary" onClick={run}>
          <Unlock size={18} aria-hidden="true" /> {t(UI.decode)}
          {payload.modes.length === 1 && <small className="mono"> · {t(UI[mode])}</small>}
        </button>
        {input !== payload.input && (
          <button type="button" className="btn btn--ghost btn--sm" onClick={() => setInput(payload.input)} aria-label="reset input">
            <RotateCcw size={16} aria-hidden="true" />
          </button>
        )}
      </div>
      <div className={`decoder__out ${out ? (out.ok ? 'is-ok' : 'is-bad') : ''}`} aria-live="polite">
        <span className="decoder__outlabel">{t(UI.decoderOutput)}</span>
        <output dir="ltr" className="mono">
          {out ? out.text : solved || decoded ? '▒▒▒' : '_'}
          {!out && <span className="caret" />}
        </output>
      </div>
    </div>
  );
}
