import { Avatar } from './Avatar';
import { useEffect, useState } from 'react';
import { Trophy, Medal, Users, MonitorPlay, X, Wifi, HardDrive, Server, ArrowRight, ArrowLeft } from 'lucide-react';
import { useStore } from '../state/store';
import { UI } from '../data/ui';
import { board, type BoardMode, type TeamRecord } from '../engine/board';
import { Pixels, CardFoot, Wordmark } from './Brand';
import { formatDuration } from './FinalVault';
import { useSettings } from '../state/auth';

export function useBoard() {
  const [teams, setTeams] = useState<TeamRecord[]>(() => board.current());
  const [mode, setMode] = useState<BoardMode>(board.mode);
  const [readOnly, setReadOnly] = useState(board.readOnly);
  useEffect(() => {
    const off = board.subscribe(setTeams);
    const offMode = board.onMode(() => {
      setMode(board.mode);
      setReadOnly(board.readOnly);
    });
    return () => {
      off();
      offMode();
    };
  }, []);
  return { teams, mode, readOnly };
}

/** Time taken to reach the current score, counted from when the admin opened the competition. */
function elapsedOf(t: TeamRecord, openedAt = 0) {
  if (!t.score) return 0;
  return Math.max(0, (t.finishedAt ?? t.scoredAt) - Math.max(t.startedAt, openedAt));
}

export function BoardModeBadge({ mode }: { mode: BoardMode }) {
  const { t } = useStore();
  const Icon = mode === 'shared' || mode === 'supabase' ? Wifi : mode === 'server' ? Server : HardDrive;
  const label = mode === 'shared' || mode === 'supabase' ? UI.boardShared : mode === 'server' ? UI.boardServer : UI.boardLocal;
  return (
    <span className={`modebadge modebadge--${mode}`}>
      <Icon size={14} aria-hidden="true" /> {t(label)}
    </span>
  );
}

/** Compact standings for the case-file sidebar. */
export function MiniBoard() {
  const { t, session } = useStore();
  const { teams, mode } = useBoard();
  const top = teams.slice(0, 5);
  const myIndex = session ? teams.findIndex((x) => x.id === session.id) : -1;
  return (
    <section className="panel miniboard" aria-label={t(UI.leaderboard)}>
      <header className="panel__head">
        <Trophy size={16} aria-hidden="true" /> {t(UI.leaderboard)}
        <a className="miniboard__all" href="#/leaderboard">
          {t(UI.viewBoard)}
        </a>
      </header>
      {myIndex >= 0 && (
        <p className="miniboard__me">
          {t(UI.yourRank)}: <b className="mono">#{myIndex + 1}</b> {t(UI.of)} <span className="mono">{teams.length}</span>
        </p>
      )}
      {top.length === 0 ? (
        <p className="locker__empty">{t(UI.noTeams)}</p>
      ) : (
        <ol className="miniboard__list">
          {top.map((tm, i) => (
            <li key={tm.id} className={tm.id === session?.id ? 'is-me' : ''}>
              <span className={`rankchip rankchip--${i + 1}`}>{i + 1}</span>
              <span className="miniboard__name">{tm.name}</span>
              <b className="mono" dir="ltr">
                {tm.score}
              </b>
            </li>
          ))}
        </ol>
      )}
      <BoardModeBadge mode={mode} />
    </section>
  );
}

export function Leaderboard({ tv = false }: { tv?: boolean }) {
  const { t, session, prefs } = useStore();
  const { teams, mode, readOnly } = useBoard();
  const settings = useSettings();
  const [, tick] = useState(0);
  const Back = prefs.lang === 'ar' ? ArrowRight : ArrowLeft;
  useEffect(() => {
    const id = setInterval(() => tick((n) => n + 1), 1000);
    return () => clearInterval(id);
  }, []);
  const podium = teams.slice(0, 3);
  const order = [1, 0, 2].filter((i) => podium[i]);

  return (
    <div className={`lb ${tv ? 'lb--tv' : ''}`}>
      <header className="lb__head">
        <Pixels corner="tr" />
        <div>
          <p className="kicker mono" dir="ltr">
            CTF360 // SCOREBOARD
          </p>
          <h1>
            <Trophy size={34} aria-hidden="true" /> {t(UI.leaderboard)}
          </h1>
          <div className="lb__meta">
            <BoardModeBadge mode={mode} />
            <span className="lb__live">
              <i aria-hidden="true" /> {t({ ar: 'مباشر', en: 'Live' })}
            </span>
            <span className="lb__count">
              <Users size={14} aria-hidden="true" /> <span className="mono">{teams.length}</span> {t(UI.teams)}
            </span>
          </div>
          {readOnly && <p className="lb__warn">{t(UI.boardReadOnly)}</p>}
        </div>
        <div className="lb__actions">
          {tv ? (
            <>
              <Wordmark size="md" />
              <a className="btn btn--ghost btn--sm" href="#/leaderboard">
                <X size={16} aria-hidden="true" /> {t(UI.exitTv)}
              </a>
            </>
          ) : (
            <>
              <a className="btn btn--ghost" href={session ? '#/hub' : '#/intro'}>
                <Back size={16} aria-hidden="true" /> {session ? t(UI.backHub) : t({ ar: 'الصفحة الرئيسية', en: 'Home' })}
              </a>
              <a className="btn btn--primary" href="#/leaderboard/tv">
                <MonitorPlay size={18} aria-hidden="true" /> {t(UI.tvMode)}
              </a>
            </>
          )}
        </div>
      </header>

      {teams.length === 0 ? (
        <div className="lb__empty">
          <Trophy size={48} aria-hidden="true" />
          <p>{t(UI.noTeams)}</p>
          {!session && !tv && (
            <a className="btn btn--primary btn--lg" href="#/intro">
              {t(UI.codenameTitle)}
            </a>
          )}
        </div>
      ) : (
        <>
          <ol className="podium" aria-label="top 3">
            {order.map((i) => {
              const tm = podium[i];
              return (
                <li key={tm.id} className={`podium__step podium__step--${i + 1} ${tm.id === session?.id ? 'is-me' : ''}`}>
                  <span className="podium__medal">{i === 0 ? <Trophy size={30} aria-hidden="true" /> : <Medal size={26} aria-hidden="true" />}</span>
                  <span className="podium__rank mono">#{i + 1}</span>
                  {tm.avatar && <Avatar id={tm.avatar} size={i === 0 ? 56 : 46} className="podium__avatar" />}
                  <b className="podium__name">{tm.name}</b>
                  <span className="podium__members">{tm.members.join(' · ')}</span>
                  <b className="podium__score mono" dir="ltr">
                    {tm.score}
                  </b>
                  <span className="podium__block" aria-hidden="true" />
                </li>
              );
            })}
          </ol>

          <div className="lbtable" role="table" aria-label={t(UI.leaderboard)}>
            <div className="lbtable__row lbtable__row--head" role="row">
              <span role="columnheader">{t(UI.rank)}</span>
              <span role="columnheader">{t(UI.agent)}</span>
              <span role="columnheader">{t(UI.progressCol)}</span>
              <span role="columnheader">{t(UI.timeCol)}</span>
              <span role="columnheader">{t(UI.score)}</span>
            </div>
            {teams.map((tm, i) => (
              <div key={tm.id} role="row" className={`lbtable__row ${tm.id === session?.id ? 'is-me' : ''}`}>
                <span role="cell">
                  <span className={`rankchip rankchip--${i + 1}`}>{i + 1}</span>
                </span>
                <span role="cell" className="lbtable__team">
                  <b>
                    {tm.avatar && <Avatar id={tm.avatar} size={26} className="lbtable__avatar" />}
                    {tm.name}
                    {tm.id === session?.id && <em className="lbtable__you">{t(UI.you)}</em>}
                  </b>
                  {tm.members.length > 0 && <small>{tm.members.join(' · ')}</small>}
                </span>
                <span role="cell" className="lbtable__prog">
                  <span className="lbtable__bar">
                    <i style={{ inlineSize: `${Math.round((tm.solved / Math.max(1, tm.total)) * 100)}%` }} />
                  </span>
                  <small className="mono">
                    <bdi>
                      {tm.solved}/{tm.total}
                    </bdi>{' '}
                    {tm.finishedAt ? `· ${t(UI.finished)}` : ''}
                  </small>
                </span>
                <span role="cell" className="mono">
                  <bdi>{tm.score ? formatDuration(elapsedOf(tm, settings.openedAt)) : '—'}</bdi>
                </span>
                <span role="cell" className="lbtable__score mono">
                  <bdi>{tm.score}</bdi>
                </span>
              </div>
            ))}
          </div>
        </>
      )}
      {!tv && <CardFoot code="SCOREBOARD" />}
    </div>
  );
}
