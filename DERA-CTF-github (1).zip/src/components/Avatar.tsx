import type { L10n } from '../engine/types';
import type { Spec } from '../engine/accounts';

const s = (ar: string, en: string): L10n => ({ ar, en });

/** Cyber-security "hats" plus a few emoji avatars. */
export const AVATARS: { id: string; kind: 'hat' | 'emoji'; color?: string; band?: string; emoji?: string; label: L10n; meaning?: L10n }[] = [
  { id: 'hat-white', kind: 'hat', color: '#F4F2FA', band: '#8A5CF6', label: s('القبعة البيضاء', 'White Hat'), meaning: s('مخترقة أخلاقية تحمي الأنظمة بإذن', 'Ethical hacker who protects with permission') },
  { id: 'hat-black', kind: 'hat', color: '#1B1726', band: '#FF3D8B', label: s('القبعة السوداء', 'Black Hat'), meaning: s('المهاجم الضار — نتعلّم أساليبه عشان نوقفه', 'The malicious attacker — we learn his tricks to stop him') },
  { id: 'hat-grey', kind: 'hat', color: '#9A96A8', band: '#15121F', label: s('القبعة الرمادية', 'Grey Hat'), meaning: s('بين الأبيض والأسود', 'Somewhere between white and black') },
  { id: 'hat-red', kind: 'hat', color: '#FF4D5E', band: '#15121F', label: s('القبعة الحمراء', 'Red Hat'), meaning: s('الفريق الأحمر: يحاكي الهجوم لاختبار الدفاع', 'Red team: simulates attacks to test defences') },
  { id: 'hat-purple', kind: 'hat', color: '#8A5CF6', band: '#C8F04A', label: s('القبعة البنفسجية', 'Purple Hat'), meaning: s('الفريق البنفسجي: يجمع الهجوم والدفاع', 'Purple team: attack and defence together') },
  { id: 'hat-blue', kind: 'hat', color: '#3B82F6', band: '#F4F2FA', label: s('القبعة الزرقاء', 'Blue Hat'), meaning: s('الفريق الأزرق: يراقب ويدافع', 'Blue team: monitors and defends') },
  { id: 'e-shield', kind: 'emoji', emoji: '🛡️', label: s('الدرع', 'Shield') },
  { id: 'e-detective', kind: 'emoji', emoji: '🕵️‍♀️', label: s('المحققة', 'Detective') },
  { id: 'e-lock', kind: 'emoji', emoji: '🔐', label: s('القفل', 'Lock') },
  { id: 'e-alien', kind: 'emoji', emoji: '👾', label: s('البكسل', 'Pixel') },
  { id: 'e-laptop', kind: 'emoji', emoji: '💻', label: s('اللابتوب', 'Laptop') },
  { id: 'e-owl', kind: 'emoji', emoji: '🦉', label: s('البومة', 'Owl') },
  { id: 'e-bolt', kind: 'emoji', emoji: '⚡', label: s('البرق', 'Bolt') },
  { id: 'e-rocket', kind: 'emoji', emoji: '🚀', label: s('الصاروخ', 'Rocket') },
];

export const avatarById = (id?: string) => AVATARS.find((a) => a.id === id) ?? AVATARS[0];

function Hat({ color, band }: { color: string; band: string }) {
  return (
    <svg viewBox="0 0 64 64" aria-hidden="true" className="hat">
      <ellipse cx="32" cy="44" rx="27" ry="8" fill={color} stroke="#15121F" strokeWidth="2.5" />
      <path d="M17 43 C17 30 19 18 25 16 C28 15 30 19 32 19 C34 19 36 15 39 16 C45 18 47 30 47 43 Z" fill={color} stroke="#15121F" strokeWidth="2.5" strokeLinejoin="round" />
      <path d="M18 36 C26 39 38 39 46 36 L46.6 41 C38 44 26 44 17.4 41 Z" fill={band} stroke="#15121F" strokeWidth="2" strokeLinejoin="round" />
    </svg>
  );
}

export function Avatar({ id, size = 44, className = '' }: { id?: string; size?: number; className?: string }) {
  const a = avatarById(id);
  return (
    <span className={`avatar avatar--${a.kind} ${className}`} style={{ inlineSize: size, blockSize: size, fontSize: size * 0.56 }} aria-hidden="true">
      {a.kind === 'hat' ? <Hat color={a.color!} band={a.band!} /> : a.emoji}
    </span>
  );
}

export const SPECS: { id: Spec; label: L10n; icon: string }[] = [
  { id: 'net', label: s('إدارة أنظمة الشبكات', 'Network systems administration'), icon: '🌐' },
  { id: 'web', label: s('برمجة الويب', 'Web programming'), icon: '💻' },
  { id: 'support', label: s('الدعم الفني', 'IT support'), icon: '🛠️' },
  { id: 'marketing', label: s('أخرى · تسويق', 'Other · Marketing'), icon: '📣' },
  { id: 'office', label: s('أخرى · إدارة مكتبية', 'Other · Office administration'), icon: '🗂️' },
  { id: 'other', label: s('أخرى · غير ذلك', 'Other · Something else'), icon: '✨' },
];
export const specById = (id: Spec) => SPECS.find((x) => x.id === id) ?? SPECS[5];

/** Emoji avatars for individual team members. */
export const MEMBER_EMOJIS = ['👩‍💻', '🧕', '🦸‍♀️', '🕵️‍♀️', '🧠', '⚡', '🔥', '🌟', '🦊', '🐱', '🐼', '🦄', '🌸', '🎧', '🎮', '🚀', '🛡️', '🔐', '💎', '👑', '🐉', '🦋', '🍀', '☕'];
