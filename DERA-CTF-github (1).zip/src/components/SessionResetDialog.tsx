import { useStore } from '../state/store';
import { UI } from '../data/ui';
import { Dialog } from './Controls';
import { navigate } from '../router';
import { play } from '../audio/sound';

export function SessionResetDialog({ open, onClose }: { open: boolean; onClose: () => void }) {
  const { t, dispatch } = useStore();
  return (
    <Dialog open={open} onClose={onClose} title={t(UI.resetTitle)} tone="danger">
      <p className="dialog__text">{t(UI.resetBody)}</p>
      <div className="dialog__actions">
        <button type="button" className="btn btn--ghost" onClick={onClose}>
          {t(UI.cancel)}
        </button>
        <button
          type="button"
          className="btn btn--danger"
          onClick={() => {
            play('crt');
            dispatch({ type: 'reset' });
            onClose();
            navigate('/intro');
          }}
        >
          {t(UI.resetConfirm)}
        </button>
      </div>
    </Dialog>
  );
}
