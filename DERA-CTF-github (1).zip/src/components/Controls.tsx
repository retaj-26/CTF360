import { useEffect, useRef, useState, type ReactNode } from 'react';
import { Settings2, X } from 'lucide-react';
import { useStore } from '../state/store';
import { UI } from '../data/ui';
import { play } from '../audio/sound';

export function SettingsMenu() {
  const { prefs, dispatch, t } = useStore();
  const [open, setOpen] = useState(false);
  const ref = useRef<HTMLDivElement>(null);
  useEffect(() => {
    if (!open) return;
    const onDoc = (e: MouseEvent) => {
      if (ref.current && !ref.current.contains(e.target as Node)) setOpen(false);
    };
    const onKey = (e: KeyboardEvent) => e.key === 'Escape' && setOpen(false);
    document.addEventListener('mousedown', onDoc);
    document.addEventListener('keydown', onKey);
    return () => {
      document.removeEventListener('mousedown', onDoc);
      document.removeEventListener('keydown', onKey);
    };
  }, [open]);

  const seg = <K extends 'motion' | 'exhibition'>(key: K, value: (typeof prefs)[K], label: string) => (
    <button
      type="button"
      className={`seg__btn ${prefs[key] === value ? 'is-active' : ''}`}
      aria-pressed={prefs[key] === value}
      onClick={() => {
        play('click');
        dispatch({ type: 'pref', patch: { [key]: value } as Partial<typeof prefs> });
      }}
    >
      {label}
    </button>
  );

  return (
    <div className="settings" ref={ref}>
      <button type="button" className="ctl" aria-expanded={open} aria-label={t(UI.settings)} onClick={() => setOpen((o) => !o)}>
        <Settings2 size={18} aria-hidden="true" />
      </button>
      {open && (
        <div className="settings__pop" role="dialog" aria-label={t(UI.settings)}>
          <div className="settings__row">
            <span>{t(UI.motion)}</span>
            <div className="seg">
              {seg('motion', 'system', t(UI.motionSystem))}
              {seg('motion', 'reduced', t(UI.motionReduced))}
              {seg('motion', 'full', t(UI.motionFull))}
            </div>
          </div>
          <div className="settings__row">
            <span>{t(UI.exhibition)}</span>
            <div className="seg">
              {seg('exhibition', true, t(UI.exhibitionOn))}
              {seg('exhibition', false, t(UI.exhibitionOff))}
            </div>
          </div>
        </div>
      )}
    </div>
  );
}

export function Dialog({
  open,
  onClose,
  title,
  children,
  tone = 'default',
}: {
  open: boolean;
  onClose: () => void;
  title: string;
  children: ReactNode;
  tone?: 'default' | 'danger' | 'success';
}) {
  const ref = useRef<HTMLDivElement>(null);
  useEffect(() => {
    if (!open) return;
    const prev = document.activeElement as HTMLElement | null;
    const first = ref.current?.querySelector<HTMLElement>('button, [href], input');
    first?.focus();
    const onKey = (e: KeyboardEvent) => {
      if (e.key === 'Escape') onClose();
      if (e.key === 'Tab' && ref.current) {
        const els = Array.from(ref.current.querySelectorAll<HTMLElement>('button, [href], input'));
        if (!els.length) return;
        const [a, z] = [els[0], els[els.length - 1]];
        if (e.shiftKey && document.activeElement === a) {
          e.preventDefault();
          z.focus();
        } else if (!e.shiftKey && document.activeElement === z) {
          e.preventDefault();
          a.focus();
        }
      }
    };
    document.addEventListener('keydown', onKey);
    return () => {
      document.removeEventListener('keydown', onKey);
      prev?.focus?.();
    };
  }, [open, onClose]);
  if (!open) return null;
  return (
    <div className="dialog" role="presentation" onMouseDown={(e) => e.target === e.currentTarget && onClose()}>
      <div className={`dialog__box dialog__box--${tone}`} role="dialog" aria-modal="true" aria-label={title} ref={ref}>
        <div className="dialog__head">
          <h2>{title}</h2>
          <button type="button" className="ctl ctl--ghost" onClick={onClose} aria-label="Close">
            <X size={18} />
          </button>
        </div>
        {children}
      </div>
    </div>
  );
}
