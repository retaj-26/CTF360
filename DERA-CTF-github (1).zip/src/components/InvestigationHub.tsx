import { useEffect, useMemo, useRef, useState } from 'react';
import { HelpCircle, Lock, LockOpen, ChevronsLeft, ChevronsRight, Clock, ShieldCheck, KeyRound, Award, Headset, Network, Code2, TriangleAlert, Users } from 'lucide-react';
import { useStore, stats, roomProgress, type Session } from '../state/store';
import { ROOMS } from '../data/rooms';
import { CHALLENGES, byId } from '../data/challenges';
import { UI } from '../data/ui';
import { Dialog } from './Controls';
import { VaultArt } from './RoomArt';
import { EmergencyLights } from './Atmosphere';
import { PartnerStrip, Pixels, CardFoot, Wordmark } from './Brand';
import { MiniBoard } from './Leaderboard';
import { navigate } from '../router';
import { play } from '../audio/sound';
import type { L10n, Room } from '../engine/types';

// Fictional, scripted events for the "live" incident log.
const SCRIPT: { lvl: 'warn' | 'err' | 'info'; msg: L10n }[] = [
  { lvl: 'err', msg: { ar: 'دخول ناجح لحساب razan من سنغافورة', en: 'Successful login to razan from Singapore' } },
  { lvl: 'warn', msg: { ar: 'جهاز جديد «iPhone-X» انضم للشبكة 192.168.10.0/24', en: 'New device “iPhone-X” joined 192.168.10.0/24' } },
  { lvl: 'info', msg: { ar: 'تذكرة دعم جديدة: «الطابعة ما تطبع»', en: 'New ticket: “the printer won’t print”' } },
  { lvl: 'err', msg: { ar: 'انقطاع الوصلة بين المبدّل والموجّه', en: 'Link down between switch and router' } },
  { lvl: 'warn', msg: { ar: '37 رسالة من النطاق org-sa-secure.com', en: '37 emails from org-sa-secure.com' } },
  { lvl: 'warn', msg: { ar: 'طلب RDP من عنوان خارجي مجهول', en: 'RDP request from an unknown external address' } },
  { lvl: 'err', msg: { ar: 'alarm.py توقف بخطأ SyntaxError', en: 'alarm.py crashed with SyntaxError' } },
  { lvl: 'info', msg: { ar: 'مكالمة واردة على خط الدعم…', en: 'Incoming call on the support line…' } },
  { lvl: 'warn', msg: { ar: 'كاميرا المدخل تتصل بخادم خارجي عبر Telnet', en: 'Entrance camera connecting abroad over Telnet' } },
  { lvl: 'err', msg: { ar: 'محاولة دخول فاشلة على razan-hr', en: 'Failed login on razan-hr' } },
];

function stamp(d = new Date()) {
  return d.toLocaleTimeString('en-GB', { hour12: false });
}

function IncidentLog({ session }: { session: Session }) {
  const { t, reducedMotion } = useStore();
  const [lines, setLines] = useState<{ id: number; time: string; lvl: string; msg: L10n }[]>(() =>
    SCRIPT.slice(0, 4).map((s, i) => ({ id: i, time: stamp(new Date(Date.now() - (4 - i) * 47000)), ...s })),
  );
  const idx = useRef(4);
  const box = useRef<HTMLOListElement>(null);

  useEffect(() => {
    const id = setInterval(() => {
      const s = SCRIPT[idx.current % SCRIPT.length];
      idx.current++;
      setLines((l) => [...l.slice(-11), { id: idx.current + 1000, time: stamp(), ...s }]);
    }, reducedMotion ? 9000 : 4200);
    return () => clearInterval(id);
  }, [reducedMotion]);

  // Real events from this visitor's progress are interleaved in green.
  const solvedEvents = useMemo(
    () =>
      CHALLENGES.filter((c) => session.progress[c.id]?.solved)
        .sort((a, b) => (session.progress[a.id].solvedAt ?? 0) - (session.progress[b.id].solvedAt ?? 0))
        .slice(-3)
        .map((c) => ({
          id: c.id,
          time: stamp(new Date(session.progress[c.id].solvedAt ?? Date.now())),
          lvl: 'ok',
          msg: { ar: `${session.codename} أنهى «${c.title.ar}»`, en: `${session.codename} cleared “${c.title.en}”` },
        })),
    [session],
  );

  useEffect(() => {
    const el = box.current;
    if (el) el.scrollTop = el.scrollHeight;
  }, [lines, solvedEvents]);

  return (
    <section className="panel log" aria-label={t(UI.incidentLog)}>
      <header className="panel__head">
        <span className="live-dot" /> {t(UI.incidentLog)}
      </header>
      <ol className="log__list" ref={box} aria-live="off">
        {[...lines, ...solvedEvents].map((l) => (
          <li key={l.id} className={`log__item log__item--${l.lvl}`}>
            <time dir="ltr">{l.time}</time>
            <span className="log__lvl" dir="ltr">
              {l.lvl === 'ok' ? '[ OK ]' : l.lvl === 'err' ? '[CRIT]' : l.lvl === 'warn' ? '[WARN]' : '[INFO]'}
            </span>
            <span className="log__msg">{t(l.msg)}</span>
          </li>
        ))}
      </ol>
    </section>
  );
}

export function ScorePanel() {
  const { t, session } = useStore();
  const st = stats(session);
  return (
    <section className="panel score" aria-label={t(UI.score)}>
      <div className="score__big">
        <span className="score__label">{t(UI.score)}</span>
        <b className="score__value mono" dir="ltr">
          {st.score}
          <small>/{st.maxScore}</small>
        </b>
      </div>
      <dl className="score__grid">
        <div>
          <dt>{t(UI.solved)}</dt>
          <dd className="mono" dir="ltr">
            {st.solved}/{st.total}
          </dd>
        </div>
        <div>
          <dt>{t(UI.rooms)}</dt>
          <dd className="mono" dir="ltr">
            {st.roomsDone.length}/3
          </dd>
        </div>
        <div>
          <dt>{t(UI.hintsUsed)}</dt>
          <dd className="mono" dir="ltr">
            {st.hints}
          </dd>
        </div>
      </dl>
      <div className="meter" role="progressbar" aria-valuemin={0} aria-valuemax={100} aria-valuenow={st.progressPct} aria-label={t(UI.progress)}>
        <div className="meter__head">
          <span>{t(UI.progress)}</span>
          <span className="mono" dir="ltr">
            {st.progressPct}%
          </span>
        </div>
        <div className="meter__bar">
          <i style={{ inlineSize: `${st.progressPct}%` }} />
          {[1, 2, 3].map((n) => (
            <span key={n} className="meter__tick" style={{ insetInlineStart: `${(n * 3 * 100) / 10}%` }} />
          ))}
        </div>
      </div>
      <p className="score__note">{t(UI.localOnly)}</p>
    </section>
  );
}

function EvidenceLocker() {
  const { t, session } = useStore();
  const st = stats(session);
  return (
    <section className="panel locker" aria-label={t(UI.evidence)}>
      <header className="panel__head">
        <KeyRound size={16} aria-hidden="true" /> {t(UI.evidence)}
      </header>
      <ol className="locker__slots">
        {ROOMS.map((r) => {
          const has = st.roomsDone.includes(r.id);
          return (
            <li key={r.id} className={`locker__slot ${has ? 'is-found' : ''}`} style={{ '--accent': r.accent } as React.CSSProperties}>
              <span className="locker__room">{t(r.name)}</span>
              <span className="codeboxes codeboxes--sm" dir="ltr">
                <span className="codeboxes__grp">
                  {(has ? r.fragment : '????').split('').map((ch, i) => (
                    <i key={i}>{has ? ch : ''}</i>
                  ))}
                </span>
              </span>
            </li>
          );
        })}
      </ol>
      {st.roomsDone.length === 0 && <p className="locker__empty">{t(UI.evidenceEmpty)}</p>}
    </section>
  );
}

const ROOM_ICON = { headset: Headset, network: Network, code: Code2 };

function RoomEntrance({ room }: { room: Room }) {
  const { t, session, prefs } = useStore();
  const rp = roomProgress(session, room.id);
  const Arrow = prefs.lang === 'ar' ? ChevronsLeft : ChevronsRight;
  const Icon = ROOM_ICON[room.icon];
  return (
    <article
      className={`env env--${room.id} ${rp.complete ? 'is-complete' : ''}`}
      style={{ '--accent': room.accent } as React.CSSProperties}
    >
      <a
        className="env__link"
        href={`#/room/${room.id}`}
        onClick={() => play('click')}
        aria-label={`${t(room.clue)}: ${t(room.name)} — ${rp.done}/${rp.total}`}
      >
        <span className="env__flap" aria-hidden="true" />
        <Pixels corner="tr" size={7} />
        <div className="env__top">
          <span className="env__brand">
            <Wordmark size="xs" />
          </span>
          {rp.complete && (
            <span className="env__stamp">
              <ShieldCheck size={14} aria-hidden="true" /> {t(UI.roomCleared)}
            </span>
          )}
        </div>
        <p className="env__clue">{t(room.clue)}</p>
        <div className="env__hero">
          <span className="bignum" dir="ltr">
            0{room.index}
          </span>
          <Icon className="env__icon" size={44} strokeWidth={1.6} aria-hidden="true" />
        </div>
        <h3 className="env__name">{t(room.category)}</h3>
        <p className="env__teaser">{t(room.teaser)}</p>
        <ul className="door__meta">
          <li>{t(room.difficulty)}</li>
          <li>
            <Clock size={13} aria-hidden="true" /> <span dir="ltr">{room.minutes}</span> {t(UI.minutes)}
          </li>
        </ul>
        <div className="door__foot">
          <ol className="pips" aria-hidden="true">
            {room.challengeIds.map((id) => (
              <li key={id} className={session?.progress[id]?.solved ? 'is-on' : ''}>
                {byId(id).letter}
              </li>
            ))}
          </ol>
          <span className="door__cta">
            {rp.complete ? t(UI.revisit) : t(UI.enterRoom)} <Arrow size={16} aria-hidden="true" />
          </span>
        </div>
        <CardFoot code={`D360_0${room.index}`} />
      </a>
    </article>
  );
}

function Vault() {
  const { t, session } = useStore();
  const st = stats(session);
  const bolts = ROOMS.map((r) => st.roomsDone.includes(r.id));
  const open = st.vaultOpen;
  return (
    <section className={`vault ${open ? 'is-open' : ''} ${st.finalSolved ? 'is-done' : ''}`} aria-label={t(UI.vault)}>
      <div className="vault__art">
        <VaultArt bolts={bolts} open={open} />
      </div>
      <div className="vault__body">
        <p className="vault__kicker mono" dir="ltr">
          D360_04 // FINAL VAULT
        </p>
        <h2 className="vault__title">{t(UI.vault)}</h2>
        <p className="vault__text">
          {st.finalSolved ? t(UI.vaultDone) : open ? t(UI.vaultOpen) : t(UI.vaultLocked)}
        </p>
        <div className="vault__bolts">
          {ROOMS.map((r, i) => (
            <span key={r.id} className={bolts[i] ? 'is-on' : ''}>
              {bolts[i] ? <LockOpen size={14} aria-hidden="true" /> : <Lock size={14} aria-hidden="true" />} {t(r.name)}
            </span>
          ))}
        </div>
        {open ? (
          <div className="vault__actions">
            <button
              type="button"
              className="btn btn--primary btn--lg"
              onClick={() => {
                play('unlock');
                navigate('/vault');
              }}
            >
              <LockOpen size={18} aria-hidden="true" /> {t(UI.vaultEnter)}
            </button>
            {st.finalSolved && (
              <a className="btn btn--ghost btn--lg" href="#/certificate">
                <Award size={18} aria-hidden="true" /> {t(UI.viewCertificate)}
              </a>
            )}
          </div>
        ) : (
          <button type="button" className="btn btn--locked btn--lg" disabled aria-disabled="true">
            <Lock size={18} aria-hidden="true" /> {st.solved}/{st.total}
          </button>
        )}
      </div>
    </section>
  );
}

export function InvestigationHub() {
  const { t, session, dispatch } = useStore();
  const [helpOpen, setHelpOpen] = useState(() => !!session && Object.keys(session.progress).length === 0);
  if (!session) return null;
  const st = stats(session);
  return (
    <div className="hub">
      <EmergencyLights restored={st.finalSolved} />
      <div className="hub__partners">
        <PartnerStrip variant="bar" />
      </div>
      <section className="casehead">
        <Pixels corner="tr" />
        <div className="casehead__alert" aria-hidden="true">
          <TriangleAlert size={56} strokeWidth={1.8} />
        </div>
        <div className="casehead__text">
          <p className="kicker mono" dir="ltr">
            CASE_001 // {st.finalSolved ? 'SOLVED' : 'OPEN'}
          </p>
          <h1>{st.finalSolved ? t(UI.solvedCase) : t({ ar: 'تم اختراق حساب موظف', en: 'A staff account was breached' })}</h1>
          <p className="casehead__team">
            <Users size={16} aria-hidden="true" /> <b>{session.codename}</b>
            {session.members?.length ? <span> — {session.members.join('، ')}</span> : null}
          </p>
          <p>{t({ ar: 'اختاري أي مسار من الثلاثة، اجمعي رموز المراحل، ثم افتحي القبو الأخير. كل نقطة تجمعينها تظهر في لوحة الترتيب.', en: 'Pick any of the three tracks, collect the stage codes, then open the final vault. Every point shows on the leaderboard.' })}</p>
        </div>
        <button type="button" className="btn btn--ghost casehead__help" onClick={() => setHelpOpen(true)}>
          <HelpCircle size={18} aria-hidden="true" /> {t(UI.help)}
        </button>
      </section>

      <div className="hub__grid">
        <div className="hub__main">
          <div className="doors">
            {ROOMS.map((r) => (
              <RoomEntrance key={r.id} room={r} />
            ))}
          </div>
          <Vault />
        </div>
        <aside className="hub__side">
          <ScorePanel />
          <EvidenceLocker />
          <MiniBoard />
          <IncidentLog session={session} />
        </aside>
      </div>

      <Dialog open={helpOpen} onClose={() => setHelpOpen(false)} title={t(UI.helpTitle)}>
        <ol className="howto">
          {UI.helpBody.map((l, i) => (
            <li key={i}>
              <span className="howto__n mono">{i + 1}</span>
              {t(l)}
            </li>
          ))}
        </ol>
        <div className="dialog__actions">
          <button
            type="button"
            className="btn btn--primary"
            onClick={() => {
              setHelpOpen(false);
              dispatch({ type: 'pref', patch: { introSeen: true } });
            }}
          >
            {t(UI.helpClose)}
          </button>
        </div>
      </Dialog>
    </div>
  );
}
