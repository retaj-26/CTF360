/** Layered, CSS-only atmosphere: fog, grain, scanlines, vignette. Disabled/frozen in reduced motion. */
export function Atmosphere({ tone = 'default' }: { tone?: 'default' | 'helpdesk' | 'network' | 'code' | 'vault' | 'restored' }) {
  return (
    <div className={`atmo atmo--${tone}`} aria-hidden="true">
      <div className="atmo__fog atmo__fog--a" />
      <div className="atmo__fog atmo__fog--b" />
      {tone === 'code' && <div className="atmo__rain" />}
      {tone === 'network' && <div className="atmo__grid" />}
      {tone === 'helpdesk' && <div className="atmo__flicker" />}
      <div className="atmo__grain" />
      <div className="atmo__scan" />
      <div className="atmo__vignette" />
    </div>
  );
}

/** Emergency light bar — red while compromised, green once restored. */
export function EmergencyLights({ restored = false }: { restored?: boolean }) {
  return (
    <div className={`elights ${restored ? 'elights--ok' : ''}`} aria-hidden="true">
      <span />
      <span />
      <span />
    </div>
  );
}
