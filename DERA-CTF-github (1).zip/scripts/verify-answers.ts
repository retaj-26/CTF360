// Sanity checks: the browser SHA-256 matches Node's, every challenge has a valid answer path,
// normalization accepts harmless variations and rejects wrong answers.
import { createHash } from 'node:crypto';
import { readFileSync } from 'node:fs';
import { sha256Hex } from '../src/engine/sha256.ts';
import { normalize, hashInput, type NormMode } from '../src/engine/normalize.ts';
import { ANSWER_KEYS } from '../src/data/answerKeys.generated.ts';
import { decodeMorse, decodeBase64, decodeHex } from '../src/engine/decoders.ts';

let fail = 0;
const ok = (cond: boolean, msg: string) => {
  if (!cond) fail++;
  console.log(`${cond ? '✓' : '✗'} ${msg}`);
};
const check = (id: string, stage: number, raw: string) => {
  const st = ANSWER_KEYS[id][stage];
  return st.hashes.includes(sha256Hex(hashInput(id, stage, normalize(raw, st.mode))));
};

for (const s of ['', 'abc', 'العربية ✓', 'x'.repeat(200)])
  ok(sha256Hex(s) === createHash('sha256').update(s, 'utf8').digest('hex'), `sha256 parity (${s.slice(0, 12) || 'empty'})`);

const answers = JSON.parse(readFileSync(new URL('../server/answers.json', import.meta.url), 'utf8'));
for (const [id, stages] of Object.entries(answers)) {
  if (id.startsWith('_')) continue;
  (stages as { mode: NormMode; accept: string[] }[]).forEach((st, i) =>
    st.accept.forEach((a) => ok(check(id, i, a), `${id} stage ${i} accepts "${a}"`)),
  );
}

// Harmless variations accepted
const flagOf = (id: string, st: number) => String(answers[id][st].accept[0]);
ok(check('r3-secret', 0, ' ' + flagOf('r3-secret', 0).toLowerCase().replace('{', '{ ') + ' '), 'flag: spaces + case tolerated');
ok(check('final-signal', 2, flagOf('final-signal', 2).toLowerCase()), 'final flag lowercase ok');
ok(check('r1-phish', 1, 'h-link') && check('r1-phish', 2, 'h-sender'), 'phishing flags accepted in any order');
// Wrong answers rejected
for (const [id, st, a] of [
  ['r1-phish', 0, 'd-greet'],
  ['r1-calls', 2, 'c3-give'],
  ['r1-password', 0, 'pw-fine'],
  ['r2-firewall', 5, 'p6-allow'],
  ['r2-wifi', 0, 'wifi-o'],
  ['r3-trace', 0, 't-4'],
  ['r3-secret', 0, 'DERA{example_flag}'],
  ['r3-secret', 0, 'REVSQXtoNHJkYzBkM2RfczNjcjN0c19sMzRrfQ=='],
  ['final-signal', 0, 'row-4'],
  ['final-signal', 1, 'st-email,st-login,st-click,st-reuse'],
  ['final-signal', 2, 'DERA{OPEN_THE_DOOR}'],
] as const)
  ok(!check(id, st, a), `${id} stage ${st} rejects "${a}"`);

// The encoded key in the code really decodes to the accepted flag
const k = decodeBase64('REVSQXtoNHJkYzBkM2RfczNjcjN0c19sMzRrfQ==');
ok(k.ok && check('r3-secret', 0, k.text), 'ADMIN_KEY decodes to the accepted flag');
const d = decodeBase64('YmFja3VwIGZpbmlzaGVkIGF0IDAyOjAwIC0gbm90aGluZyB0byBzZWUgaGVyZQ==');
ok(d.ok && !d.text.includes('CTF360'), 'LOG_NOTE decoy decodes to plain text');
ok(!decodeHex('REVSQXtoNHJkYzBkM2RfczNjcjN0c19sMzRrfQ==').ok, 'hex tool rejects the Base64 key');
void decodeMorse;

// The plaintext answers must not leak into the generated client file.
const gen = readFileSync(new URL('../src/data/answerKeys.generated.ts', import.meta.url), 'utf8');
const plain = Object.entries(answers)
  .filter(([k]) => !k.startsWith('_'))
  .flatMap(([, st]) => (st as { accept: string[] }[]).flatMap((x) => x.accept));
ok(!plain.some((a) => a.length > 4 && gen.toLowerCase().includes(a.toLowerCase())), 'no plaintext answers in the client key file');

console.log(fail ? `\n${fail} check(s) failed` : '\nAll checks passed');
process.exit(fail ? 1 : 0);
