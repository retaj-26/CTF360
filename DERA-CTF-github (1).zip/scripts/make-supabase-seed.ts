// Builds supabase/organizer-seed.sql (PRIVATE — admin login + official solutions) from
// server/admin.json and server/solutions.json. Run: node scripts/make-supabase-seed.ts
// Then paste the file into Supabase → SQL Editor → Run (after setup.sql). Never commit it.
import { readFileSync, writeFileSync } from 'node:fs';

const q = (s: string) => `'${String(s).replace(/'/g, "''")}'`;
const admin = JSON.parse(readFileSync(new URL('../server/admin.json', import.meta.url), 'utf8'));
const sols = JSON.parse(readFileSync(new URL('../server/solutions.json', import.meta.url), 'utf8'));

let sql = `-- PRIVATE organizer seed: admin login + official solutions. Do not publish.\n`;
sql += `delete from ctf_private.admins;\n`;
sql += `insert into ctf_private.admins (username_key, pass_hash) values (ctf_private.name_key(${q(admin.user)}), extensions.crypt(${q(admin.pass)}, extensions.gen_salt('bf', 10)));\n\n`;
for (const [id, v] of Object.entries(sols) as [string, { answer: string; steps: string[] }][]) {
  if (id.startsWith('_')) continue;
  sql += `insert into ctf_private.solutions (id, answer, steps) values (${q(id)}, ${q(v.answer)}, ${q(JSON.stringify(v.steps))}::jsonb)\n  on conflict (id) do update set answer = excluded.answer, steps = excluded.steps;\n`;
}
writeFileSync(new URL('../supabase/organizer-seed.sql', import.meta.url), sql);
console.log('Wrote supabase/organizer-seed.sql (keep it private).');
