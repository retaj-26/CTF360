import { defineConfig } from 'vite';
import react from '@vitejs/plugin-react';

// base: './' keeps the static build portable (USB stick, sub-folder, any static host).
export default defineConfig({
  base: './',
  plugins: [react()],
  build: {
    target: 'es2020',
    // Modern CSS target: keeps logical properties (RTL/LTR) as written instead of lowering them.
    cssTarget: ['chrome111', 'edge111', 'firefox113', 'safari16.4'],
    chunkSizeWarningLimit: 800,
  },
});
