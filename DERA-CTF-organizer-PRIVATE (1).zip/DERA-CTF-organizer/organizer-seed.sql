-- PRIVATE organizer seed: admin login + official solutions. Do not publish.
delete from ctf_private.admins;
insert into ctf_private.admins (username_key, pass_hash) values (ctf_private.name_key('Retaj Alharbi'), extensions.crypt('roro360', extensions.gen_salt('bf', 10)));

insert into ctf_private.solutions (id, answer, steps) values ('r1-phish', '3 علامات: الرابط الغريب org-sa-secure.com، المرسل من نطاق خارجي، ولغة الاستعجال (خلال 24 ساعة / إيقاف فوري)', '["اضغطي على عنوان المرسل hr@org-sa-secure.com — نطاق مو تابع للجهة.","اضغطي على الرابط https://org-sa-secure.com/login — يقود لصفحة دخول مزيفة.","اضغطي على عبارة «خلال 24 ساعة» أو العنوان العاجل — ضغط نفسي.","الوقت 08:02 يُحفظ للقبو الأخير."]'::jsonb)
  on conflict (id) do update set answer = excluded.answer, steps = excluded.steps;
insert into ctf_private.solutions (id, answer, steps) values ('r1-calls', 'المكالمة 1: إخراج الورق العالق · المكالمة 2: تغيير كلمة المرور + التحقق الثنائي + إبلاغ الأمن · المكالمة 3: الرفض والتحقق بقناة رسمية', '["المكالمة 1 (c1-jam): أبسط حل أولًا — طفّي الطابعة وطلّعي الورق العالق.","المكالمة 2 (c2-secure): حساب مخترق = تغيير كلمة المرور من جهاز آمن + 2FA + إبلاغ.","المكالمة 3 (c3-verify): ما نعطي كلمة المرور لأحد حتى لو «مدير» — نتحقق بقناة رسمية."]'::jsonb)
  on conflict (id) do update set answer = excluded.answer, steps = excluded.steps;
insert into ctf_private.solutions (id, answer, steps) values ('r1-password', 'المشكلة: سهلة التخمين ومكررة (pw-reuse) · ثم بناء كلمة مرور 12+ خانة تحقق كل الشروط', '["اختاري «سهلة التخمين ومستخدمة في أكثر من حساب».","ابني كلمة مرور 12 خانة أو أكثر فيها كبير/صغير/رقم/رمز وبدون الاسم أو 123 (مثال: Qahwa#Buraidah!77)."]'::jsonb)
  on conflict (id) do update set answer = excluded.answer, steps = excluded.steps;
insert into ctf_private.solutions (id, answer, steps) values ('r2-link', 'الوصلة المقطوعة: بين المبدّل والموجّه · الخطوة: فحص الكابل وأضواء المنافذ', '["سجل ping: المبدّل يرد، الموجّه لا ← العطل بينهما.","اضغطي الوصلة switch ↔ router.","اختاري فحص الكابل وأضواء المنافذ."]'::jsonb)
  on conflict (id) do update set answer = excluded.answer, steps = excluded.steps;
insert into ctf_private.solutions (id, answer, steps) values ('r2-firewall', 'الحزم: 1 اسمحي · 2 احظري · 3 احظري · 4 اسمحي · 5 احظري · 6 احظري', '["اسمحي للتصفح الآمن HTTPS وDNS الداخلي.","احظري التحكم عن بُعد من الخارج، والمنافذ الغريبة، وأي اتصال لعنوان مشبوه.","حدّ الوقت 3 دقائق — بعده تنقص النقاط للنصف."]'::jsonb)
  on conflict (id) do update set answer = excluded.answer, steps = excluded.steps;
insert into ctf_private.solutions (id, answer, steps) values ('r2-wifi', 'الشبكة الرسمية: الاسم المطابق للبوستر والمحمية بقفل · السبب: الشبكة التوأم يمر عبرها كل شي ترسلينه', '["قارني كل اسم بالبوستر حرف حرف وشوفي القفل.","اضغطي الشبكة الرسمية (wifi-real).","السبب: المهاجم يشوف/يعدّل كل البيانات (w-spy)."]'::jsonb)
  on conflict (id) do update set answer = excluded.answer, steps = excluded.steps;
insert into ctf_private.solutions (id, answer, steps) values ('r3-script', 'الخطأ في السطر 3 (نقطتان ناقصة بعد if) · الإصلاح: إضافة «:»', '["اقرئي الكود سطر سطر.","اضغطي السطر 3.","اختاري إضافة النقطتين."]'::jsonb)
  on conflict (id) do update set answer = excluded.answer, steps = excluded.steps;
insert into ctf_private.solutions (id, answer, steps) values ('r3-trace', 'الناتج الصحيح: الخيار t-3 · الحماية: قفل الحساب بعد محاولات فاشلة (lock-lockout)', '["تتبّعي العداد مع كل تخمين وانتبهي لـ break.","اختاري الناتج الصحيح t-3.","الحماية: قفل الحساب/التأخير بعد عدة محاولات خاطئة."]'::jsonb)
  on conflict (id) do update set answer = excluded.answer, steps = excluded.steps;
insert into ctf_private.solutions (id, answer, steps) values ('r3-secret', 'DERA{h4rdc0d3d_s3cr3ts_l34k}', '["المتغير ADMIN_KEY فيه نص Base64.","انقليه لجهاز فك الترميز ← Base64 ← يطلع العلم.","LOG_NOTE فخ (مو المفتاح)."]'::jsonb)
  on conflict (id) do update set answer = excluded.answer, steps = excluded.steps;
insert into ctf_private.solutions (id, answer, steps) values ('final-signal', 'المرحلة 1: سطر الدخول رقم 2 (سنغافورة) · المرحلة 2: بريد ← ضغط الرابط ← دخول ← إعادة استخدام كلمة المرور · المرحلة 3: DERA{DONT_OPEN_THE_DOOR}', '["في سجل الدخول: الدخول الغريب من سنغافورة بعد وقت البريد 08:02.","رتّبي: وصل بريد التصيّد ← ضغطت الرابط وأدخلت بياناتها ← دخول من سنغافورة ← نفس كلمة المرور فتحت حسابات ثانية.","اجمعي الشظايا DONT + OPEN + THE_DOOR ← DERA{DONT_OPEN_THE_DOOR}."]'::jsonb)
  on conflict (id) do update set answer = excluded.answer, steps = excluded.steps;
insert into ctf_private.solutions (id, answer, steps) values ('w-welcome', 'DERA{WELCOME_HACKER}', '["ظلّلي المساحة الفاضية تحت سطر status."]'::jsonb)
  on conflict (id) do update set answer = excluded.answer, steps = excluded.steps;
insert into ctf_private.solutions (id, answer, steps) values ('w-format', 'DERA{FOCUS}', '["القاعدة رقم 3 تقول لك وش الكلمة."]'::jsonb)
  on conflict (id) do update set answer = excluded.answer, steps = excluded.steps;
insert into ctf_private.solutions (id, answer, steps) values ('n-whoami', 'DERA{10.0.0.37}', '["فيه ثلاث قيم شكلها أرقام ونقاط. وحدة بس جنبها كلمة IPv4."]'::jsonb)
  on conflict (id) do update set answer = excluded.answer, steps = excluded.steps;
insert into ctf_private.solutions (id, answer, steps) values ('n-exit', 'DERA{172.16.5.1}', '["في الجوالات، الـGateway أحياناً اسمه Router."]'::jsonb)
  on conflict (id) do update set answer = excluded.answer, steps = excluded.steps;
insert into ctf_private.solutions (id, answer, steps) values ('n-dns', 'DERA{10.10.4.20}', '["دوّري على Name: library.dera.lab، والعنوان اللي تحته مباشرة."]'::jsonb)
  on conflict (id) do update set answer = excluded.answer, steps = excluded.steps;
insert into ctf_private.solutions (id, answer, steps) values ('n-dnsq', 'DERA{DNS}', '["اسمها ثلاث حروف، وتشتغل مثل «دليل الهاتف».","الخيار الصحيح: dns"]'::jsonb)
  on conflict (id) do update set answer = excluded.answer, steps = excluded.steps;
insert into ctf_private.solutions (id, answer, steps) values ('n-device', 'DERA{LIVING-ROOM-TV}', '["ابدئي من عمود IP ADDRESS، ثم امشي على نفس السطر لعمود DEVICE."]'::jsonb)
  on conflict (id) do update set answer = excluded.answer, steps = excluded.steps;
insert into ctf_private.solutions (id, answer, steps) values ('s-sound', 'DERA{UNMUTE}', '["أيقونة الصوت لونها وردي… وش مكتوب تحتها؟","الخيار الصحيح: unmute"]'::jsonb)
  on conflict (id) do update set answer = excluded.answer, steps = excluded.steps;
insert into ctf_private.solutions (id, answer, steps) values ('s-caps', 'DERA{CAPS_OFF}', '["فيه تنبيه صغير تحت خانة كلمة المرور.","الخيار الصحيح: caps"]'::jsonb)
  on conflict (id) do update set answer = excluded.answer, steps = excluded.steps;
insert into ctf_private.solutions (id, answer, steps) values ('s-storage', 'DERA{VIDEOS}', '["اقرئي الدليل… لا تخمّنين. أي شريط هو الأطول؟"]'::jsonb)
  on conflict (id) do update set answer = excluded.answer, steps = excluded.steps;
insert into ctf_private.solutions (id, answer, steps) values ('s-printer', 'DERA{ADD_PAPER}', '["الطابعة شغالة ومتصلة… بس فيه شي ناقص.","الخيار الصحيح: paper"]'::jsonb)
  on conflict (id) do update set answer = excluded.answer, steps = excluded.steps;
insert into ctf_private.solutions (id, answer, steps) values ('c-night', 'DERA{GUEST07}', '["ابدئي من عمود TIME، ثم امشي على نفس السطر."]'::jsonb)
  on conflict (id) do update set answer = excluded.answer, steps = excluded.steps;
insert into ctf_private.solutions (id, answer, steps) values ('c-fails', 'DERA{LAB-PC-12}', '["عدّي كلمة FAILED لكل جهاز."]'::jsonb)
  on conflict (id) do update set answer = excluded.answer, steps = excluded.steps;
insert into ctf_private.solutions (id, answer, steps) values ('c-sender', 'DERA{DERA-HELP.XYZ}', '["شوفي عنوان البريد بين علامتي < >، والجزء اللي بعد @."]'::jsonb)
  on conflict (id) do update set answer = excluded.answer, steps = excluded.steps;
insert into ctf_private.solutions (id, answer, steps) values ('c-file', 'DERA{PARTY.JPG.EXE}', '["الامتداد الحقيقي هو اللي بعد آخر نقطة."]'::jsonb)
  on conflict (id) do update set answer = excluded.answer, steps = excluded.steps;
insert into ctf_private.solutions (id, answer, steps) values ('k-print', 'DERA{PURPLE}', '["print تعرض القيمة اللي داخل المتغير color."]'::jsonb)
  on conflict (id) do update set answer = excluded.answer, steps = excluded.steps;
insert into ctf_private.solutions (id, answer, steps) values ('k-plus', 'DERA{7}', '["x يبدأ 4، وبعدين نزيد عليه 3."]'::jsonb)
  on conflict (id) do update set answer = excluded.answer, steps = excluded.steps;
insert into ctf_private.solutions (id, answer, steps) values ('k-join', 'DERA{CYBERGIRL}', '["علامة + بين نصين تلصقهم ببعض بدون مسافة."]'::jsonb)
  on conflict (id) do update set answer = excluded.answer, steps = excluded.steps;
insert into ctf_private.solutions (id, answer, steps) values ('lab-1', 'DERA{192.168.0.42}', '["الشاشة فيها عنوانين متشابهين. واحد للجهاز، وواحد للـGateway."]'::jsonb)
  on conflict (id) do update set answer = excluded.answer, steps = excluded.steps;
insert into ctf_private.solutions (id, answer, steps) values ('lab-2', 'DERA{AIRPLANE_OFF}', '["وش الإعداد اللي ممكن نشغّله في الطيارة وننساه؟","الخيار الصحيح: airplane"]'::jsonb)
  on conflict (id) do update set answer = excluded.answer, steps = excluded.steps;
insert into ctf_private.solutions (id, answer, steps) values ('lab-3', 'DERA{TABLET-X9}', '["ابدئي من عمود TIME، ثم امشي على نفس السطر."]'::jsonb)
  on conflict (id) do update set answer = excluded.answer, steps = excluded.steps;
